This is a script that creates a set of KI definitions for use in test environment's. This script creates a KI, Adds the feature and sets the KI to active. 

Syntax is as follows: 

    Python ki_creation.py <config.py> <kg_name> [<ss_url>] [options]

<Arguments>: This is mandatory fields for the script 

<config.py> - The list of key names and keyindicators that needs to be added
<kg_name> - Enter the KG name for which the keyindicator needs to be added 
<ssl_url> - Enter the URL with the protocol http/https and with the port number 

<options>: This is optional Argument

--auth - username:password for SynIC auth
--num_kgs - number of kgs to query for (default is the input)
--debug - include debug output

Example of a usage:-

    python ki_creation.py enron_config.py gayan_test http://localhost:8999 --debug