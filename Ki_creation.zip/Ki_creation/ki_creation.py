#!/usr/bin/env python
import argparse
import sys
import subprocess
import json
import sys
import pdb
import itertools
import imp
import os

from requests import get
from sys import stderr

LOGIN = "admin:1234"
NUM_KGS = 250

def run(command):

    if DEBUG:
        print("[DEBUG] running command: %s" % command)

    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    (out, err) = p.communicate()

    if p.returncode != 0:
        print("Non-zero return code for: " + command)
        sys.exit(1)

    return out

def _curl(url, verb="GET", _data=None):
    
    if _data:
        data = " -d '" + _data + "' "
    else:
        data = ""

    # the "-f" is important here so that the script will fail if curl receives a non-200 http code
    opts = "{k} -f -sS -X{verb} -u {login}{data}".format(
        k="-k" if url.startswith("https") else "",
        verb=verb,
        login=LOGIN,
        data=data)

    return "curl %s %s" % (opts, url)

def getFeatures(ss, kgName):
    page = 1
    out = run(_curl(ss) + "/api/kgs/" + kgName + "/key_indicator_features")
    
    features = {}
    while True:
        jsonOutput = json.loads(out)
        entities = jsonOutput["entities"]
        properties = jsonOutput["properties"]
        links = jsonOutput["links"]

        for entity in entities:
            id = entity["properties"]["id"]
            name = entity["properties"]["name"]
            features[name] = id

        next_page = "false"
        for link in links:
            name = link["rel"][0]
            if (name == "next"):
                next_page = "true"
        if next_page == "false":
            break
        else:
            page += 1
            #out = run("curl -k -sS -XGET -u " + LOGIN + " " + ss + "/api/kgs/" + kgName + "/key_indicator_features?page=" + str(page))
            out = run(_curl(ss) + "/api/kgs/" + kgName + "/key_indicator_features?page=" + str(page))

    return features


def getFeaturesForKeyindicator(ss, kgName, keyindicatorName, DEBUG):

    keyIndicators = getKeyindicators(ss, kgName, DEBUG)
    if keyindicatorName not in keyIndicators:
        print("Can't find keyindicator '" + keyindicatorName + "' in KG '" + kgName + "'. Aborting.")
        sys.exit(1)

    out = run(_curl(ss) + "/api/kgs/" + kgName + "/key_indicators/" + keyIndicators[keyindicatorName])
    dump = json.loads(out)

    features = []
    for feature in dump["properties"]["features"]:
        feature_id = feature["feature_id"]
        feature_name = feature["name"]
        features.append(feature_name)

    return features


def getKeyindicators(ss, kgName, DEBUG):
    out = run(_curl(ss) + "/api/kgs/" + kgName + "/key_indicators/?limit=1000")
    dump = json.loads(out)

    keyindicators = {}
    if "entities" in dump:
        for entity in dump["entities"]:
            id = entity["properties"]["id"]
            name = entity["properties"]["name"]
            keyindicators[name] = id
            if DEBUG:
                print(name)

    return keyindicators


def getKGs(ss):
    out = run(_curl(ss) + "/api/kgs/?limit=%s" % NUM_KGS)
    dump = json.loads(out)
    kgs = []

    for entity in dump["entities"]:
        name = entity["properties"]["name"]
        kgs.append(name)

    return kgs


def createKeyIndicator(ss, kgName, keyindicatorName, kiProperties, DEBUG):

    if not kgName in getKGs(ss):
        print("Can't find KG: " + kgName + ". Aborting")
        sys.exit(1)

    if keyindicatorName in getKeyindicators(ss, kgName, DEBUG):
        print("Keyindicator '" + keyindicatorName + "' already exists. Not Adding.")
        return

    properties = "&".join(kiProperties)
    out = run(_curl(ss, "POST", properties) + "/api/kgs/" + kgName + "/key_indicators")
    if DEBUG:
        print(out)


def setActive(ss, kgName, keyindicatorName, DEBUG):

    if not kgName in getKGs(ss):
        print("Can't find KG: " + kgName + ". Aborting")
        print("Correct form: 'python kicombo.py ki_name'")
        sys.exit(1)

    keyindicators = getKeyindicators(ss, kgName, DEBUG)
    if keyindicatorName not in keyindicators:
        print("Can't find keyindicator '" + keyindicatorName + "' in KG '" + kgName + "'. Aborting.")
        sys.exit(1)

    properties = "weight=5&active=true"
    out = run(_curl(ss, "PATCH", properties) + "/api/kgs/" + kgName + "/key_indicators/" + keyindicators[keyindicatorName])
    if DEBUG:
        print(out)


def addFeatureToKeyindicator(ss, kgName, keyindicatorName, featureList, DEBUG):

    if not kgName in getKGs(ss):
        print("Can't find KG: " + kgName + ". Aborting")
        sys.exit(1)

    keyindicators = getKeyindicators(ss, kgName, DEBUG)
    if keyindicatorName not in keyindicators:
        print("Can't find keyindicator '" + keyindicatorName + "' in KG '" + kgName + "'. Aborting.")
        sys.exit(1)

    features = getFeatures(ss, kgName)

    # First ensure all feature names exist
    for feature in featureList:
        if not feature in features:
            print("Couldn't find feature " + feature + ". Aborting.")
            sys.exit(1)

    featuresAlreadyInKI = getFeaturesForKeyindicator(ss, kgName, keyindicatorName, DEBUG)

    print("Adding features")
    for feature in featureList:

        if feature in featuresAlreadyInKI:
            print("Feature " + feature + " is already in KI " + keyindicatorName + ". Not adding again.")
            continue

        run(_curl(ss, "POST", 'feature_id=' + features[feature]) + "/api/kgs/" + kgName + "/key_indicators/" + keyindicators[keyindicatorName] + "/add-feature")

def addKIcombos(ss, kgName, keyIndicators, kiNames, DEBUG):

    # Ensure we have a shortcut for each keyIndicator
    if len(keyIndicators) != len(kiNames):
       print("Each KI needs to have a name defined. Aborting.")
       sys.exit(1)

    num_kis = len(kiNames)
    index = 0
    for ki_features, ki_name_properties in zip(keyIndicators, kiNames):
        index += 1
        name_properties = list(ki_name_properties)
        name = name_properties[0]

        # Change first proeprty to be correct form for creating the KI now
        name_properties[0] = "name=" + name
        features = list(ki_features)
        print("")
        print("## [%s / %s]" % (index, num_kis))
        print("KI name: %s" % name)
        print("KI properties: %s" % name_properties)
        print("KI features: %s" % features)
        createKeyIndicator(ss, kgName, name, name_properties, DEBUG)
        addFeatureToKeyindicator(ss, kgName, name, features, DEBUG)
        setActive(ss, kgName, name, DEBUG)


def loadVarsFromConfigFile(file_path):
    config_vars = {}
    with open(file_path, "r") as file:
        exec(file.read(), config_vars)
    return(config_vars)

if __name__ == "__main__":

    usage = "%(prog)s <config_module_path> <kg_name> [<ss_url>] [options]"
    description = """
        This is a script that creates a set of KI definitions for use in QA 
        testing and validation.  Requires use of the included config modules in
        the included ``ki-*-configs`` directories.  SynIC credentials can be
        passed via the SYNIC_AUTH environment variable, or via the --auth
        argument.
    """
    parser = argparse.ArgumentParser(usage=usage, description=description)
    parser.add_argument("cfg_path", help="config file path")
    parser.add_argument("kg_name", help="name of kg")
    parser.add_argument("ss_url", nargs="?", help="URL of SS",
        default="http://localhost:8999")

    parser.add_argument("--auth", help="username:password for SynIC auth",
        default=os.environ.get('SYNIC_AUTH', LOGIN))
    parser.add_argument("--num_kgs", help="number of kgs to query for (default is %s)" % NUM_KGS,
        default=NUM_KGS)
    parser.add_argument("--debug", action="store_true", default=False,
        help="include debug output")
    args = parser.parse_args()

    args.ss_url = args.ss_url.rstrip("/")

    # keeping these here for simplicity, would be "better" to refactor them out
    DEBUG = args.debug
    LOGIN = args.auth
    NUM_KGS = args.num_kgs
    
    # config file validation
    if not os.path.isfile(args.cfg_path):
        parser.error("Specified config file does not exist")

    cfg_vars = loadVarsFromConfigFile(args.cfg_path)
    if not cfg_vars.get("KEYINDICATORS"):
        parser.error("KEYINDICATORS is undefined in the specified config file.")
        
    if not cfg_vars.get("KI_NAMES"):
        parser.error("KI_NAMES is undefined in the specified config file.")

    # everything checks out - time to create some KIs!
    print("#" * 79)
    print(" Config file         : %s" % args.cfg_path)
    print(" Knowledgegraph      : %s" % args.kg_name)
    print(" Synthesys URL       : %s" % args.ss_url) 
    print(" SSL                 : %s" % args.ss_url.startswith("https"))
    print(" Number of KGs       : %s" % NUM_KGS)
    print(" DEBUG Mode          : %s" % DEBUG)
    print(" SynIC user          : %s" % LOGIN.split(":")[0])
    print("#" * 79)

   
    result = get(args.ss_url, auth=tuple(LOGIN.split(':')), verify=not args.ss_url.startswith("https"))
    try:
        result.raise_for_status()
    except Exception as e:
        stderr.write("Invalid synic configuration: %s\n" % e.message)
        exit(1) 

    addKIcombos(args.ss_url, args.kg_name, cfg_vars['KEYINDICATORS'], cfg_vars['KI_NAMES'], DEBUG)