#!/usr/bin/python

# List of list of key indicators to combine:

KEYINDICATORS = [
   ["node-selector: disclaimerSelector"],
   ["node-selector: quoteHeaderSelector"],
   ["lexicon: gifts_and_entertainment.regex"],
   ["fact-class: Business Transaction"],
   ["lexicon: rationalization.regex"],
   ["lexicon: corruption.regex"],
   ["lexicon: corruption.clex"],
#["node-selector: Something1", "node-selector: Something2", "node-selector: Something3"],
]

# KeyIndicator feature shortcuts. Used to name the KeyIndicators.

KI_NAMES = [
   ["Disclaimer"],
   ["Quote Header"],
   ["G and E"],
   ["Business Transaction Fact"],
   ["Rationalization"],
   ["Corruption"],
   ["Corruption Clex"],
]