'''Script to search alerts and export their fields to a CSV file.'''
import argparse
import json
import time
import concurrent.futures
import os
import csv
import copy
import cs_common as cs
from cs_common import AppLogger
from es_client import ESClient

#
# Script to search for messages and alerts and change their permissions.
#
#  - The ES query template is read from a JSON file to search for messages. More filters can be added to it.
#  - For ES 7.x, the query must contain a "bool" query inside the "query" section so a "doc_type" filter can be added by the script. 
#  - "size", "sort", "_source", and "inner_hits" are set by the script and must not be set in the JSON query file.
#  - This is written for ES 5.x and ES 7.x.
#
# Usage: 
#   Search for messages and alerts that contain user1@test.com or user2@test.com email addresses as either a sender or recipient
#   and message permissions MPERM1 or MPERM2 or alert permissions APERM1 or APERM2.
#
#   python3 csurv_change_perms.py test_kg "user1@test.com,user2@test.com" "MPERM1,MPERM2" "MPERM3,MPERM4,MPERM5"  "APERM1,APERM2" "APERM3" find_messages_template.json
#
#   Search for messages and alerts that contain user1@test.com or user2@test.com email addresses as either a sender or recipient
#   and message permissions MPERM1 or MPERM2 or alert permissions APERM1 or APERM2. Remove message permissions MPERM1 and MPERM2,
#   alert permissions APERM1 and APERM2 and add message permissions MPERM3, MPERM4, and MPERM5 and add alert permission APERM3
#   to the matching messages and alerts.
#
#   python3 csurv_change_perms.py --update test_kg "user1@test.com,user2@test.com" "MPERM1,MPERM2" "MPERM3,MPERM4,MPERM5"  "APERM1,APERM2" "APERM3" find_messages_template.json
#

#
# Constants
#
CSV_HEADERS                 = [ '_index',
                                '_type',
                                '_id']
                               
INDEX_PATTERN               = '__message_types_*20*'

JSON_MESSAGE_DOC_TYPE_FILTER    = '{"term":{"doc_type":"' + cs.DOC_TYPE_MESSAGE + '"}}'
JSON_TRACK_TOTAL_HITS           = '{"track_total_hits":true}'
JSON_SLICE                      = '{"slice":{"id":-1,"max":""}}'  
JSON_SIZE                       = '{"size":""}'
JSON_SORT                       = '{"sort":["_doc"]}'
JSON_SCROLL_BODY                = '{"scroll":"","scroll_id":""}'
OUTPUT_FILE                     = 'matched_records.csv'

OPTION_UPDATE                   = '--update'
ENV_UPDATE                      = 'UPDATE'
DEFAULT_UPDATE                  = False
HELP_UPDATE                     = 'If set, execute the update. Otherwise, list the records to be updated.'
HELP_UPDATE                     += cs.get_env_and_default(ENV_UPDATE, default_value=DEFAULT_UPDATE)

def get_messages_search(es_client, slice_id, query_body, index_pattern, es_scroll_timeout):
    '''Get the initial batch of messages for a slice.'''
    
    if es_client.is_es5():
        request_url = '/' + index_pattern + '/' + cs.DOC_TYPE_MESSAGE + '/' + '_search' + '?scroll=' + es_scroll_timeout
    else:
        request_url = '/' + index_pattern + '/' + '_search' + '?scroll=' + es_scroll_timeout
        
    # Update the slice_id.       
    query_body['slice']['id'] = slice_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
    
    return response.json()

def get_messages_scroll(es_client, scroll_id, query_body, es_scroll_timeout):
    '''Get a subsequent batch of messages with the scroll_id.'''
  
    request_url = "/" + "_search/scroll"
    
    # Update the scroll.
    query_body['scroll'] = es_scroll_timeout
    query_body['scroll_id'] = scroll_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
    
    return response.json()

def bulk_update_records(es_client, bulk_cmd):
    '''Bulk update the records.'''

    request_url = '/_bulk'
                    
    return es_client.es_post_request(request_url, bulk_cmd)

def check_perms(perms_to_check, perms):
    '''Check if any perms to check are in the perms.'''
    return any(item in perms for item in perms_to_check)
    
def update_perms(perms, to_remove, to_add):
    '''Remove and add perms.'''
    # Remove items
    updated = [item for item in perms if item not in to_remove]
    # Add new items, avoiding duplicates
    for item in to_add:
        if item not in updated:
            updated.append(item)
    return updated
                  
def process_slice(es_client, slice_id, csv_writer, query_body, scroll_body, index_pattern, alert_perms_to_remove, alert_perms_to_add, msg_perms_to_remove, msg_perms_to_add, es_scroll_timeout, update, logger, logging_status_interval):
    '''Search for messages in one slice.'''
    last_status = time.time()
    stats_count = 0
    total_msgs = 0
    updated_msgs = 0
    updated_alerts = 0
    
    logger.info('Slice[%d] Starting search...', slice_id)
    
    results = get_messages_search(es_client, slice_id, query_body, index_pattern, es_scroll_timeout)
    
    failed_shards = results['_shards']['failed']
    
    if failed_shards != 0:
        logger.error('Could not search messages. Shards failed: %d', failed_shards)
        os._exit(1)
        
    if es_client.is_es5():
        total_hits = results['hits']['total']
    else:
        total_hits = results['hits']['total']['value']
    
    logger.info('Slice[%d] Total hits: %d', slice_id, total_hits)
    
    hits = results['hits']['hits']
      
    while total_hits > 0 and len(hits) > 0:
        bulk_body = ''
        bulk_count = 0
        
        # Check a batch of hits for a match.
        for hit in hits:
            _id = hit['_id']
            parent = _id
            _index = hit['_index']
            source = hit['_source'] 
                        
            data_permissions = source.get('data_permissions', [])
            
            if check_perms(msg_perms_to_remove, data_permissions):
                logger.debug('Original message data_permissions: %s', data_permissions) 
                data_permissions = update_perms(data_permissions, msg_perms_to_remove, msg_perms_to_add)
                logger.debug('Updated message data_permissions: %s', data_permissions) 
            else: 
                data_permissions = None
                
            if 'key_indicators' in source:
                found_one = False
                key_indicators = source['key_indicators']
                for ki in key_indicators:
                    alert_data_permissions = ki.get('alert_data_permissions', [])
                    if check_perms(alert_perms_to_remove, alert_data_permissions):
                        logger.debug('Original message ki: %s, alert_data_permissions: %s', ki['key_indicator_id'], alert_data_permissions) 
                        alert_data_permissions = update_perms(alert_data_permissions, alert_perms_to_remove, alert_perms_to_add)
                        ki['alert_data_permissions'] = alert_data_permissions
                        logger.debug('Updated message ki: %s, alert_data_permissions: %s', ki['key_indicator_id'], alert_data_permissions)   
                        found_one = True  
                        
                if not found_one:
                    key_indicators = None                                                       
            else:
                key_indicators = None
             
            if 'ghost_key_indicators' in source:
                found_one = False
                ghost_key_indicators = source['ghost_key_indicators']
                for ki in ghost_key_indicators:
                    alert_data_permissions = ki.get('alert_data_permissions', [])
                    if check_perms(alert_perms_to_remove, alert_data_permissions):
                        logger.debug('Original message ghost ki: %s, alert_data_permissions: %s', ki['name'], alert_data_permissions) 
                        alert_data_permissions = update_perms(alert_data_permissions, alert_perms_to_remove, alert_perms_to_add)  
                        ki['alert_data_permissions'] = alert_data_permissions
                        logger.debug('Updated message ghost ki: %s, alert_data_permissions: %s', ki['name'], alert_data_permissions) 
                        found_one = True  
                        
                if not found_one:
                    ghost_key_indicators = None                                                       
            else:
                ghost_key_indicators = None
                   
            if data_permissions is not None or key_indicators is not None or ghost_key_indicators is not None:
                update_obj = {}
                update_obj['_id'] = _id
                if es_client.is_es5():
                    update_obj['_type'] = cs.DOC_TYPE_MESSAGE
                elif es_client.is_es7():
                    update_obj['_type'] = cs.DOC_TYPE_DOC
                update_obj['_index'] = _index
                
                update_cmd = {}
                update_cmd['update'] = update_obj
                        
                doc = {}
                
                if data_permissions is not None:
                    doc['data_permissions'] = data_permissions
                    
                if key_indicators is not None:
                    doc['key_indicators'] = key_indicators
                    
                if ghost_key_indicators is not None:
                    doc['ghost_key_indicators'] = ghost_key_indicators
                 
                update_doc = {}
                update_doc['doc'] = doc
                
                bulk_cmd = json.dumps(update_cmd)
                bulk_doc = json.dumps(update_doc)
                
                logger.debug('Update message cmd: %s, doc: %s', bulk_cmd, bulk_doc)
                
                if update:
                    bulk_body += bulk_cmd + '\n' + bulk_doc + '\n'
                    bulk_count += 1
                csv_writer.writerow([_index, 'message', _id])
                updated_msgs += 1
                  
            inner_hits = hit['inner_hits']['alert_status']['hits']['hits']            
            
            for inner_hit in inner_hits:
                _id = inner_hit['_id']
                inner_source = inner_hit['_source']
                                    
                logger.debug('inner_hit: %s', inner_hit)
               
                message_data_permissions = inner_source.get('message_data_permissions', [])
                                           
                if check_perms(msg_perms_to_remove, message_data_permissions):
                    logger.debug('Original alert_status message_data_permissions: %s', message_data_permissions) 
                    message_data_permissions = update_perms(message_data_permissions, msg_perms_to_remove, msg_perms_to_add)
                    logger.debug('Updated alert_status message_data_permissions: %s', message_data_permissions)
                else: 
                    message_data_permissions = None
                 
                alert_data_permissions = inner_source.get('alert_data_permissions', [])
                                           
                if check_perms(alert_perms_to_remove, alert_data_permissions):
                    logger.debug('Original alert_status ki: %s, alert_data_permissions: %s', inner_source['key_indicator_id'], alert_data_permissions)
                    alert_data_permissions = update_perms(alert_data_permissions, alert_perms_to_remove, alert_perms_to_add)
                    logger.debug('Updated alert_status ki: %s, alert_data_permissions: %s', inner_source['key_indicator_id'], alert_data_permissions)
                else: 
                    alert_data_permissions = None
                
                if message_data_permissions is not None or alert_data_permissions is not None:
                    update_obj = {}
                    update_obj['_id'] = _id
                    if es_client.is_es5():
                        update_obj['_type'] = cs.DOC_TYPE_ALERT_STATUS
                    elif es_client.is_es7():
                        update_obj['_type'] = cs.DOC_TYPE_DOC
                    update_obj['_index'] = _index
                    if es_client.is_es5():
                        update_obj['_parent'] = parent
                        update_obj['_routing'] = parent
                    elif es_client.is_es7():
                        update_obj['routing'] = parent
                    
                    update_cmd = {}
                    update_cmd['update'] = update_obj
                
                    doc = {}
                    
                    if message_data_permissions is not None:
                        doc['message_data_permissions'] = message_data_permissions
                        
                    if alert_data_permissions is not None:
                        doc['alert_data_permissions'] = alert_data_permissions
                        
                    update_doc = {}
                    update_doc['doc'] = doc
                    
                    bulk_cmd = json.dumps(update_cmd)
                    bulk_doc = json.dumps(update_doc)
                    
                    logger.debug('Update alert_status cmd: %s, doc: %s', bulk_cmd, bulk_doc)
                    
                    if update:
                        bulk_body += bulk_cmd + '\n' + bulk_doc + '\n'
                        bulk_count += 1
                    csv_writer.writerow([_index, 'alert_status', _id])
                    updated_alerts += 1                                  
            
            stats_count += 1
            total_msgs += 1
    
        if update and bulk_body is not '':
            created, indexed, deleted, not_found = bulk_update_records(es_client, bulk_body)
            logger.debug('Bulk created: %d, indexed: %d, deleted: %d, not_found: %d', created, indexed, deleted, not_found)
            if indexed != bulk_count:
                logger.error('Not all records updated. bulk size: %d, indexed: %d', bulk_count, indexed)             
            bulk_body = ''
            bulk_count = 0
            
        scroll_id = results['_scroll_id']
                
        cur_time = time.time()
        if cur_time - last_status >= logging_status_interval:
            exec_time = cur_time - last_status
            docs_per_sec = stats_count / exec_time if stats_count > 0 else 0
            logger.info('Slice[%d] Processed: %d - %s, docs/sec: %.0f', 
                slice_id, total_msgs, f'{(total_msgs / total_hits):.0%} complete', docs_per_sec)
            
            last_status = cur_time
            stats_count = 0
            
        results = get_messages_scroll(es_client, scroll_id, scroll_body, es_scroll_timeout)
        
        failed_shards = results['_shards']['failed']
    
        if failed_shards != 0:
            logger.error('Could not search messages. Shards failed: %d', failed_shards)
            os._exit(1)
                
        hits = results['hits']['hits']
    
    logger.info('Slice[%d] Completed search, total msgs: %d, %s msgs: %d, alerts: %d', slice_id, total_hits, ('updated' if update else 'can update'), updated_msgs, updated_alerts)
    
    return (total_hits, updated_msgs, updated_alerts)
    
def find_and_fix_perms(es_client, es_slices, es_scroll_timeout, query_body, scroll_body, index_pattern, alert_perms_to_remove, alert_perms_to_add, msg_perms_to_remove, msg_perms_to_add, update, logger, logging_status_interval):
    '''Find and fix perms.'''

    total_msgs = 0
    updated_msgs = 0
    updated_alerts = 0
            
    logger.info('Searching messages with %d slices...', es_slices)
    
    start_exec = time.time()
    with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as output:
        csv_writer = csv.writer(output, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        csv_writer.writerow(CSV_HEADERS)
        logger.debug('CSV_HEADERS: %s', CSV_HEADERS)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=es_slices) as executor:
            futures = []
            for slice_id in range(es_slices):
                futures.append(executor.submit( process_slice, 
                                                es_client=es_client, 
                                                slice_id=slice_id, 
                                                csv_writer=csv_writer, 
                                                query_body=copy.deepcopy(query_body), 
                                                scroll_body=copy.deepcopy(scroll_body), 
                                                index_pattern=index_pattern,
                                                alert_perms_to_remove=alert_perms_to_remove,
                                                alert_perms_to_add=alert_perms_to_add,
                                                msg_perms_to_remove=msg_perms_to_remove,
                                                msg_perms_to_add=msg_perms_to_add,
                                                es_scroll_timeout=es_scroll_timeout,
                                                update=update,
                                                logger=logger,
                                                logging_status_interval=logging_status_interval))
            
            for future in concurrent.futures.as_completed(futures):
                results = future.result() 
                total_msgs += results[0]
                updated_msgs += results[1] 
                updated_alerts += results[2]                
                                         
    end_exec = time.time()    
    exec_time = end_exec - start_exec
    exec_mins = exec_time / 60
    docs_per_sec = total_msgs / exec_time if total_msgs > 0 else 0
    
    logger.info('Found %d messages, %s %d messages, %d alerts in %.2f minutes, docs/sec: %.0f', total_msgs, ('updated' if update else 'can update'), updated_msgs, updated_alerts, exec_mins, docs_per_sec)

def init_query(es_client, query_body, email_addresses, alert_perms_to_remove, msg_perms_to_remove, es_slices, es_search_batch_size):
    '''Initialize the query for slicing and ES 7.'''
    
    # Needed for all ES versions.
    esslice = json.loads(JSON_SLICE)
    esslice['slice']['max'] = es_slices
    query_body.update(esslice) 
    
    if 'size' in query_body:
        raise ValueError('JSON query must not contain the "size" field.')
    
    if 'sort' in query_body:
        raise ValueError('JSON query must not contain the "sort" field.')
    
    size = json.loads(JSON_SIZE)
    size['size'] = es_search_batch_size
    query_body.update(size)    
    query_body.update(json.loads(JSON_SORT))
    
    query_body['query']['bool']['filter'][0]['bool']['should'][0]['nested']['query']['terms']['senders.sender_email_lc'] = email_addresses                                                    
    query_body['query']['bool']['filter'][0]['bool']['should'][1]['nested']['query']['terms']['receivers.receiver_email_lc'] = email_addresses
    query_body['query']['bool']['filter'][1]['bool']['should'][0]['terms']['data_permissions'] = msg_perms_to_remove
    query_body['query']['bool']['filter'][1]['bool']['should'][1]['nested']['query']['terms']['key_indicators.alert_data_permissions'] = alert_perms_to_remove
    query_body['query']['bool']['filter'][1]['bool']['should'][2]['nested']['query']['terms']['ghost_key_indicators.alert_data_permissions'] = alert_perms_to_remove
    query_body['query']['bool']['filter'][1]['bool']['should'][3]['has_child']['query']['bool']['should'][0]['terms']['message_data_permissions'] = msg_perms_to_remove
    query_body['query']['bool']['filter'][1]['bool']['should'][3]['has_child']['query']['bool']['should'][1]['terms']['alert_data_permissions'] = alert_perms_to_remove
       
    if es_client.is_es5(): 
        return query_body
        
    # The following are for ES7+.
    query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))    
      
    # Add doc_type filter.
    query_body['query']['bool']['filter'].append(json.loads(JSON_MESSAGE_DOC_TYPE_FILTER))
    
    return query_body
 
def main():
    '''Start of main.'''    
    parser = argparse.ArgumentParser(description='Change message and alert permissions for email addresses.')
    parser.add_argument('kg_name', help='CSurv KG name.', type=str)
    parser.add_argument('email_addresses', help='Email addresses to search.', type=str)
    parser.add_argument('msg_perms_to_remove', help='Message permissions to search and remove.', type=str)
    parser.add_argument('msg_perms_to_add', help='Message permissions to add.', type=str)
    parser.add_argument('alert_perms_to_remove', help='Alert permissions to search and remove.', type=str)
    parser.add_argument('alert_perms_to_add', help='Alert permissions to add.', type=str)
    parser.add_argument('query_template_file', help='JSON file containing the ES query template.')
    
    parser.add_argument(OPTION_UPDATE, action='store_true', help=HELP_UPDATE)   
    
    parser = ESClient.init_client_args(parser)    
    parser = ESClient.init_scroll_timeout_arg(parser)
    parser = ESClient.init_slices_arg(parser)
    parser = ESClient.init_search_batch_size_arg(parser)
    
    parser = AppLogger.init_file_args(parser)
    
    args = parser.parse_args()
          
    app_logger = AppLogger.create_file_from_args(__file__, args, parser)
    logger = app_logger.get_logger()
    logging_status_interval = app_logger.get_status_interval()
    
    kg_name = args.kg_name
    email_addresses = cs.get_arg_as_lc_list(parser, 'email_addresses', args.email_addresses)
    msg_perms_to_remove = cs.get_arg_as_list(parser, 'msg_perms_to_remove', args.msg_perms_to_remove)
    msg_perms_to_add = cs.get_arg_as_list(parser, 'msg_perms_to_add', args.msg_perms_to_add)
    alert_perms_to_remove = cs.get_arg_as_list(parser, 'alert_perms_to_remove', args.alert_perms_to_remove)
    alert_perms_to_add = cs.get_arg_as_list(parser, 'alert_perms_to_add', args.alert_perms_to_add)
    query_template_file = args.query_template_file
        
    es_scroll_timeout = ESClient.get_scroll_timeout(args)
    es_slices = ESClient.get_slices(parser, args)
    es_search_batch_size = ESClient.get_search_batch_size(parser, args)   
       
    logger.info('Starting...')       
    
    index_pattern = kg_name + INDEX_PATTERN
    
    logger.info('KG name: %s', kg_name)
    logger.info('Email addresses: %s', email_addresses) 
    logger.info('Message permissions to remove: %s', msg_perms_to_remove)
    logger.info('Message permissions to add: %s', msg_perms_to_add)
    logger.info('Alert permissions to remove: %s', alert_perms_to_remove)
    logger.info('Alert permissions to add: %s', alert_perms_to_add)
    logger.info('Query template file: %s', query_template_file)
    logger.info('Index pattern: %s', index_pattern)  
    
    update = cs.get_option_as_bool(args, OPTION_UPDATE, ENV_UPDATE, DEFAULT_UPDATE)    
    logger.info('Update: %s', update)  
          
    es_client = ESClient.create_from_args(args, parser, logger)  
     
    logger.info('ES scroll timeout: %s', es_scroll_timeout)
    logger.info('ES slices: %d', es_slices)
    logger.info('ES search batch size: %d', es_search_batch_size)
    
    with open(query_template_file, 'r', encoding='utf-8') as f:
        query_body = json.load(f)  
        logger.info('Loaded ES query: %s', json.dumps(query_body))
    
    query_body = init_query(es_client, query_body, email_addresses, alert_perms_to_remove, msg_perms_to_remove, es_slices, es_search_batch_size)  
    logger.info('Inited ES query body: %s', json.dumps(query_body))
    
    scroll_body = json.loads(JSON_SCROLL_BODY)
       
    find_and_fix_perms(es_client, es_slices, es_scroll_timeout, query_body, scroll_body, index_pattern, alert_perms_to_remove, alert_perms_to_add, msg_perms_to_remove, msg_perms_to_add, update, logger, logging_status_interval) 
                                       
    logger.info('Done.')                  
    
if __name__ == '__main__':        
    main()
