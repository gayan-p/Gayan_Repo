# csurv-change-perms
This Python3 script will change message and alert permissions on messages and alerts. It will search all messages in a KG looking for
any of the comma-separated "email_addresses" in the "senders.sender_email_lc" and "receivers.receiver_email_lc" fields and any of the
comma-separated "msg_perms_to_remove" in the message's "data_permissions" field or an alert_status' "message_data_permissions" field
or any of the comma-separated "alert_perms_to_remove" in the message's "key_indicators.alert_data_permissions" fields or an 
alert_status' "alert_data_permissions" field.

Note, at least one email address must match, and one message permission or one alert permission must match.

When the "--update" option is used, all message and alert permissions listed in "msg_perms_to_remove" and "alert_perms_to_remove" will be
removed from the matching message and alert_status records. All message and alert permissions listed in "msg_perms_to_add" and "alert_perms_to_add" will be
added to the matching message and alert_status records.

If message PERM1 should be replaced with PERM2 and PERM3 replaced with PERM4, then run the script twice, once with msg_perms_to_remove = PERM1 and msg_perms_to_add = PERM2 
and once with msg_perms_to_remove = PERM3 and msg_perms_to_add = PERM4.
If you run with msg_perms_to_remove = "PERM1,PERM3", a message may contain either PERM1 or PERM3 or both. All fields that have a match will have those permissions removed, 
and PERM2 and PERM4 permissions will be added.

If only message permissions need to be replaced and not alert permissions or vice versa, use an unused permission in *_perms_to_remove and *_perms_to_add. See example below.
```
usage: csurv_change_perms.py [-h] [--update] [--es-host ES_HOST]
                             [--es-user ES_USER] [--es-password ES_PASSWORD]
                             [--es-use-tls] [--es-use-hosts]
                             [--es-use-hostname]
                             [--es-connect-timeout ES_CONNECT_TIMEOUT]
                             [--es-read-timeout ES_READ_TIMEOUT]
                             [--es-scroll-timeout ES_SCROLL_TIMEOUT]
                             [--es-slices ES_SLICES]
                             [--es-search-batch-size ES_SEARCH_BATCH_SIZE]
                             [--logging-level {DEBUG,INFO,WARNING,ERROR}]
                             [--logging-status-interval LOGGING_STATUS_INTERVAL]
                             [--logging-file-name LOGGING_FILE_NAME]
                             [--logging-max-size LOGGING_MAX_SIZE]
                             [--logging-max-files LOGGING_MAX_FILES]
                             kg_name email_addresses msg_perms_to_remove
                             msg_perms_to_add alert_perms_to_remove
                             alert_perms_to_add query_template_file

Change message and alert permissions for email addresses.

positional arguments:
  kg_name               CSurv KG name.
  email_addresses       Email addresses to search.
  msg_perms_to_remove   Message permissions to search and remove.
  msg_perms_to_add      Message permissions to add.
  alert_perms_to_remove
                        Alert permissions to search and remove.
  alert_perms_to_add    Alert permissions to add.
  query_template_file   JSON file containing the ES query template.

optional arguments:
  -h, --help            show this help message and exit
  --update              If set, execute the update. Otherwise, list the
                        records to be updated. (Env: UPDATE, Default: False)
  --es-host ES_HOST     Comma-separated list of ES hosts or IP addresses with
                        optional ports. The default port is 9200. (Env:
                        ES_HOSTS, Default: localhost:9200)
  --es-user ES_USER     ES user name. (Env: ES_USER, Default: elastic)
  --es-password ES_PASSWORD
                        ES password. (Env: ES_PASSWORD, Default: )
  --es-use-tls          If set, use HTTPS for ES connections. Otherwise, use
                        HTTP. (Env: ES_USE_TLS, Default: False)
  --es-use-hosts        If set, use ES_HOSTS for connecting to ES. Otherwise,
                        use the sniffer to discover ES data nodes and only use
                        them for requests. (Env: ES_USE_HOSTS, Default: False)
  --es-use-hostname     If set and sniffing, connect to ES data nodes using
                        their hostname. Otherwise, use their IP address. (Env:
                        ES_USE_HOSTNAME, Default: False)
  --es-connect-timeout ES_CONNECT_TIMEOUT
                        ES connection timeout in seconds. (Env:
                        ES_CONNECT_TIMEOUT, Default: 60)
  --es-read-timeout ES_READ_TIMEOUT
                        ES read timeout in seconds. (Env: ES_READ_TIMEOUT,
                        Default: 300)
  --es-scroll-timeout ES_SCROLL_TIMEOUT
                        ES scroll timeout. (Env: ES_SCROLL_TIMEOUT, Default:
                        5m)
  --es-slices ES_SLICES
                        Number of ES slices/threads to use when searching.
                        (Env: ES_SLICES, Default: 10)
  --es-search-batch-size ES_SEARCH_BATCH_SIZE
                        Batch size for an ES scrolled search request. (Env:
                        ES_SEARCH_BATCH_SIZE, Default: 1000)
  --logging-level {DEBUG,INFO,WARNING,ERROR}
                        Log level. (Env: LOGGING_LEVEL, Default: INFO)
  --logging-status-interval LOGGING_STATUS_INTERVAL
                        Number of seconds between logging status updates.
                        (Env: LOGGING_STATUS_INTERVAL, Default: 20)
  --logging-file-name LOGGING_FILE_NAME
                        Log file path. Parent directories in the path must
                        already exist. (Env: LOGGING_FILE_NAME, Default: None)
  --logging-max-size LOGGING_MAX_SIZE
                        Maximum size in bytes for a log file before rollover.
                        (Env: LOGGING_MAX_SIZE, Default: 10000000)
  --logging-max-files LOGGING_MAX_FILES
                        Maximum number of log files to save. (Env:
                        LOGGING_MAX_FILES, Default: 10)
```
# Examples
Search for messages and alerts that contain user1@test.com or user2@test.com email addresses as either a sender or recipient
and message permissions MPERM1 or MPERM2 or alert permissions APERM1 or APERM2.
```
python3 csurv_change_perms.py test_kg "user1@test.com,user2@test.com" "MPERM1,MPERM2" "MPERM3,MPERM4,MPERM5"  "APERM1,APERM2" "APERM3" find_messages_template.json
```
Search for messages and alerts that contain user1@test.com or user2@test.com email addresses as either a sender or recipient
and message permissions MPERM1 or MPERM2 or alert permissions APERM1 or APERM2. Remove message permissions MPERM1 and MPERM2,
alert permissions APERM1 and APERM2, and add message permissions MPERM3, MPERM4, and MPERM5 and add alert permission APERM3
to the matching messages and alerts.
```
python3 csurv_change_perms.py --update test_kg "user1@test.com,user2@test.com" "MPERM1,MPERM2" "MPERM3,MPERM4,MPERM5"  "APERM1,APERM2" "APERM3" find_messages_template.json
```
Search for messages and alerts that contain the user1@test.com email address as either a sender or recipient, 
and message permission MPERM1. Remove message permission MPERM1 and add message permissions MPERM2 and MPERM3
to the matching messages and alerts. All alert permissions will be ignored.
```
python3 csurv_change_perms.py --update test_kg "user1@test.com,user2@test.com" "MPERM1" "MPERM2,MPERM3"  "ignore_alerts" "ignore_alerts" find_messages_template.json
```

