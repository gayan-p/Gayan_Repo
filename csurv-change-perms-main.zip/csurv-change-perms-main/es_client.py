'''Elasticsearch client for ES 5 and 7.'''

import threading
import urllib3
import requests
import cs_common as cs

class ESRequestError(ValueError):
    '''Error raised when an ES request returns an error.'''
    def __init__(self, message):
        '''Initialize the error.'''
        self.message = message
        super().__init__(self.message)          


class ESClient:  
    '''An ES client.'''
    
    #
    # Constants
    #
    QUERY_HEADERS   = {'Content-Type': 'application/json'}
    BULK_HEADERS    = {'Content-Type': 'application/x-ndjson'}
  
    # Supported ES versions.
    VERSION_ES5 = '5'
    VERSION_ES7 = '7'
    
    # Client options
    OPTION_ES_HOSTS                     = '--es-host'
    OPTION_ES_USER                      = '--es-user'
    OPTION_ES_PASSWORD                  = '--es-password'
    OPTION_ES_USE_TLS                   = '--es-use-tls'
    OPTION_ES_USE_HOSTS                 = '--es-use-hosts'
    OPTION_ES_USE_HOSTNAME              = '--es-use-hostname'
    OPTION_ES_CONNECT_TIMEOUT           = '--es-connect-timeout'
    OPTION_ES_READ_TIMEOUT              = '--es-read-timeout'   
    
    ENV_ES_HOSTS                        = 'ES_HOSTS'
    ENV_ES_USER                         = 'ES_USER'
    ENV_ES_PASSWORD                     = 'ES_PASSWORD'
    ENV_ES_USE_TLS                      = 'ES_USE_TLS'
    ENV_ES_USE_HOSTS                    = 'ES_USE_HOSTS'
    ENV_ES_USE_HOSTNAME                 = 'ES_USE_HOSTNAME'
    ENV_ES_CONNECT_TIMEOUT              = 'ES_CONNECT_TIMEOUT'
    ENV_ES_READ_TIMEOUT                 = 'ES_READ_TIMEOUT'

    DEFAULT_ES_HOSTS                    = 'localhost:9200'
    DEFAULT_ES_PORT                     = 9200
    DEFAULT_ES_USER                     = 'elastic'
    DEFAULT_ES_PASSWORD                 = ''
    DEFAULT_ES_USE_TLS                  = False
    DEFAULT_ES_USE_HOSTS                = False
    DEFAULT_ES_USE_HOSTNAME             = False
    DEFAULT_ES_CONNECT_TIMEOUT          = 60
    DEFAULT_ES_READ_TIMEOUT             = 300

    MIN_ES_CONNECT_TIMEOUT              = 1
    MIN_ES_READ_TIMEOUT                 = 1

    HELP_ES_HOSTS                       = 'Comma-separated list of ES hosts or IP addresses with optional ports. The default port is ' + str(DEFAULT_ES_PORT) + '.'
    HELP_ES_USER                        = 'ES user name.'
    HELP_ES_PASSWORD                    = 'ES password.'
    HELP_ES_USE_TLS                     = 'If set, use HTTPS for ES connections. Otherwise, use HTTP.'
    HELP_ES_USE_HOSTS                   = 'If set, use ES_HOSTS for connecting to ES. Otherwise, use the sniffer to discover ES data nodes and only use them for requests.'
    HELP_ES_USE_HOSTNAME                = 'If set and sniffing, connect to ES data nodes using their hostname. Otherwise, use their IP address.'
    HELP_ES_CONNECT_TIMEOUT             = 'ES connection timeout in seconds.'
    HELP_ES_READ_TIMEOUT                = 'ES read timeout in seconds.'

    HELP_ES_HOSTS                       += cs.get_env_and_default(ENV_ES_HOSTS, default_value=DEFAULT_ES_HOSTS)
    HELP_ES_USER                        += cs.get_env_and_default(ENV_ES_USER, default_value=DEFAULT_ES_USER)
    HELP_ES_PASSWORD                    += cs.get_env_and_default(ENV_ES_PASSWORD, default_value=DEFAULT_ES_PASSWORD)
    HELP_ES_USE_TLS                     += cs.get_env_and_default(ENV_ES_USE_TLS, default_value=DEFAULT_ES_USE_TLS)
    HELP_ES_USE_HOSTS                   += cs.get_env_and_default(ENV_ES_USE_HOSTS, default_value=DEFAULT_ES_USE_HOSTS)
    HELP_ES_USE_HOSTNAME                += cs.get_env_and_default(ENV_ES_USE_HOSTNAME, default_value=DEFAULT_ES_USE_HOSTNAME)
    HELP_ES_CONNECT_TIMEOUT             += cs.get_env_and_default(ENV_ES_CONNECT_TIMEOUT, default_value=DEFAULT_ES_CONNECT_TIMEOUT)
    HELP_ES_READ_TIMEOUT                += cs.get_env_and_default(ENV_ES_READ_TIMEOUT, default_value=DEFAULT_ES_READ_TIMEOUT)

    # Other ES options
    OPTION_ES_SCROLL_TIMEOUT            = '--es-scroll-timeout'
    OPTION_ES_SLICES                    = '--es-slices'
    OPTION_ES_SEARCH_BATCH_SIZE         = '--es-search-batch-size'
    
    ENV_ES_SCROLL_TIMEOUT               = 'ES_SCROLL_TIMEOUT'
    ENV_ES_SLICES                       = 'ES_SLICES'
    ENV_ES_SEARCH_BATCH_SIZE            = 'ES_SEARCH_BATCH_SIZE'
    
    DEFAULT_ES_SCROLL_TIMEOUT           = '5m'
    DEFAULT_ES_SLICES                   = 10
    DEFAULT_ES_SEARCH_BATCH_SIZE        = 1000
    
    MIN_ES_SLICES                       = 1
    MIN_ES_SEARCH_BATCH_SIZE            = 1
    
    HELP_ES_SCROLL_TIMEOUT              = 'ES scroll timeout.'
    HELP_ES_SLICES                      = 'Number of ES slices/threads to use when searching.'
    HELP_ES_SEARCH_BATCH_SIZE           = 'Batch size for an ES scrolled search request.'
    
    HELP_ES_SCROLL_TIMEOUT              += cs.get_env_and_default(ENV_ES_SCROLL_TIMEOUT, default_value=DEFAULT_ES_SCROLL_TIMEOUT)
    HELP_ES_SLICES                      += cs.get_env_and_default(ENV_ES_SLICES, default_value=DEFAULT_ES_SLICES)
    HELP_ES_SEARCH_BATCH_SIZE           += cs.get_env_and_default(ENV_ES_SEARCH_BATCH_SIZE, default_value=DEFAULT_ES_SEARCH_BATCH_SIZE)
    
    def __init__(self, nodes, user, password,  use_tls, use_hostname, connect_timeout, read_timeout, logger):
        '''Internal constructor for the ES client.'''
        
        self._nodes_lock = threading.Lock() 
        self._nodes = nodes
        self._next_node = 0
        self._user = user
        self._password = password
        self._use_tls = use_tls
        self._use_hostname = use_hostname
        self._connect_timeout = connect_timeout
        self._read_timeout = read_timeout   
        self._logger = logger
        self._version = None        
      
    @staticmethod
    def init_client_args(parser):
        '''Initialize ES client options.'''
        parser.add_argument(ESClient.OPTION_ES_HOSTS, type=str, help=ESClient.HELP_ES_HOSTS)
        parser.add_argument(ESClient.OPTION_ES_USER, type=str, help=ESClient.HELP_ES_USER)
        parser.add_argument(ESClient.OPTION_ES_PASSWORD, type=str, help=ESClient.HELP_ES_PASSWORD)
        parser.add_argument(ESClient.OPTION_ES_USE_TLS, action='store_true', help=ESClient.HELP_ES_USE_TLS)    
        parser.add_argument(ESClient.OPTION_ES_USE_HOSTS, action='store_true', help=ESClient.HELP_ES_USE_HOSTS)  
        parser.add_argument(ESClient.OPTION_ES_USE_HOSTNAME, action='store_true', help=ESClient.HELP_ES_USE_HOSTNAME)  
        parser.add_argument(ESClient.OPTION_ES_CONNECT_TIMEOUT, type=int, help=ESClient.HELP_ES_CONNECT_TIMEOUT)  
        parser.add_argument(ESClient.OPTION_ES_READ_TIMEOUT, type=int, help=ESClient.HELP_ES_READ_TIMEOUT)  
        
        return parser
        
    @staticmethod
    def init_scroll_timeout_arg(parser):
        '''Initialize scroll timeout option.'''
        parser.add_argument(ESClient.OPTION_ES_SCROLL_TIMEOUT, type=int, help=ESClient.HELP_ES_SCROLL_TIMEOUT)        
        return parser
    
    @staticmethod
    def init_slices_arg(parser):
        '''Initialize slices option.'''
        parser.add_argument(ESClient.OPTION_ES_SLICES, type=int, help=ESClient.HELP_ES_SLICES)          
        return parser
    
    @staticmethod
    def init_search_batch_size_arg(parser):
        '''Initialize search batch size option.'''
        parser.add_argument(ESClient.OPTION_ES_SEARCH_BATCH_SIZE, type=int, help=ESClient.HELP_ES_SEARCH_BATCH_SIZE)          
        return parser
      
    @staticmethod
    def get_scroll_timeout(args): 
        '''Get the scroll timeout option.'''
        return cs.get_option_as_str(args, ESClient.OPTION_ES_SCROLL_TIMEOUT, ESClient.ENV_ES_SCROLL_TIMEOUT, default_value=ESClient.DEFAULT_ES_SCROLL_TIMEOUT)
    
    @staticmethod
    def get_slices(parser, args):
        '''Get the slices option.'''
        return cs.get_option_as_int(parser, args, ESClient.OPTION_ES_SLICES, ESClient.ENV_ES_SLICES, ESClient.DEFAULT_ES_SLICES, ESClient.MIN_ES_SLICES)
    
    @staticmethod
    def get_search_batch_size(parser, args):
        '''Get the search batch size option.'''
        return cs.get_option_as_int(parser, args, ESClient.OPTION_ES_SEARCH_BATCH_SIZE, ESClient.ENV_ES_SEARCH_BATCH_SIZE, ESClient.DEFAULT_ES_SEARCH_BATCH_SIZE, ESClient.MIN_ES_SEARCH_BATCH_SIZE)
     
    @staticmethod
    def create_from_args(args, parser, logger):
        '''Create an ES client from the options.'''
        # Options
        es_hosts = cs.get_option_as_str(args, ESClient.OPTION_ES_HOSTS, ESClient.ENV_ES_HOSTS, default_value=ESClient.DEFAULT_ES_HOSTS)
        es_user = cs.get_option_as_str(args, ESClient.OPTION_ES_USER, ESClient.ENV_ES_USER, default_value=ESClient.DEFAULT_ES_USER)
        es_password = cs.get_option_as_str(args, ESClient.OPTION_ES_PASSWORD, ESClient.ENV_ES_PASSWORD, default_value=ESClient.DEFAULT_ES_PASSWORD)
        es_use_tls = cs.get_option_as_bool(args, ESClient.OPTION_ES_USE_TLS, ESClient.ENV_ES_USE_TLS, ESClient.DEFAULT_ES_USE_TLS)
        es_use_hosts = cs.get_option_as_bool(args, ESClient.OPTION_ES_USE_HOSTS, ESClient.ENV_ES_USE_HOSTS, ESClient.DEFAULT_ES_USE_HOSTS)
        es_use_hostname = cs.get_option_as_bool(args, ESClient.OPTION_ES_USE_HOSTNAME, ESClient.ENV_ES_USE_HOSTNAME, ESClient.DEFAULT_ES_USE_HOSTNAME)
        es_connect_timeout = cs.get_option_as_int(parser, args, ESClient.OPTION_ES_CONNECT_TIMEOUT, ESClient.ENV_ES_CONNECT_TIMEOUT, ESClient.DEFAULT_ES_CONNECT_TIMEOUT, ESClient.MIN_ES_CONNECT_TIMEOUT)
        es_read_timeout = cs.get_option_as_int(parser, args, ESClient.OPTION_ES_READ_TIMEOUT, ESClient.ENV_ES_READ_TIMEOUT, ESClient.DEFAULT_ES_READ_TIMEOUT, ESClient.MIN_ES_READ_TIMEOUT)
        
        return ESClient.create(es_hosts, es_user, es_password, es_use_tls, es_use_hosts, es_use_hostname, es_connect_timeout, es_read_timeout, logger)
        
    @staticmethod
    def create(initial_hosts, user, password, use_tls, use_hosts, use_hostname, connect_timeout, read_timeout, logger):
        '''Create an ES client.'''
        
        logger.info('ES hosts: %s', initial_hosts)
        logger.info('ES user: %s', user)
        logger.info('ES password: %s', ''.rjust(len(password),'*'))
        logger.info('ES use TLS: %s', use_tls)
        logger.info('ES use hosts: %s', use_hosts)
        logger.info('ES use hostname: %s', use_hostname)
        logger.info('ES connect timeout: %d', connect_timeout)
        logger.info('ES read timeout: %d', read_timeout)
        
        # Silence https warnings
        urllib3.disable_warnings(category = urllib3.exceptions.InsecureRequestWarning)
        #requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
        
        initial_hosts = initial_hosts.split(',')
         
        data_nodes = []   
        coord_nodes = []   
        requested_nodes = []
        
        # Try all of the initial hosts.
        for initial_host in initial_hosts:
            
            try:
                logger.debug('Trying initial host: %s', initial_host)
                
                # Add the default port if the port is not present.
                host_and_port = initial_host if ':' in initial_host else initial_host + ':' + str(ESClient.DEFAULT_ES_PORT)
                    
                base_url = f'http{"s" if use_tls else ""}://{host_and_port}'
                
                url = base_url + '/_nodes/http'
            
                logger.debug('ES get hosts: %s', url)
            
                response = requests.get(
                    url,
                    auth=(user, password),
                    verify=False,
                    timeout=(connect_timeout, read_timeout)
                )
                
                if response.status_code != requests.codes.ok: # pylint: disable=E1101
                    logger.error('ES GET error: %s', response.json())
                    raise ESRequestError(f'ES GET error: {response.json()}')
                        
                results = response.json()
                
                # If using sniffer, save the data hosts.
                if use_hosts is False:
                    for node in results['nodes'].values():    
                        host = node['host']
                        ip = node['ip']
                        roles = node['roles']
                        
                        # Get the port from the published_address.
                        if 'published_address' in node['http'] and ':' in node['http']['published_address']:
                            _, port_part = node['http']['published_address'].split(':')
                            port = int(port_part)
                            logger.debug('Using published port: %d', port)
                        else:
                            port = ESClient.DEFAULT_ES_PORT
                            logger.debug('Using default port: %d', port)
                                
                        # Check for a dedicated coordinator.
                        if 'master' not in roles and 'data' not in roles:  
                            # Save the host/IP plus port.
                            coord_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                            logger.debug('Saving coordinating node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                                 
                        elif 'data' in node['roles']:                                                  
                            # Save the host/IP plus port.
                            data_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                            logger.debug('Saving data node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                        
                        else:
                            logger.debug('Non-data or coordinating node: %s', node)
                        
                    if len(data_nodes) > 0 or len(coord_nodes) > 0:
                        break
                else:
                    # No sniffer, use as-is.
                    requested_nodes.append((host_and_port, host_and_port))
                        
            except requests.ConnectionError as ce:
                logger.warn('Could not connect to configured ES host: %s', ce) 
             
        # Check if there is at least one coordinating node available.
        if len(requested_nodes) > 0:
            nodes = requested_nodes
            node_type = 'requested'
        if len(coord_nodes) > 0:
            nodes = coord_nodes
            node_type = 'coordinating'
        else:
            nodes = data_nodes
            node_type = 'data'
            
        if len(nodes) == 0:
            if use_hosts is False:
                logger.error('No ES data or coordinating nodes are available.')
                raise ESRequestError('No ES data or coordinating nodes are available.') 
            
            logger.error('Configured ES hosts are not available.')
            raise ESRequestError('Configured ES hosts are not available.')          
        
        logger.info('ES hosts available: %d, type: %s', len(nodes), node_type)
        
        client = ESClient(nodes, user, password,  use_tls, use_hostname, connect_timeout, read_timeout, logger)
          
        client.init_es_version()  
        
        logger.info('ES version: %s', client.get_version())
        
        return client 
        
    def _get_next_node(self):
        '''Internal method to return the next node in the list.'''
        with self._nodes_lock:    
            node = self._nodes[self._next_node] 
            self._next_node += 1
            if self._next_node >= len(self._nodes):
                self._next_node = 0        
        
        return node[0] if self._use_hostname else node[1]
        
    def init_es_version(self):
        '''Internal method to initialize the ES version and check if it is supported.'''
        
        request_url = "/"
        
        response = self.es_get_request(request_url, None)
        
        result = response.json()
        version_number = result['version']['number']
        version = version_number.split('.')[0]  
       
        if version is None or version not in (ESClient.VERSION_ES5, ESClient.VERSION_ES7):
            self._logger.error('Unsupported ES version: %s', version_number)
            raise ESRequestError(f'Unsupported ES version: {version_number}')     
            
        self._version = version 
     
    def get_version(self):
        '''Get the ES version.'''
        return self._version
        
    def is_es5(self):
        '''Return True if ES version 5.'''
        return self._version == ESClient.VERSION_ES5
        
    def is_es7(self):
        '''Return True if ES version 7.'''
        return self._version == ESClient.VERSION_ES7
           
    def check_response(self, response):
        '''Check a no results response for errors.'''
        
        self._logger.debug('check_response status_code: %s', response.status_code)
        if response.status_code == requests.codes.ok: # pylint: disable=E1101
            return True
        
        if response.status_code == requests.codes.not_found: # pylint: disable=E1101
            return False
            
        self._logger.error('ES request error: %s', response.json())
        raise ESRequestError(f'ES request error: {response.json()}')     
    
    def check_get_response(self, response):
        '''Check GET response for errors.'''
        
        self._logger.debug('check_get_response status_code: %s', response.status_code)
        if response.status_code == requests.codes.ok: # pylint: disable=E1101
            return response
        
        self._logger.error('ES GET error: %s', response.json())
        raise ESRequestError(f'ES GET error: {response.json()}')      
    
    def check_post_response(self, response):
        '''Check POST with results response for errors.'''
        
        if response.status_code != requests.codes.ok: # pylint: disable=E1101
            self._logger.error('ES POST error: %s', response.json())
            raise ESRequestError(f'ES POST error: {response.json()}')   
            
        json_response = response.json()
        
        self._logger.debug('response: %s', json_response)
        
        created = 0
        indexed = 0
        deleted = 0
        not_found = 0
        
        for item in json_response['items']:
            if 'create' in item:
                item_status = item['create']
            elif 'index' in item:
                item_status = item['index']
            elif 'update' in item:
                item_status = item['update']
            elif 'delete' in item:
                item_status = item['delete']
            else:
                self._logger.warn('Unexpected item in the bulk response: %s', item)
                continue
            
            self._logger.debug('item_status: %s', item_status)
            
            status = item_status['status']
            result = item_status['result']
            _id = item_status['_id']
            _index = item_status['_index']
                
            if status == requests.codes.created and result == 'created': # pylint: disable=E1101
                self._logger.debug('Record created. _id: %s, _index: %s', _id, _index)
                created += 1
                      
            elif status == requests.codes.ok and result == 'updated': # pylint: disable=E1101
                self._logger.debug('Record updated. _id: %s, _index: %s', _id, _index)
                indexed += 1
                      
            elif status == requests.codes.ok and result == 'deleted': # pylint: disable=E1101
                self._logger.debug('Record deleted. _id: %s, _index: %s', _id, _index)
                deleted += 1
                      
            elif status == requests.codes.not_found and result == 'not_found': # pylint: disable=E1101
                self._logger.debug('Record not found. _id: %s, _index: %s', _id, _index)
                not_found += 1
                    
            else:
                error = item_status.get('error', 'N/A')
                self._logger.error('Bulk command failed - _id: %s, _index: %s, status: %d, result: %s, error: %s', _id, _index, status, result, error)
                raise ESRequestError(f'Bulk command failed - _id: {_id}, _index: {_index}, status: {status}, result: {result}, error: {error}')
                
        return created, indexed, deleted, not_found
    
    def es_head_request(self, request_url):
        '''ES HEAD request.'''
                  
        for _ in range(len(self._nodes)):
            next_host = self._get_next_node()
            
            try: 
                url = f'http{"s" if self._use_tls else ""}://{next_host}' + request_url
                 
                self._logger.debug('ES HEAD URL: %s', url)
                
                response = requests.head(
                    url,
                    auth=(self._user, self._password),
                    verify=False,
                    timeout=(self._connect_timeout, self._read_timeout)
                )
                
                return self.check_response(response)
            except requests.ConnectionError as ce:
                self._logger.warn('Could not connect to ES: %s', ce)
                
        self._logger.error('ES HEAD request failed. Could not connect to any ES host. Request: %s', url)
        raise ESRequestError(f'ES HEAD request failed. Could not connect to any ES host. Request: {url}')  
            
    def es_get_request(self, request_url, es_body):
        '''ES GET request.'''
        
        for _ in range(len(self._nodes)):  
            next_host = self._get_next_node()
                
            try:
                url = f'http{"s" if self._use_tls else ""}://{next_host}' + request_url
                 
                self._logger.debug('ES GET URL: %s', url)
                self._logger.debug('ES GET body: %s', es_body)
                
                response = requests.get(
                    url,
                    auth=(self._user, self._password),
                    verify=False,
                    timeout=(self._connect_timeout, self._read_timeout),
                    data=es_body,
                    headers=ESClient.QUERY_HEADERS                
                )
                #self._logger.info('RESPONSE: %s', response)
                return self.check_get_response(response)
            except requests.ConnectionError as ce:
                self._logger.warn('Could not connect to ES: %s', ce)
                
        self._logger.error('ES GET request failed. Could not connect to any ES host. Request: %s', url)
        raise ESRequestError(f'ES GET request failed. Could not connect to any ES host. Request: {url}')
            
    def es_post_request(self, request_url, es_body):
        '''ES POST request.'''
        
        for _ in range(len(self._nodes)):  
            next_host = self._get_next_node()
                
            try:
                url = f'http{"s" if self._use_tls else ""}://{next_host}' + request_url
       
                self._logger.debug('ES POST URL: %s', url)
                self._logger.debug('ES POST body: %s', es_body)
                
                response = requests.post(
                    url,
                    auth=(self._user, self._password),
                    verify=False,
                    timeout=(self._connect_timeout, self._read_timeout),
                    data=es_body,
                    headers=ESClient.BULK_HEADERS
                )
                return self.check_post_response(response)
                
            except requests.ConnectionError as ce:
                self._logger.warn('Could not connect to ES: %s', ce)
                
        self._logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
        raise ESRequestError(f'ES POST request failed. Could not connect to any ES host. Request: {url}')
    
    def es_post_no_body_request(self, request_url):
        '''POST with no body or return results.'''
        
        for _ in range(len(self._nodes)):  
            next_host = self._get_next_node()
                
            try:
                url = f'http{"s" if self._use_tls else ""}://{next_host}' + request_url
       
                self._logger.debug('ES POST URL: %s', url)
                
                response = requests.post(
                    url,
                    auth=(self._user, self._password),
                    verify=False,
                    timeout=(self._connect_timeout, self._read_timeout)
                )
                return self.check_response(response)
                
            except requests.ConnectionError as ce:
                self._logger.warn('Could not connect to ES: %s', ce)
                
        self._logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
        raise ESRequestError(f'ES POST request failed. Could not connect to any ES host. Request: {url}')
    
    def es_delete_request(self, request_url):   
        '''ES DELETE request.'''
           
        for _ in range(len(self._nodes)):
            next_host = self._get_next_node()
            
            try: 
                url = f'http{"s" if self._use_tls else ""}://{next_host}' + request_url
                 
                self._logger.debug('ES DELETE URL: %s', url)
                
                response = requests.delete(
                    url,
                    auth=(self._user, self._password),
                    verify=False,
                    timeout=(self._connect_timeout, self._read_timeout)
                )
                
                return self.check_response(response)
            except requests.ConnectionError as ce:
                self._logger.warn('Could not connect to ES: %s', ce)
                
        self._logger.error('ES DELETE request failed. Could not connect to any ES host. Request: %s', url)
        raise ESRequestError(f'ES DELETE request failed. Could not connect to any ES host. Request: {url}')
