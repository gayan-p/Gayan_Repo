(function() {
    const DRAFT_KEY_PREFIX = 'sf_draft_';

    function getPageContextKey() {
        return DRAFT_KEY_PREFIX + window.location.pathname;
    }

    function saveDraft(content) {
        localStorage.setItem(getPageContextKey(), content);
        console.log('Draft saved.');
    }

    function loadDraft() {
        return localStorage.getItem(getPageContextKey()) || '';
    }

    function clickShareButton() {
        const button = document.querySelector('button[title="Share an update..."]');
        if (button) {
            button.click();
            console.log('Clicked "Share an update..." button.');
        } else {
            console.log('Share button not found yet. Retrying...');
            setTimeout(clickShareButton, 1000);
        }
    }

    function initializeDraftEditor(editorDiv) {
        if (!editorDiv) return;

        // Load existing draft
        editorDiv.innerHTML = loadDraft();

        // Listen for input events
        editorDiv.addEventListener('input', () => {
            saveDraft(editorDiv.innerHTML);
        });

        console.log('Draft Auto-Save initialized on editor:', editorDiv);
    }

    function observeForEditor() {
        const observer = new MutationObserver((mutationsList, observer) => {
            for (const mutation of mutationsList) {
                const editorDiv = document.querySelector('div.ql-editor[contenteditable="true"]');
                if (editorDiv) {
                    initializeDraftEditor(editorDiv);
                    observer.disconnect(); // Stop observing after initializing
                    break;
                }
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    window.addEventListener('load', () => {
        const existingDraft = loadDraft();
        if (existingDraft) {
            console.log('Draft found, triggering editor open...');
            setTimeout(clickShareButton, 1000); // Delay to ensure button is present
        }
        observeForEditor(); // Always observe for editor to initialize auto-save
    });
})();