// version 2.0 few bug fixes and improvements
// This script auto-saves drafts for Salesforce updates and comments and quick comments gracefully removing them when the post/comment is successfully submitted. from local cache

(function() {
    const DRAFT_KEY_PREFIX = 'sf_draft_';

    function getPageContextKey(suffix = '') {
        return DRAFT_KEY_PREFIX + window.location.pathname + (suffix ? '_' + suffix : '');
    }

    function saveDraft(content, suffix = '') {
        localStorage.setItem(getPageContextKey(suffix), content);
        console.log('Draft saved for', suffix || 'update');
    }

    function loadDraft(suffix = '') {
        return localStorage.getItem(getPageContextKey(suffix)) || '';
    }

 //   function clickShareButton() {
 //       const button = document.querySelector('button[title="Share an update..."]');
 //       if (button) {
 //           button.click();
//            console.log('Clicked "Share an update..." button.');
 //       } else {
//            console.log('Share button not found yet. Retrying...');
//            setTimeout(clickShareButton, 1000);
 //       }
//    }

 //   function clickCommentButton() {
 //       const commentIcon = document.querySelector('lightning-icon[icon-name="utility:comments"]');
 //       if (commentIcon) {
 //           const commentBtn = commentIcon.closest('a,button') || commentIcon;
 //           commentBtn.click();
 //           console.log('Clicked comment button.');
//        } else {
//            console.log('Comment button not found yet. Retrying...');
 //           setTimeout(clickCommentButton, 1500);
//        }
//    }    

    function initializeDraftEditor(editorDiv, suffix = '') {
        if (!editorDiv) return;
        editorDiv.removeAttribute('data-draft-type');
        editorDiv.setAttribute('data-draft-type', suffix || 'update');
        // Load existing draft
        editorDiv.innerHTML = loadDraft(suffix);

        // Listen for input events
        editorDiv.addEventListener('input', () => {
            saveDraft(editorDiv.innerHTML, suffix);
        });

        console.log('Draft Auto-Save initialized on editor:', editorDiv, 'for', suffix || 'update');
    }

    function waitForEditorAndInit(suffix = '' ) {
        // Wait for the editor to appear, then tag and initialize it
        const interval = setInterval(() => {
            const editorDiv = document.querySelector('div.ql-editor[contenteditable="true"]');
            if (editorDiv) {
                initializeDraftEditor(editorDiv, suffix);
                clearInterval(interval);
            }
        }, 300);
        // Optional: add a timeout to avoid infinite polling
        setTimeout(() => clearInterval(interval), 10000);
    }

 //   function observeForEditor(suffix = '') {
 //       const observer = new MutationObserver((mutationsList, observer) => {
 //           for (const mutation of mutationsList) {
 //               const editorDiv = document.querySelector('div.ql-editor[contenteditable="true"]');
 //               for (const editorDiv of editorDivs) {
//                    if (!editorDiv.hasAttribute('data-draft-type')) {
//                        // Mark this editor with the correct type
 //                       editorDiv.setAttribute('data-draft-type', suffix || 'update');
   //                     initializeDraftEditor(editorDiv, suffix);
 //                       observer.disconnect();
 //                       return;
 //               }
 //           }
 //       });

 //       observer.observe(document.body, { childList: true, subtree: true });
 //   }

  // Poll for buttons/icons and attach listeners when found
    function attachListeners() {
        // Share an update...
        const shareBtn = document.querySelector('button[title="Share an update..."]');
        if (shareBtn && !shareBtn._draftListenerAttached) {
            shareBtn.addEventListener('click', function() {
                waitForEditorAndInit();
            });
            shareBtn._draftListenerAttached = true;
        }

        // Comment icon (opens comment editor)
        const commentIcon = document.querySelector('lightning-icon[icon-name="utility:comments"]');
        if (commentIcon) {
            const commentBtn = commentIcon.closest('a,button') || commentIcon;
            if (commentBtn && !commentBtn._draftListenerAttached) {
                commentBtn.addEventListener('click', function() {
                    waitForEditorAndInit('comment');
                });
                commentBtn._draftListenerAttached = true;
            }
        }

        // Quick comment field (or any other unique field)
        const quickCommentDiv = document.querySelector('div.ql-editor.slds-rich-text-area__content[data-placeholder="Write a comment..."]');
        if (quickCommentDiv && !quickCommentDiv._draftListenerAttached) {
            initializeDraftEditor(quickCommentDiv, 'quickcomment');
            quickCommentDiv._draftListenerAttached = true;
        }

        // Keep polling until both listeners are attached
        if (
            !(shareBtn && shareBtn._draftListenerAttached) ||
            !(commentIcon && ((commentIcon.closest('a,button') || commentIcon)._draftListenerAttached)) ||
            !(quickCommentDiv && quickCommentDiv._draftListenerAttached)
        ) {
            setTimeout(attachListeners, 1000);
        }
    }

    document.body.addEventListener('click', function(e) {
    // Share button for update
    if (
        e.target.matches('button.slds-button_brand.cuf-publisherShareButton.qe-textPostDesktop') &&
        e.target.textContent.trim() === 'Share'
    ) {
        localStorage.removeItem('sf_draft_' + window.location.pathname);
        console.log('Draft removed after successful post.');
    }
    // Comment button for comment
    if (
        e.target.matches('button.slds-button_brand.cuf-commentSubmit') &&
        e.target.textContent.trim() === 'Comment'
    ) {
        localStorage.removeItem('sf_draft_' + window.location.pathname + '_comment');
        console.log('Comment draft removed after successful comment.');
    }
    // Quick comment submit button (update selector as needed)
    if (
        e.target.matches('button.slds-button_brand.cuf-commentSubmit')
    ) {
        localStorage.removeItem('sf_draft_' + window.location.pathname + '_quickcomment');
        console.log('Quick comment draft removed after successful quick comment.');
    }
});

    attachListeners();

})();