# csurv-fix-alert-status
Script to fix missing or broken alert status records in CSurv. This script fixes two use cases:

## Missing Alert Status Record
An alert status record is missing for a KI in a message.
## Partial Alert Status Record
An alert status record is present for a KI in a message, but it only contains the review status fields. 
Metadata fields such as "parent", "alert_status_id", or "key_indicator_id" are missing. 

# Operation
The script searches an alert index for messages using the "KG name" and "alerts_year" arguments. 
Fields from a message's "alert_status" child records are returned along with message metadata. 
If no alert status fields are found for a KI, then the alert status record is considered missing.
If some alert status fields are found for a KI, but the required metadata fields are missing, then the alert status record is considered partial.
The query file can limit the messages and alert status records searched using filters. 
The script fills in the "size", "sort", "_source", and "inner_hits" tags. They must not be set in the query file.
By default, only missing and partial alert status records are logged to a CSV file. 
The "--update" option is used to fix the records.

# Usage
```
usage: csurv_fix_alert_status.py [-h] [--update] [--es-host ES_HOST]
                                 [--es-user ES_USER]
                                 [--es-password ES_PASSWORD] [--es-use-tls]
                                 [--es-use-hosts] [--es-use-hostname]
                                 [--es-connect-timeout ES_CONNECT_TIMEOUT]
                                 [--es-read-timeout ES_READ_TIMEOUT]
                                 [--es-scroll-timeout ES_SCROLL_TIMEOUT]
                                 [--es-slices ES_SLICES]
                                 [--es-search-batch-size ES_SEARCH_BATCH_SIZE]
                                 [--logging-level {DEBUG,INFO,WARNING,ERROR}]
                                 [--logging-status-interval LOGGING_STATUS_INTERVAL]
                                 kg_name alerts_year query_file

Search for missing or broken alerts and fix them.

positional arguments:
  kg_name               CSurv KG name.
  alerts_year           Alerts index year.
  query_file            JSON file containing the ES query

optional arguments:
  -h, --help            show this help message and exit
  --update              If set, execute the update. Otherwise, list the
                        records to be updated. (Env: UPDATE, Default: False)
  --es-host ES_HOST     Comma-separated list of ES hosts or IP addresses with
                        optional ports. The default port is 9200. (Env:
                        ES_HOSTS, Default: localhost:9200)
  --es-user ES_USER     ES user name. (Env: ES_USER, Default: elastic)
  --es-password ES_PASSWORD
                        ES password. (Env: ES_PASSWORD, Default: )
  --es-use-tls          If set, use HTTPS for ES connections. Otherwise, use
                        HTTP. (Env: ES_USE_TLS, Default: False)
  --es-use-hosts        If set, use ES_HOSTS for connecting to ES. Otherwise,
                        use the sniffer to discover ES data nodes and only use
                        them for requests. (Env: ES_USE_HOSTS, Default: False)
  --es-use-hostname     If set and sniffing, connect to ES data nodes using
                        their hostname. Otherwise, use their IP address. (Env:
                        ES_USE_HOSTNAME, Default: False)
  --es-connect-timeout ES_CONNECT_TIMEOUT
                        ES connection timeout in seconds. (Env:
                        ES_CONNECT_TIMEOUT, Default: 60)
  --es-read-timeout ES_READ_TIMEOUT
                        ES read timeout in seconds. (Env: ES_READ_TIMEOUT,
                        Default: 300)
  --es-scroll-timeout ES_SCROLL_TIMEOUT
                        ES scroll timeout. (Env: ES_SCROLL_TIMEOUT, Default:
                        5m)
  --es-slices ES_SLICES
                        Number of ES slices/threads to use when searching.
                        (Env: ES_SLICES, Default: 10)
  --es-search-batch-size ES_SEARCH_BATCH_SIZE
                        Batch size for an ES scrolled search request. (Env:
                        ES_SEARCH_BATCH_SIZE, Default: 5000)
  --logging-level {DEBUG,INFO,WARNING,ERROR}
                        Log level. (Env: LOGGING_LEVEL, Default: INFO)
  --logging-status-interval LOGGING_STATUS_INTERVAL
                        Number of seconds between logging status updates.
                        (Env: LOGGING_STATUS_INTERVAL, Default: 20)
```
