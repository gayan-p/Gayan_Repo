'''Script to search alerts and export their fields to a CSV file.'''
import argparse
import json
import time
import concurrent.futures
import os
import csv
import copy
import cea_common as cea
from cea_common import AppLogger
from es_client import ESClient

#
# Script to search for missing or broken alerts and fix them.
#
#  - The ES query is read from a JSON file to search for messages. 
#  - For ES 7.x, the query must contain a "bool" query inside the "query" section so a "doc_type" filter can be added by the script. 
#  - "size", "sort", "_source", and "inner_hits" are set by the script and must not be set in the JSON query file.
#  - This is written for ES 5.x and ES 7.x.
#
# Usage: 
#   Search for missing or broken alerts for a KG.
#
#   python3 csurv-fix-alert-status.py test_kg 2025 find_by_date.json
#
#   Search for missing or broken alerts for a KG and fix them.
#
#   python3 csurv-fix-alert-status.py --update test_kg 2025 find_by_date.json
#

#
# Constants
#
CSV_HEADERS                 = [ 'message_id',
                                'alert_status_id',
                                'loaded_date',                
                                'alert_status']
                               
ALERTS_INDEX_PATTERN            = '__message_types_alerts_'

JSON_MESSAGE_DOC_TYPE_FILTER    = '{"term":{"doc_type":"' + cea.DOC_TYPE_MESSAGE + '"}}'
JSON_TRACK_TOTAL_HITS           = '{"track_total_hits":true}'
JSON_SLICE                      = '{"slice":{"id":-1,"max":""}}'  
JSON_SIZE                       = '{"size":""}'
JSON_SORT                       = '{"sort":["_doc"]}'
JSON_SOURCE                     = '{"_source":["message_id","loaded_date","key_indicators.key_indicator_id","key_indicators.alert_data_permissions","data_permissions"]}'
JSON_INNER_HITS                 = '{"inner_hits": {"_source":["alert_status_id","parent","key_indicator_id","created_date","status","status_date","assignee","assignment_date","resolved","resolved_date","last_updated"],"size":100}}'   
JSON_SCROLL_BODY                = '{"scroll":"","scroll_id":""}'
OUTPUT_FILE                     = 'broken_alerts.csv'

OPTION_UPDATE                   = '--update'
ENV_UPDATE                      = 'UPDATE'
DEFAULT_UPDATE                  = False
HELP_UPDATE                     = 'If set, execute the update. Otherwise, list the records to be updated.'
HELP_UPDATE                     += cea.get_env_and_default(ENV_UPDATE, default_value=DEFAULT_UPDATE)

def get_messages_search(es_client, slice_id, query_body, alerts_index, es_scroll_timeout):
    '''Get the initial batch of messages for a slice.'''
    
    if es_client.is_es5():
        request_url = '/' + alerts_index + '/' + cea.DOC_TYPE_MESSAGE + '/' + '_search' + '?scroll=' + es_scroll_timeout
    else:
        request_url = '/' + alerts_index + '/' + '_search' + '?scroll=' + es_scroll_timeout
        
    # Update the slice_id.       
    query_body['slice']['id'] = slice_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
    
    return response.json()

def get_messages_scroll(es_client, scroll_id, query_body, es_scroll_timeout):
    '''Get a subsequent batch of messages with the scroll_id.'''
  
    request_url = "/" + "_search/scroll"
    
    # Update the scroll.
    query_body['scroll'] = es_scroll_timeout
    query_body['scroll_id'] = scroll_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
    
    return response.json()

def bulk_update_alert_status(es_client, bulk_cmd):
    '''Bulk index the alert_status records.'''

    request_url = '/_bulk'
                    
    return es_client.es_post_request(request_url, bulk_cmd)
              
def process_slice(es_client, slice_id, csv_writer, query_body, scroll_body, alerts_index, index_suffix, es_scroll_timeout, update, logger, logging_status_interval):
    '''Search for messages in one slice.'''
    last_status = time.time()
    stats_count = 0
    total_msgs = 0
    total_alerts = 0
    valid_alerts = 0
    missing_alerts = 0
    partial_alerts = 0
    created_alerts = 0
    indexed_alerts = 0
    
    logger.info('Slice[%d] Starting search...', slice_id)
    
    results = get_messages_search(es_client, slice_id, query_body, alerts_index, es_scroll_timeout)
    
    failed_shards = results['_shards']['failed']
    
    if failed_shards != 0:
        logger.error('Could not search alerts. Shards failed: %d', failed_shards)
        os._exit(1)
        
    if es_client.is_es5():
        total_hits = results['hits']['total']
    else:
        total_hits = results['hits']['total']['value']
    
    logger.info('Slice[%d] Total hits: %d', slice_id, total_hits)
    
    hits = results['hits']['hits']
      
    while total_hits > 0 and len(hits) > 0:
        # Save a batch of alerts metadata.
        for hit in hits:
            source = hit['_source'] 
            message_id = source['message_id']
            loaded_date = source['loaded_date']
            
            data_permissions = source.get('data_permissions', [])
            
            ki_map = dict()
            if 'key_indicators' in source:
                for ki in source['key_indicators']:
                    if 'key_indicator_id' in ki:
                        key_indicator_id = ki['key_indicator_id']                    
                        alert_data_permissions = ki.get('alert_data_permissions', [])                
                        alert_status_id = message_id + '$' + key_indicator_id
                        ki_map[alert_status_id] = alert_data_permissions
                    else:
                        logger.warn('key_indicator_id missing in message. message_id: %s, key_indicator: %s', message_id, ki)
                        
                    total_alerts += 1
            else:
                logger.warn('key_indicators missing in message. message_id: %s', message_id)
                    
            inner_hits = hit['inner_hits']['alert_status']['hits']['hits']
            
            bulk_cmd = ''
            
            for inner_hit in inner_hits:
                _id = inner_hit['_id']
                inner_source = inner_hit['_source']
                
                if 'alert_status_id' not in inner_source or 'parent' not in inner_source or 'key_indicator_id' not in inner_source or 'created_date' not in inner_source:
                    csv_writer.writerow([message_id, _id, loaded_date, 'partial'])
                    partial_alerts += 1
                    
                    logger.debug('inner_hit: %s', inner_hit)
                    
                    if update:
                        status                      = inner_source.get('status', None)
                        status_date                 = inner_source.get('status_date', None)
                        assignee                    = inner_source.get('assignee', None)
                        assignment_date             = inner_source.get('assignment_date', None)
                        resolved                    = inner_source.get('resolved', None)
                        resolved_date               = inner_source.get('resolved_date', None)
                        last_updated                = inner_source.get('last_updated', None)
                        
                        alert_status_id             = _id
                        parent                      = message_id
                        key_indicator_id            = _id.split('$', 1)[1]
                        owner                       = assignee
                        created_date                = loaded_date
                                                
                        alert_data_permissions      = ki_map[alert_status_id]               
                        message_data_permissions    = data_permissions
                        
                        regex_hits                  = []
                        
                        # Update the alert status doc.             
                        index_obj = {}
                        index_obj['_id'] = alert_status_id
                        if es_client.is_es5():
                            index_obj['_type'] = cea.DOC_TYPE_ALERT_STATUS
                        elif es_client.is_es7():
                            index_obj['_type'] = cea.DOC_TYPE_DOC
                        index_obj['_index'] = alerts_index
                        if es_client.is_es5():
                            index_obj['_parent'] = parent
                            index_obj['_routing'] = parent
                        elif es_client.is_es7():
                            index_obj['routing'] = parent
                        
                        index_cmd = {}
                        index_cmd['index'] = index_obj
                        
                        alert_status = dict()
                        
                        if status is not None:
                           alert_status['status'] = status
                           
                        if status_date is not None:
                           alert_status['status_date'] = status_date 
                        
                        if assignee is not None:
                           alert_status['assignee'] = assignee 
                         
                        if assignment_date is not None:
                           alert_status['assignment_date'] = assignment_date 
                             
                        if resolved is not None:
                           alert_status['resolved'] = resolved 
                           
                        if resolved_date is not None:
                           alert_status['resolved_date'] = resolved_date
                         
                        if last_updated is not None:
                           alert_status['last_updated'] = last_updated
                           
                        alert_status['alert_status_id'] = alert_status_id
                        alert_status['parent'] = parent
                        alert_status['index_suffix'] = index_suffix
                        alert_status['key_indicator_id'] = key_indicator_id
                        alert_status['owner'] = owner
                        alert_status['created_date'] = created_date
                          
                        alert_status['message_data_permissions'] = message_data_permissions                   
                        alert_status['alert_data_permissions'] = alert_data_permissions
                            
                        alert_status['regex_hits'] = regex_hits
                        
                        if es_client.is_es7():
                            doc_type = dict()
                            doc_type['name'] = cea.DOC_TYPE_ALERT_STATUS
                            doc_type['parent'] = parent
                            alert_status['doc_type'] = doc_type
                            
                        str_alert_status = json.dumps(alert_status)
                        
                        bulk_cmd += json.dumps(index_cmd) + '\n' + str_alert_status + '\n'                        
                
                else:
                    valid_alerts += 1                
                
                # Remove the found alert from the map.
                if _id in ki_map:
                    ki_map.pop(_id)
                else:
                    logger.warn('alert_status_id missing in message. message_id: %s, alert_status_id: %s, inner_hit: %s', message_id, _id, inner_hit)                    
            
            # What is left over is missing.
            for alert_status_id in ki_map.keys():
                csv_writer.writerow([message_id, alert_status_id, loaded_date, 'missing']) 
                               
                if update: 
                    alert_status_id             = alert_status_id
                    parent                      = message_id
                    key_indicator_id            = alert_status_id.split('$', 1)[1]
                    created_date                = loaded_date
                                            
                    alert_data_permissions      = ki_map[alert_status_id]               
                    message_data_permissions    = data_permissions
                    
                    regex_hits                  = []
                    
                    # Create the alert status doc.             
                    index_obj = {}
                    index_obj['_id'] = alert_status_id
                    if es_client.is_es5():
                        index_obj['_type'] = cea.DOC_TYPE_ALERT_STATUS
                    elif es_client.is_es7():
                        index_obj['_type'] = cea.DOC_TYPE_DOC
                    index_obj['_index'] = alerts_index
                    if es_client.is_es5():
                        index_obj['_parent'] = parent
                        index_obj['_routing'] = parent
                    elif es_client.is_es7():
                            index_obj['routing'] = parent
                    
                    index_cmd = {}
                    index_cmd['create'] = index_obj
                    
                    alert_status = dict()
                        
                    alert_status['alert_status_id'] = alert_status_id
                    alert_status['parent'] = parent
                    alert_status['index_suffix'] = index_suffix
                    alert_status['key_indicator_id'] = key_indicator_id
                    alert_status['created_date'] = created_date
                      
                    alert_status['message_data_permissions'] = message_data_permissions                
                    alert_status['alert_data_permissions'] = alert_data_permissions
                        
                    alert_status['regex_hits'] = regex_hits
                        
                    if es_client.is_es7():
                        doc_type = dict()
                        doc_type['name'] = cea.DOC_TYPE_ALERT_STATUS
                        doc_type['parent'] = parent
                        alert_status['doc_type'] = doc_type
                        
                    str_alert_status = json.dumps(alert_status)
                    
                    bulk_cmd += json.dumps(index_cmd) + '\n' + str_alert_status + '\n' 
                    
                missing_alerts += 1            
            
            if update and bulk_cmd != '':
                created, indexed, deleted, not_found = bulk_update_alert_status(es_client, bulk_cmd)
                created_alerts += created
                indexed_alerts += indexed                
            
            total_msgs += 1
            stats_count += 1
    
        scroll_id = results['_scroll_id']
                
        cur_time = time.time()
        if cur_time - last_status >= logging_status_interval:
            exec_time = cur_time - last_status
            docs_per_sec = stats_count / exec_time if stats_count > 0 else 0
            logger.info('Slice[%d] Processed: %d - %s, docs/sec: %.0f', 
                slice_id, total_msgs, f'{(total_msgs / total_hits):.0%} complete', docs_per_sec)
            
            last_status = cur_time
            stats_count = 0
            
        results = get_messages_scroll(es_client, scroll_id, scroll_body, es_scroll_timeout)
        
        failed_shards = results['_shards']['failed']
    
        if failed_shards != 0:
            logger.error('Could not search messages. Shards failed: %d', failed_shards)
            os._exit(1)
                
        hits = results['hits']['hits']
    
    logger.info('Slice[%d] Completed search, total hits: %d, processed: %d', slice_id, total_hits, total_msgs)
    
    return (total_msgs, total_alerts, valid_alerts, missing_alerts, partial_alerts, created_alerts, indexed_alerts)
    
def find_and_fix_alerts(es_client, es_slices, es_scroll_timeout, query_body, scroll_body, alerts_index, index_suffix, update, logger, logging_status_interval):
    '''Find and fix alerts.'''

    total_msgs = 0
    total_alerts = 0
    valid_alerts = 0
    missing_alerts = 0
    partial_alerts = 0
    created_alerts = 0
    indexed_alerts = 0
        
    logger.info('Searching messages with %d slices...', es_slices)
    
    start_exec = time.time()
    with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as output:
        csv_writer = csv.writer(output, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        csv_writer.writerow(CSV_HEADERS)
        logger.debug('CSV_HEADERS: %s', CSV_HEADERS)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=es_slices) as executor:
            futures = []
            for slice_id in range(es_slices):
                futures.append(executor.submit( process_slice, 
                                                es_client=es_client, 
                                                slice_id=slice_id, 
                                                csv_writer=csv_writer, 
                                                query_body=copy.deepcopy(query_body), 
                                                scroll_body=copy.deepcopy(scroll_body), 
                                                alerts_index=alerts_index,
                                                index_suffix=index_suffix,
                                                es_scroll_timeout=es_scroll_timeout,
                                                update=update,
                                                logger=logger,
                                                logging_status_interval=logging_status_interval))
            
            for future in concurrent.futures.as_completed(futures):
                results = future.result() 
                total_msgs += results[0]
                total_alerts += results[1]
                valid_alerts += results[2]
                missing_alerts += results[3]
                partial_alerts += results[4]
                created_alerts += results[5]
                indexed_alerts += results[6]
                                         
    end_exec = time.time()    
    exec_time = end_exec - start_exec
    exec_mins = exec_time / 60
    docs_per_sec = total_msgs / exec_time if total_msgs > 0 else 0
    
    logger.info('Found %d msgs in %.2f minutes, docs/sec: %.0f, total alerts: %d, valid alerts: %d, missing alerts: %d, partial alerts: %d, created alerts: %d, indexed alerts: %d', total_msgs, exec_mins, docs_per_sec, total_alerts, valid_alerts, missing_alerts, partial_alerts, created_alerts, indexed_alerts)

def init_query(es_client, query_body, es_slices, es_search_batch_size):
    '''Initialize the query for slicing and ES 7.'''
    
    # Needed for all ES versions.
    esslice = json.loads(JSON_SLICE)
    esslice['slice']['max'] = es_slices
    query_body.update(esslice) 
    
    if 'size' in query_body:
        raise ValueError('JSON query must not contain the "size" field.')
    
    if 'sort' in query_body:
        raise ValueError('JSON query must not contain the "sort" field.')
    
    if '_source' in query_body:
        raise ValueError('JSON query must not contain the "_source" field.')
                
    size = json.loads(JSON_SIZE)
    size['size'] = es_search_batch_size
    query_body.update(size)    
    query_body.update(json.loads(JSON_SORT))
    query_body.update(json.loads(JSON_SOURCE))
      
    # "query" must be present.
    if 'query' not in query_body:
        raise ValueError('JSON query is missing the "query" field.')
        
    # "bool" must be present.
    if 'bool' not in query_body['query']:
        raise ValueError('JSON query is missing the "bool" field.')
    
    # "should" must be present.
    if 'should' not in query_body['query']['bool']:
        raise ValueError('JSON query is missing the "should" field.')
   
    # "has_child" must be present.
    if 'has_child' not in query_body['query']['bool']['should'][0]:
        raise ValueError('JSON query is missing the "has_child" field.')
    
    # "minimum_should_match" must be present.
    if 'minimum_should_match' not in query_body['query']['bool']:
        raise ValueError('JSON query is missing the "minimum_should_match" field.')
    
    # "inner_hits" must not be present.
    if 'inner_hits' in query_body['query']['bool']['should'][0]['has_child']:
        raise ValueError('JSON query must not contain the "inner_hits" field.')
        
    query_body['query']['bool']['should'][0]['has_child'].update(json.loads(JSON_INNER_HITS))
                
    if es_client.is_es5(): 
        return query_body
        
    # The following are for ES7+.
    query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))    
      
    # Add "filter" if missing.  
    if 'filter' not in query_body['query']['bool']:
        query_body['query']['bool']['filter'] = []

    # Add doc_type filter.
    query_body['query']['bool']['filter'].append(json.loads(JSON_MESSAGE_DOC_TYPE_FILTER))
    
    return query_body
 
def main():
    '''Start of main.'''    
    parser = argparse.ArgumentParser(description='Search for missing or broken alerts and fix them.')
    parser.add_argument('kg_name', help='CSurv KG name.', type=str)
    parser.add_argument('alerts_year', help='Alerts index year.', type=int)
    parser.add_argument('query_file', help='JSON file containing the ES query')
    
    parser.add_argument(OPTION_UPDATE, action='store_true', help=HELP_UPDATE)   
    
    parser = ESClient.init_client_args(parser)    
    parser = ESClient.init_scroll_timeout_arg(parser)
    parser = ESClient.init_slices_arg(parser)
    parser = ESClient.init_search_batch_size_arg(parser)
    
    parser = AppLogger.init_stdout_args(parser)
    
    args = parser.parse_args()
          
    app_logger = AppLogger.create_stdout_from_args(__file__, args, parser)
    logger = app_logger.get_logger()
    logging_status_interval = app_logger.get_status_interval()
    
    kg_name = args.kg_name
    alerts_year = args.alerts_year
    query_file = args.query_file
        
    es_scroll_timeout = ESClient.get_scroll_timeout(args)
    es_slices = ESClient.get_slices(parser, args)
    es_search_batch_size = ESClient.get_search_batch_size(parser, args)   
       
    logger.info('Starting...')       
    
    alerts_index = kg_name + ALERTS_INDEX_PATTERN + str(alerts_year)
    index_suffix = 'alerts_' + str(alerts_year)
    
    logger.info('KG name: %s', kg_name)
    logger.info('Alerts year: %d', alerts_year) 
    logger.info('Query file: %s', query_file)
    logger.info('Alerts index: %s', alerts_index)  
    
    update = cea.get_option_as_bool(args, OPTION_UPDATE, ENV_UPDATE, DEFAULT_UPDATE)    
    logger.info('Update: %s', update)  
          
    es_client = ESClient.create_from_args(args, parser, logger)  
     
    logger.info('ES scroll timeout: %s', es_scroll_timeout)
    logger.info('ES slices: %d', es_slices)
    logger.info('ES search batch size: %d', es_search_batch_size)
    
    with open(query_file, 'r', encoding='utf-8') as f:
        query_body = json.load(f)  
        logger.debug('Loaded ES query: %s', json.dumps(query_body))
    
    query_body = init_query(es_client, query_body, es_slices, es_search_batch_size)  
    logger.debug('Inited ES query body: %s', json.dumps(query_body))
    
    scroll_body = json.loads(JSON_SCROLL_BODY)
       
    find_and_fix_alerts(es_client, es_slices, es_scroll_timeout, query_body, scroll_body, alerts_index, index_suffix, update, logger, logging_status_interval) 
                                       
    logger.info('Done.')                  
    
if __name__ == '__main__':        
    main()
