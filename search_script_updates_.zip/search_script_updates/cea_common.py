'''Misc. utilities for purge scripts.'''

# pylint: disable=trailing-whitespace
# pylint: disable=line-too-long

import logging
import os
import threading
from urllib3.exceptions import InsecureRequestWarning
import requests
from requests.exceptions import ConnectionError

#
# Constants
#

OPTION_ES_HOSTS                     = '--es-host'
OPTION_ES_USER                      = '--es-user'
OPTION_ES_PASSWORD                  = '--es-password'
OPTION_ES_USE_TLS                   = '--es-use-tls'
OPTION_ES_USE_HOSTS                 = '--es-use-hosts'
OPTION_ES_USE_HOSTNAME              = '--es-use-hostname'
OPTION_ES_CONNECT_TIMEOUT           = '--es-connect-timeout'
OPTION_ES_READ_TIMEOUT              = '--es-read-timeout'
OPTION_ES_SCROLL_TIMEOUT            = '--es-scroll-timeout'
OPTION_ES_SLICES                    = '--es-slices'
OPTION_ES_SEARCH_BATCH_SIZE         = '--es-search-batch-size'
OPTION_LOGGING_LEVEL                = '--logging-level'
OPTION_LOGGING_STATUS_INTERVAL      = '--logging-status-interval'

ENV_ES_HOSTS                        = 'ES_HOSTS'
ENV_ES_USER                         = 'ES_USER'
ENV_ES_PASSWORD                     = 'ES_PASSWORD'
ENV_ES_USE_TLS                      = 'ES_USE_TLS'
ENV_ES_USE_HOSTS                    = 'ES_USE_HOSTS'
ENV_ES_USE_HOSTNAME                 = 'ES_USE_HOSTNAME'
ENV_ES_CONNECT_TIMEOUT              = 'ES_CONNECT_TIMEOUT'
ENV_ES_READ_TIMEOUT                 = 'ES_READ_TIMEOUT'
ENV_ES_SCROLL_TIMEOUT               = 'ES_SCROLL_TIMEOUT'
ENV_ES_SLICES                       = 'ES_SLICES'
ENV_ES_SEARCH_BATCH_SIZE            = 'ES_SEARCH_BATCH_SIZE'
ENV_LOGGING_LEVEL                   = 'LOGGING_LEVEL'
ENV_LOGGING_STATUS_INTERVAL         = 'LOGGING_STATUS_INTERVAL'

DEFAULT_ES_HOSTS                    = 'localhost:9200'
DEFAULT_ES_PORT                     = 9200
DEFAULT_ES_USER                     = 'elastic'
DEFAULT_ES_PASSWORD                 = ''
DEFAULT_ES_USE_TLS                  = False
DEFAULT_ES_USE_HOSTS                = False
DEFAULT_ES_USE_HOSTNAME             = False
DEFAULT_ES_CONNECT_TIMEOUT          = 60
DEFAULT_ES_READ_TIMEOUT             = 300
DEFAULT_ES_SCROLL_TIMEOUT           = '5m'
DEFAULT_ES_SLICES                   = 10
DEFAULT_ES_SEARCH_BATCH_SIZE        = 5000
DEFAULT_LOGGING_LEVEL               = 'INFO'
DEFAULT_LOGGING_STATUS_INTERVAL     = 20

MIN_ES_CONNECT_TIMEOUT              = 1
MIN_ES_READ_TIMEOUT                 = 1
MIN_ES_SLICES                       = 1
MIN_ES_SEARCH_BATCH_SIZE            = 1
MIN_LOGGING_STATUS_INTERVAL         = 1

def get_env_and_default(*env_var, default_value):
    '''Return the environment variable and default option value as a string.'''
    
    return ' (Env: ' + ' or '.join(env_var) + ', Default: ' + str(default_value) + ')'
 
HELP_ES_HOSTS                       = 'Comma-separated list of ES hosts or IP addresses with optional ports. The default port is ' + str(DEFAULT_ES_PORT) + '.'
HELP_ES_USER                        = 'ES user name.'
HELP_ES_PASSWORD                    = 'ES password.'
HELP_ES_USE_TLS                     = 'If set, use HTTPS for ES connections. Otherwise, use HTTP.'
HELP_ES_USE_HOSTS                   = 'If set, use ES_HOSTS for connecting to ES. Otherwise, use the sniffer to discover ES data nodes and only use them for requests.'
HELP_ES_USE_HOSTNAME                = 'If set and sniffing, connect to ES data nodes using their hostname. Otherwise, use their IP address.'
HELP_ES_CONNECT_TIMEOUT             = 'ES connection timeout in seconds.'
HELP_ES_READ_TIMEOUT                = 'ES read timeout in seconds.'
HELP_ES_SCROLL_TIMEOUT              = 'ES scroll timeout.'
HELP_ES_SLICES                      = 'Number of ES slices/threads to use when searching.'
HELP_ES_SEARCH_BATCH_SIZE           = 'Batch size for an ES scrolled search request.'
HELP_LOGGING_LEVEL                  = 'Log level.'
HELP_LOGGING_STATUS_INTERVAL        = 'Number of seconds between logging status updates.'
 
HELP_ES_HOSTS                       += get_env_and_default(ENV_ES_HOSTS, default_value=DEFAULT_ES_HOSTS)
HELP_ES_USER                        += get_env_and_default(ENV_ES_USER, default_value=DEFAULT_ES_USER)
HELP_ES_PASSWORD                    += get_env_and_default(ENV_ES_PASSWORD, default_value=DEFAULT_ES_PASSWORD)
HELP_ES_USE_TLS                     += get_env_and_default(ENV_ES_USE_TLS, default_value=DEFAULT_ES_USE_TLS)
HELP_ES_USE_HOSTS                   += get_env_and_default(ENV_ES_USE_HOSTS, default_value=DEFAULT_ES_USE_HOSTS)
HELP_ES_USE_HOSTNAME                += get_env_and_default(ENV_ES_USE_HOSTNAME, default_value=DEFAULT_ES_USE_HOSTNAME)
HELP_ES_CONNECT_TIMEOUT             += get_env_and_default(ENV_ES_CONNECT_TIMEOUT, default_value=DEFAULT_ES_CONNECT_TIMEOUT)
HELP_ES_READ_TIMEOUT                += get_env_and_default(ENV_ES_READ_TIMEOUT, default_value=DEFAULT_ES_READ_TIMEOUT)
HELP_ES_SCROLL_TIMEOUT              += get_env_and_default(ENV_ES_SCROLL_TIMEOUT, default_value=DEFAULT_ES_SCROLL_TIMEOUT)
HELP_ES_SLICES                      += get_env_and_default(ENV_ES_SLICES, default_value=DEFAULT_ES_SLICES)
HELP_ES_SEARCH_BATCH_SIZE           += get_env_and_default(ENV_ES_SEARCH_BATCH_SIZE, default_value=DEFAULT_ES_SEARCH_BATCH_SIZE)
HELP_LOGGING_LEVEL                  += get_env_and_default(ENV_LOGGING_LEVEL, default_value=DEFAULT_LOGGING_LEVEL)
HELP_LOGGING_STATUS_INTERVAL        += get_env_and_default(ENV_LOGGING_STATUS_INTERVAL, default_value=DEFAULT_LOGGING_STATUS_INTERVAL)
   
def get_option_as_str(args, option_name, *env_names, default_value):
    '''Return a string option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None and option_value != '':
        return option_value
     
    for env_name in env_names:   
        env_value = os.getenv(env_name)
        if env_value is not None and env_value != '':
            return env_value
     
    return default_value
       
def get_option_as_int(parser, args, option_name, env_name, default_value, min_value):
    '''Return an integer option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None:
        if option_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {option_value}, must be greater than or equal to {min_value}.') 
        return option_value
        
    env_value = int(os.getenv(env_name)) if os.getenv(env_name) is not None else None
    if env_value is not None:
        if env_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {env_value}, must be greater than or equal to {min_value}.')
        return env_value
        
    return default_value

def get_option_as_bool(args, option_name, env_name, default_value):
    '''Return an boolean option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is True:
        return option_value
    
    env_value = os.getenv(env_name).lower() == 'true' if os.getenv(env_name) is not None else None    
    if env_value is not None:
        return env_value
    
    return default_value

def get_option_as_set(args, option_name, env_name, default_value):
    '''Get a comma-separated list of option values as a lower-case set.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None and option_value != '':
        return set(option_value.lower().split(','))
        
    env_value = os.getenv(env_name)
    if env_value is not None and env_value != '':
        return set(env_value.lower().split(','))
        
    return default_value.lower() if default_value is not None else None

#   
# Argument Validators
#

def validate_int(parser, arg_name, arg_value, min_value):
    '''Validate an integer argument.'''
    
    if arg_value < min_value:
        parser.error(arg_name + f' = {arg_value}, must be greater than or equal to {min_value}.')
    return arg_value
       
#
# Logging
#
   
logging_status_interval = DEFAULT_LOGGING_STATUS_INTERVAL   

def get_logging_status_interval():
    '''Get the logging status interval.'''
    
    global logging_status_interval
    return logging_status_interval
    
def get_logger(name, level, status_interval = DEFAULT_LOGGING_STATUS_INTERVAL):
    '''Init the logger.'''
    
    name = os.path.basename(name)
    logger = logging.getLogger(name)
    
    logging.basicConfig(format='[%(asctime)s][%(name)s][%(levelname)s] %(message)s')   
    logger.setLevel(level)
    
    global logging_status_interval
    logging_status_interval = status_interval
    
    return logger

#
# CSV Utilities
#

def get_csv_row_count(csv_file):
    '''Count the rows in a CSV file minus the header row.'''
    
    with open(csv_file, 'rb') as f:
        row_count = sum(1 for _ in f)
    return row_count - 1
    
#
# ES Utilities
#

QUERY_HEADERS               = {'Content-Type': 'application/json'}
BULK_HEADERS                = {'Content-Type': 'application/x-ndjson'}

DOC_TYPE_MESSAGE            = 'message'
DOC_TYPE_ALERT_STATUS       = 'alert_status'
DOC_TYPE_KI                 = 'key_indicator'

# Supported ES versions.
VERSION_ES5 = '5'
VERSION_ES7 = '7'

def check_response(response, logger):
    '''Check a no results response for errors.'''
    
    logger.debug('check_response status_code: %s', response.status_code)
    if response.status_code == requests.codes.ok:
        return True
    
    if response.status_code == requests.codes.not_found:
        return False
        
    logger.error('ES request error: %s', response.json())
    os._exit(1)      

def check_get_response(response, logger):
    '''Check GET response for errors.'''
    
    logger.debug('check_get_response status_code: %s', response.status_code)
    if response.status_code == requests.codes.ok:
        return response
    
    logger.error('ES GET error: %s', response.json())
    os._exit(1)     

def check_post_response(response, logger):
    '''Check POST with results response for errors.'''
    
    if response.status_code != requests.codes.ok:
        logger.error('ES POST error: %s', response.json())
        os._exit(1)
        
    json_response = response.json()
    
    logger.debug('response: %s', json_response)
    
    deleted = 0
    not_found = 0
    
    for item in json_response['items']:
        if 'delete' in item:
            item_status = item['delete']
        else:
            logger.warn('Unexpected item in the bulk response: %s', item)
            continue
        
        status = item_status['status']
        found = item_status['found']
        result = item_status['result']
        _id = item_status['_id']
        _index = item_status['_index']
            
        if status == requests.codes.ok and found and result == 'deleted':
            logger.debug('Message deleted. _id: %s, _index: %s', _id, _index)
            deleted += 1
                  
        elif status == requests.codes.not_found and not found and result == 'not_found':
            logger.debug('Message not found. _id: %s, _index: %s', _id, _index)
            not_found += 1
                
        else:
            error = item_status['error']
            logger.error('Bulk command failed - _id: %s, _index: %s, status: %d, found: %s, error: %s', _id, status, found, _index, error)
            os._exit(1)
            
    return deleted, not_found

def es_head_request(request_url, logger):
    '''ES HEAD request.'''
          
    global es_user
    global es_password
    global es_use_tls
    
    for _ in range(len(es_nodes)):
        next_host = get_next_node()
        
        try: 
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES HEAD URL: %s', url)
            
            response = requests.head(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            
            return check_response(response, logger)
        except ConnectionError as ce:
            logger.error('Could not connect to ES: %s', ce)
            
    logger.error('ES HEAD request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)   
        
def es_get_request(request_url, es_body, logger):
    '''ES GET request.'''
    
    global es_user
    global es_password
    global es_use_tls
    
    for _ in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES GET URL: %s', url)
            logger.debug('ES GET body: %s', es_body)
            
            response = requests.get(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout),
                data=es_body,
                headers=QUERY_HEADERS                
            )
            #logger.info('RESPONSE: %s', response)
            return check_get_response(response, logger)
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES GET request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)
        
def es_post_request(request_url, es_body, logger):
    '''ES POST request.'''
    
    global es_user
    global es_password
    global es_use_tls
    
    for _ in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
   
            logger.debug('ES POST URL: %s', url)
            
            response = requests.post(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout),
                data=es_body,
                headers=BULK_HEADERS
            )
            return check_post_response(response, logger)
            
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)

def es_post_no_body_request(request_url, logger):
    '''POST with no body or return results.'''
    
    global es_user
    global es_password
    global es_use_tls
    
    for _ in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
   
            logger.debug('ES POST URL: %s', url)
            
            response = requests.post(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            return check_response(response, logger)
            
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)

def es_delete_request(request_url, logger):   
    '''ES DELETE request.'''
       
    global es_user
    global es_password
    global es_use_tls
    
    for _ in range(len(es_nodes)):
        next_host = get_next_node()
        
        try: 
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES DELETE URL: %s', url)
            
            response = requests.delete(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            
            return check_response(response, logger)
        except ConnectionError as ce:
            logger.error('Could not connect to ES: %s', ce)
            
    logger.error('ES DELETE request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)   
              
def check_es_version(logger):
    '''Get the ES version and check if it is supported.'''
    
    request_url = "/"
    
    response = es_get_request(request_url, None, logger)
    
    result = response.json()
    version_number = result['version']['number']
    es_version = version_number.split('.')[0]  
   
    if es_version is None and not (es_version == VERSION_ES5 or es_version == VERSION_ES7):
        logger.error('Unsupported ES version: %s', version_number)
        os._exit(1)
        
    return es_version 

es_nodes_lock = threading.Lock()  
es_nodes = []
es_next_node = 0
es_user = ''
es_password = ''
es_use_tls = False
es_use_hostname = True
es_connect_timeout = 0
es_read_timeout = 0

def init_es(initial_hosts, user, password, use_tls, use_hosts, use_hostname, connect_timeout, read_timeout, logger):
    '''Initialize the ES environment.'''
    global es_nodes_lock
    global es_nodes
    global es_next_node
    global es_user
    global es_password
    global es_use_tls
    global es_use_hostname
    global es_connect_timeout
    global es_read_timeout
    
    # Silence https warnings
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
    
    initial_hosts = initial_hosts.split(',')
     
    data_nodes = []   
    coord_nodes = []   
    requested_nodes = []
    
    es_nodes_lock.acquire() 
    
    # Try all of the initial hosts.
    for initial_host in initial_hosts:
        
        try:
            logger.debug('Trying initial host: %s', initial_host)
            
            # Add the default port if the port is not present.
            host_and_port = initial_host if ':' in initial_host else initial_host + ':' + str(DEFAULT_ES_PORT)
                
            base_url = 'http{s}://{host_and_port}'.format(s=('s' if use_tls else ''),host_and_port=host_and_port)
            
            url = base_url + '/_nodes/http'
        
            logger.debug('ES get hosts: %s', url)
        
            response = requests.get(
                url,
                auth=(user, password),
                verify=False,
                timeout=(connect_timeout, read_timeout)
            )
            response = check_get_response(response, logger)
            
            results = response.json()
            
            # If using sniffer, save the data hosts.
            if use_hosts is False:
                for node in results['nodes'].values():    
                    host = node['host']
                    ip = node['ip']
                    roles = node['roles']
                    
                    # Get the port from the published_address.
                    if 'published_address' in node['http'] and ':' in node['http']['published_address']:
                        host_part, port_part = node['http']['published_address'].split(':')
                        port = int(port_part)
                        logger.debug('Using published port: %d', port)
                    else:
                        port = DEFAULT_ES_PORT
                        logger.debug('Using default port: %d', port)
                            
                    # Check for a dedicated coordinator.
                    if 'master' not in roles and 'data' not in roles:  
                        # Save the host/IP plus port.
                        coord_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                        logger.debug('Saving coordinating node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                             
                    elif 'data' in node['roles']:                                                  
                        # Save the host/IP plus port.
                        data_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                        logger.debug('Saving data node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                    
                    else:
                        logger.debug('Non-data or coordinating node: %s', node)
                    
                if len(data_nodes) > 0 or len(coord_nodes) > 0:
                    break
            else:
                # No sniffer, use as-is.
                requested_nodes.append((host_and_port, host_and_port))
                    
        except ConnectionError as ce:
            logger.warn('Could not connect to configured ES host: %s', ce) 
     
    # Check if there is at least one coordinating node available.
    if len(requested_nodes) > 0:
        nodes = requested_nodes
        node_type = 'requested'
    if len(coord_nodes) > 0:
        nodes = coord_nodes
        node_type = 'coordinating'
    else:
        nodes = data_nodes
        node_type = 'data'
        
    if len(nodes) == 0:
        if use_hosts is False:
            logger.error('No ES data or coordinating nodes are available.')
        else:
            logger.error('Configured ES hosts are not available.')
        os._exit(1)
      
    es_nodes = nodes
    es_next_node = 0
    es_user = user
    es_password = password
    es_use_tls = use_tls
    es_use_hostname = use_hostname
    es_connect_timeout = connect_timeout
    es_read_timeout = read_timeout
    es_nodes_lock.release()    
    
    es_version = check_es_version(logger)  
    
    logger.info('ES version: %s', es_version)
    logger.info('ES hosts available: %d, type: %s', len(nodes), node_type)
      
    return es_version     
 
def get_next_node():
    '''Return the next node in the list.'''
    global es_nodes_lock
    global es_nodes
    global es_next_node
    global es_use_hostname
    
    es_nodes_lock.acquire()    
    node = es_nodes[es_next_node] 
    es_next_node += 1
    if es_next_node >= len(es_nodes):
        es_next_node = 0        
    es_nodes_lock.release()
    
    return node[0] if es_use_hostname else node[1]
