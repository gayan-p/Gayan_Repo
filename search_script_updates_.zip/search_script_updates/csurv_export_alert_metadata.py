'''Script to search alerts and export their fields to a CSV file.'''
# pylint: disable=trailing-whitespace
# pylint: disable=line-too-long

import argparse
import json
#import logging
import time
import concurrent.futures
#import io
import os
import csv
import copy
#from datetime import datetime, timezone
#import requests
import cea_common as cea

#
# Script to search alerts and export their fields to a CSV file.
#
#  - The ES query is read from a JSON file. 
#  - For ES 7.x, the query must contain a "bool" query inside the "query" section so a "doc_type" filter can be added by the script. 
#  - "size" and "sort" are set by the script and should not be set in the JSON query file.
#  - This is written for ES 5.x and ES 7.x.
#
# Usage: 
#   Save alert metadata from alert indices for a KG.
#
#   python3 csurv-export-alert-metadata.py test_kg query.json
#

#
# Constants
#
CSV_HEADERS                 = ['message_id','ki_id','ki_name','document_date','ingestion_date','status','resolved','assignee','alert_data_permissions','message_data_permissions','sender_email_addrs','receiver_email_addrs','subject']
ALERTS_INDEX_PATTERN        = '__message_types_alerts_2*'
KIS_INDEX_PATTERN           = '__monitoring_misc_types'

JSON_ALERTS_DOC_TYPE_FILTER = '{"term":{"doc_type":"' + cea.DOC_TYPE_ALERT_STATUS + '"}}'
JSON_KIS_DOC_TYPE_FILTER    = '{"term":{"doc_type":"' + cea.DOC_TYPE_KI + '"}}'
JSON_TRACK_TOTAL_HITS       = '{"track_total_hits":true}'
JSON_SLICE                  = '{"slice":{"id":-1,"max":""}}'  
JSON_SIZE                   = '{"size":""}'
JSON_SORT                   = '{"sort":["_doc"]}'
JSON_SCROLL_BODY            = '{"scroll":"","scroll_id":""}'
OUTPUT_FILE                 = 'alerts.csv'

QUERY_KIS = '''
{
    "query": { 
        "bool": {
            "filter": [
                {
                    "match_all": {}
                }
            ]
        }
    },
    "_source": "ki_name",
    "size": 10000
}
'''

# Map of all KI names by ID.
ki_by_id = {}

def init_ki_names(es_version, kis_index):
    '''Initialize ki_names.'''
    query_body = json.loads(QUERY_KIS)
    
    if es_version == cea.VERSION_ES5:
        request_url = '/' + kis_index + '/' + cea.DOC_TYPE_KI + '/' + '_search'
    else:
        request_url = '/' + kis_index + '/' + '_search'
        
        # Add doc_type filter.
        query_body['query']['bool']['filter'].append(json.loads(JSON_KIS_DOC_TYPE_FILTER))
       
    data = json.dumps(query_body)
     
    response = cea.es_get_request(request_url, data, logger)
    
    json_results = response.json()
    
    hits = json_results['hits']['hits']
    
    count = 0
    
    for hit in hits:
        _id = hit['_id']
        ki_name = hit['_source']['ki_name']
        
        ki_by_id[_id] = ki_name
        logger.debug('id: %s, ki_name: %s', _id, ki_name)
        count += 1
        
    logger.info('Inited %d KI names.', count)
       
    if count > 10000:
        logger.error('KIs greater than 10,000. Increase the query size to: %d', count)
        os._exit(1)
        
def get_alert_metadata_search(es_version, slice_id, query_body, alerts_indices, es_scroll_timeout):
    '''Get the initial batch of alerts for a slice.'''
    
    if es_version == cea.VERSION_ES5:
        request_url = '/' + alerts_indices + '/' + cea.DOC_TYPE_ALERT_STATUS + '/' + '_search' + '?scroll=' + es_scroll_timeout
    else:
        request_url = '/' + alerts_indices + '/' + '_search' + '?scroll=' + es_scroll_timeout
        
    # Update the slice_id.       
    query_body['slice']['id'] = slice_id
    
    data = json.dumps(query_body)
    
    response = cea.es_get_request(request_url, data, logger)
    
    return response.json()

def get_alert_metadata_scroll(scroll_id, query_body, es_scroll_timeout):
    '''Get a subsequent batch of alerts with the scroll_id.'''
  
    request_url = "/" + "_search/scroll"
    
    # Update the scroll.
    query_body['scroll'] = es_scroll_timeout
    query_body['scroll_id'] = scroll_id
    
    data = json.dumps(query_body)
    
    response = cea.es_get_request(request_url, data, logger)
    
    return response.json()
          
def process_slice(es_version, slice_id, csv_writer, query_body, scroll_body, alerts_indices, es_scroll_timeout):
    '''Search for alerts in one slice.'''
    last_status = time.time()
    stats_count = 0
    total_alerts = 0
    
    logger.info('Slice[%d] Starting search...', slice_id)
    
    results = get_alert_metadata_search(es_version, slice_id, query_body, alerts_indices, es_scroll_timeout)
    
    failed_shards = results['_shards']['failed']
    
    if failed_shards != 0:
        logger.error('Could not search alerts. Shards failed: %d', failed_shards)
        os._exit(1)
        
    if es_version == cea.VERSION_ES5:
        total_hits = results['hits']['total']
    else:
        total_hits = results['hits']['total']['value']
    
    logger.info('Slice[%d] Total hits: %d', slice_id, total_hits)
    
    hits = results['hits']['hits']
      
    while total_hits > 0 and len(hits) > 0:
        # Save a batch of alerts metadata.
        for hit in hits:
            source = hit['_source'] 
            inner_source = hit['inner_hits']['message']['hits']['hits'][0]['_source']
            
            message_id = inner_source['message_id']
            ki_id = source['key_indicator_id']
            ki_name = ki_by_id[ki_id]
            document_date = inner_source['document_date']
            ingestion_date = inner_source['ingestion_date']
            status = source.get('status','')
            resolved = source.get('resolved','')
            assignee = source.get('assignee','')
            
            alert_data_permissions = ''
            if 'alert_data_permissions' in source:
                alert_data_permissions = ','.join(map(str,source['alert_data_permissions']))
            
            message_data_permissions = ''
            if 'message_data_permissions' in source:
                message_data_permissions = ','.join(map(str,source['message_data_permissions']))
                        
            senders_email = ''                  
            if 'senders' in inner_source:
                senders_email_list = []
                senders = inner_source['senders']
                for sender in senders:
                    sender_email = sender.get('sender_email_lc')
                    if sender_email is not None:
                        senders_email_list.append(sender_email)
                 
                senders_email = ','.join(map(str,senders_email_list))
                           
            receivers_email = ''                  
            if 'receivers' in inner_source:
                receivers_email_list = []
                receivers = inner_source['receivers']
                for receiver in receivers:
                    receiver_email = receiver.get('receiver_email_lc')
                    if receiver_email is not None:
                        receivers_email_list.append(receiver_email)
                 
                receivers_email = ','.join(map(str,receivers_email_list))
            
            subject = inner_source.get('subject','')
                               
            csv_writer.writerow([message_id,ki_id,ki_name,document_date,ingestion_date,status,resolved,assignee,alert_data_permissions,message_data_permissions,senders_email,receivers_email,subject])
            total_alerts += 1
            stats_count += 1
    
        scroll_id = results['_scroll_id']
                
        cur_time = time.time()
        if cur_time - last_status >= cea.get_logging_status_interval():
            exec_time = cur_time - last_status
            docs_per_sec = stats_count / exec_time if stats_count > 0 else 0
            logger.info('Slice[%d] Processed: %d - %s, docs/sec: %.0f', 
                slice_id, total_alerts, f'{(total_alerts / total_hits):.0%} complete', docs_per_sec)
            
            last_status = cur_time
            stats_count = 0
            
        results = get_alert_metadata_scroll(scroll_id, scroll_body, es_scroll_timeout)
        
        failed_shards = results['_shards']['failed']
    
        if failed_shards != 0:
            logger.error('Could not search alerts. Shards failed: %d', failed_shards)
            os._exit(1)
                
        hits = results['hits']['hits']
    
    logger.info('Slice[%d] Completed search, total hits: %d, processed: %d', slice_id, total_hits, total_alerts)
    
    return total_alerts

def save_alert_metadata_to_csv(es_version, es_slices, es_scroll_timeout, query_body, scroll_body, alerts_indices):
    '''Save alert metadata to a CSV file.'''

    total_alerts = 0
        
    logger.info('Searching alerts with %d slices...', es_slices)
    
    start_exec = time.time()
    with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as output:
        csv_writer = csv.writer(output, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        csv_writer.writerow(CSV_HEADERS)
        logger.debug('CSV_HEADERS: %s', CSV_HEADERS)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=es_slices) as executor:
            futures = []
            for slice_id in range(es_slices):
                futures.append(executor.submit(process_slice, es_version=es_version, slice_id=slice_id, csv_writer=csv_writer, query_body=copy.deepcopy(query_body), scroll_body=copy.deepcopy(scroll_body), alerts_indices=alerts_indices, es_scroll_timeout=es_scroll_timeout))
            
            for future in concurrent.futures.as_completed(futures):
                total_alerts += future.result()              
            
    end_exec = time.time()    
    exec_time = end_exec - start_exec
    exec_mins = exec_time / 60
    docs_per_sec = total_alerts / exec_time if total_alerts > 0 else 0
    
    logger.info('Found %d alerts in %.2f minutes, docs/sec: %.0f', total_alerts, exec_mins, docs_per_sec)

def init_query(es_version, query_body, es_slices, es_search_batch_size):
    '''Initialize the query for slicing and ES 7.'''
    
    # Needed for all ES versions.
    esslice = json.loads(JSON_SLICE)
    esslice['slice']['max'] = es_slices
    query_body.update(esslice)  
    size = json.loads(JSON_SIZE)
    size['size'] = es_search_batch_size
    query_body.update(size)    
    query_body.update(json.loads(JSON_SORT))
    
    if es_version == cea.VERSION_ES5: 
        return query_body
        
    # The following are for ES7+.
    query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))
    
    # "query" must be present.
    if 'query' not in query_body:
        raise ValueError('JSON query is missing the "query" field.')
        
    # "bool" must be present.
    if 'bool' not in query_body['query']:
        raise ValueError('JSON query is missing the "bool" field.')
      
    # Add "filter" if missing.  
    if 'filter' not in query_body['query']['bool']:
        query_body['query']['bool']['filter'] = []

    # Add doc_type filter.
    query_body['query']['bool']['filter'].append(json.loads(JSON_ALERTS_DOC_TYPE_FILTER))
    
    return query_body
 
def main(argparser):
    '''Start of main.'''
    
    args = argparser.parse_args()

    kg_name = args.kg_name
    query_file = args.query_file
    
    # Options
    es_hosts = cea.get_option_as_str(args, cea.OPTION_ES_HOSTS, cea.ENV_ES_HOSTS, default_value=cea.DEFAULT_ES_HOSTS)
    es_user = cea.get_option_as_str(args, cea.OPTION_ES_USER, cea.ENV_ES_USER, default_value=cea.DEFAULT_ES_USER)
    es_password = cea.get_option_as_str(args, cea.OPTION_ES_PASSWORD, cea.ENV_ES_PASSWORD, default_value=cea.DEFAULT_ES_PASSWORD)
    es_use_tls = cea.get_option_as_bool(args, cea.OPTION_ES_USE_TLS, cea.ENV_ES_USE_TLS, cea.DEFAULT_ES_USE_TLS)
    es_use_hosts = cea.get_option_as_bool(args, cea.OPTION_ES_USE_HOSTS, cea.ENV_ES_USE_HOSTS, cea.DEFAULT_ES_USE_HOSTS)
    es_use_hostname = cea.get_option_as_bool(args, cea.OPTION_ES_USE_HOSTNAME, cea.ENV_ES_USE_HOSTNAME, cea.DEFAULT_ES_USE_HOSTNAME)
    es_connect_timeout = cea.get_option_as_int(argparser, args, cea.OPTION_ES_CONNECT_TIMEOUT, cea.ENV_ES_CONNECT_TIMEOUT, cea.DEFAULT_ES_CONNECT_TIMEOUT, cea.MIN_ES_CONNECT_TIMEOUT)
    es_read_timeout = cea.get_option_as_int(argparser, args, cea.OPTION_ES_READ_TIMEOUT, cea.ENV_ES_READ_TIMEOUT, cea.DEFAULT_ES_READ_TIMEOUT, cea.MIN_ES_READ_TIMEOUT)
    es_scroll_timeout = cea.get_option_as_str(args, cea.OPTION_ES_SCROLL_TIMEOUT, cea.ENV_ES_SCROLL_TIMEOUT, default_value=cea.DEFAULT_ES_SCROLL_TIMEOUT)
    es_slices = cea.get_option_as_int(argparser, args, cea.OPTION_ES_SLICES, cea.ENV_ES_SLICES, cea.DEFAULT_ES_SLICES, cea.MIN_ES_SLICES)
    es_search_batch_size = cea.get_option_as_int(argparser, args, cea.OPTION_ES_SEARCH_BATCH_SIZE, cea.ENV_ES_SEARCH_BATCH_SIZE, cea.DEFAULT_ES_SEARCH_BATCH_SIZE, cea.MIN_ES_SEARCH_BATCH_SIZE)
    
    logging_level = cea.get_option_as_str(args, cea.OPTION_LOGGING_LEVEL, cea.ENV_LOGGING_LEVEL, default_value=cea.DEFAULT_LOGGING_LEVEL)
    logging_status_interval = cea.get_option_as_int(argparser, args, cea.OPTION_LOGGING_STATUS_INTERVAL, cea.ENV_LOGGING_STATUS_INTERVAL, cea.DEFAULT_LOGGING_STATUS_INTERVAL, cea.MIN_LOGGING_STATUS_INTERVAL)
      
    global logger
    logger = cea.get_logger(__file__, logging_level, logging_status_interval)
       
    logger.info('Starting...')       
    
    kis_index = kg_name + KIS_INDEX_PATTERN
    alerts_indices = kg_name + ALERTS_INDEX_PATTERN
    
    logger.info('KG name: %s', kg_name) 
    logger.info('Query file: %s', query_file)
    logger.info('KIs index: %s', kis_index)
    logger.info('Alerts indices: %s', alerts_indices)    
    
    logger.info('ES hosts: %s', es_hosts)
    logger.info('ES user: %s', es_user)
    logger.info('ES password: %s', ''.rjust(len(es_password),'*'))
    logger.info('ES use TLS: %s', es_use_tls)
    logger.info('ES use hosts: %s', es_use_hosts)
    logger.info('ES use hostname: %s', es_use_hostname)
    logger.info('ES connect timeout: %d', es_connect_timeout)
    logger.info('ES read timeout: %d', es_read_timeout)
    logger.info('ES scroll timeout: %s', es_scroll_timeout)
    logger.info('ES slices: %d', es_slices)
    logger.info('ES search batch size: %d', es_search_batch_size)
          
    es_version = cea.init_es(es_hosts, es_user, es_password, es_use_tls, es_use_hosts, es_use_hostname, es_connect_timeout, es_read_timeout, logger)
        
    init_ki_names(es_version, kis_index)
       
    with open(query_file, 'r', encoding='utf-8') as f:
        query_body = json.load(f)  
        logger.debug('Loaded ES query: %s', json.dumps(query_body))
    
    query_body = init_query(es_version, query_body, es_slices, es_search_batch_size)  
    logger.debug('Inited ES query body: %s', json.dumps(query_body))
    
    scroll_body = json.loads(JSON_SCROLL_BODY)
       
    save_alert_metadata_to_csv(es_version, es_slices, es_scroll_timeout, query_body, scroll_body, alerts_indices) 
                                       
    logger.info('Done.')                  
    
if __name__ == '__main__':    
    parser = argparse.ArgumentParser(description='Search and save alert metadata to a CSV file for a KG.')
    parser.add_argument('kg_name', help='CSurv KG name.', type=str)
    parser.add_argument('query_file', help='JSON file containing the ES query')
    
    parser.add_argument(cea.OPTION_ES_HOSTS, type=str, help=cea.HELP_ES_HOSTS)
    parser.add_argument(cea.OPTION_ES_USER, type=str, help=cea.HELP_ES_USER)
    parser.add_argument(cea.OPTION_ES_PASSWORD, type=str, help=cea.HELP_ES_PASSWORD)
    parser.add_argument(cea.OPTION_ES_USE_TLS, action='store_true', help=cea.HELP_ES_USE_TLS)    
    parser.add_argument(cea.OPTION_ES_USE_HOSTS, action='store_true', help=cea.HELP_ES_USE_HOSTS)  
    parser.add_argument(cea.OPTION_ES_USE_HOSTNAME, action='store_true', help=cea.HELP_ES_USE_HOSTNAME)  
    parser.add_argument(cea.OPTION_ES_CONNECT_TIMEOUT, type=int, help=cea.HELP_ES_CONNECT_TIMEOUT)  
    parser.add_argument(cea.OPTION_ES_READ_TIMEOUT, type=int, help=cea.HELP_ES_READ_TIMEOUT)  
    parser.add_argument(cea.OPTION_ES_SCROLL_TIMEOUT, type=int, help=cea.HELP_ES_SCROLL_TIMEOUT)  
    parser.add_argument(cea.OPTION_ES_SLICES, type=int, help=cea.HELP_ES_SLICES)  
    parser.add_argument(cea.OPTION_ES_SEARCH_BATCH_SIZE, type=int, help=cea.HELP_ES_SEARCH_BATCH_SIZE)  
    
    parser.add_argument(cea.OPTION_LOGGING_LEVEL, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], help=cea.HELP_LOGGING_LEVEL)
    parser.add_argument(cea.OPTION_LOGGING_STATUS_INTERVAL, type=int, help=cea.HELP_LOGGING_STATUS_INTERVAL)
    
    main(parser)
