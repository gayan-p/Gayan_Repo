command:

python3 csurv_export_alert_metadata.py --es-host localhost:9200 --es-use-tls --es-user xxxx --es-password xxxx KGname All_open_alerts_new.json

