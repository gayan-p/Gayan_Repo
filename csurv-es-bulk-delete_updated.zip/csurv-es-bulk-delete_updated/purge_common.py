import argparse
import logging
from logging.handlers import RotatingFileHandler
import os
import requests
import csv
import threading
import re
from datetime import datetime, timezone
from requests.exceptions import ConnectionError
from urllib3.exceptions import InsecureRequestWarning

#
# Misc. utilities for purge scripts.
#

#
# Constants
#

OPTION_ES_HOSTS                     = '--es-host'
OPTION_ES_USER                      = '--es-user'
OPTION_ES_PASSWORD                  = '--es-password'
OPTION_ES_USE_TLS                   = '--es-use-tls'
OPTION_ES_USE_HOSTS                 = '--es-use-hosts'
OPTION_ES_USE_HOSTNAME              = '--es-use-hostname'
OPTION_ES_CONNECT_TIMEOUT           = '--es-connect-timeout'
OPTION_ES_READ_TIMEOUT              = '--es-read-timeout'
OPTION_ES_SCROLL_TIMEOUT            = '--es-scroll-timeout'
OPTION_ES_SLICES_PER_SHARD          = '--es-slices-per-shard'
OPTION_ES_SEARCH_BATCH_SIZE         = '--es-search-batch-size'
OPTION_ES_DELETE_BATCH_SIZE         = '--es-delete-batch-size'
OPTION_ES_DELETE_THREADS            = '--es-delete-threads'
OPTION_ES_DELETE_BY_INDEX           = '--es-delete-by-index'
OPTION_ES_NON_ALERTED_QUERY_FILE    = '--es-non-alerted-query-file'
OPTION_ES_ALERTED_QUERY_FILE        = '--es-alerted-query-file'
OPTION_ES_COUNTRY_FIELD             = '--es-country-field'
OPTION_ES_PARTICIPANT_COUNTRIES     = '--es-participant-countries'
OPTION_ES_KI_NAMES                  = '--es-ki-names'
OPTION_ES_ALERT_STATUS              = '--es-alert-status'
OPTION_ES_START_DATE                = '--es-start-date'
OPTION_GCS_PROJECT                  = '--gcs-project'
OPTION_GCS_CREDENTIALS_FILE         = '--gcs-credentials-file'
OPTION_GCS_CONNECT_TIMEOUT          = '--gcs-connect-timeout'
OPTION_GCS_READ_TIMEOUT             = '--gcs-read-timeout'
OPTION_GCS_DELETE_BATCH_SIZE        = '--gcs-delete-batch-size'
OPTION_GCS_DELETE_THREADS           = '--gcs-delete-threads'
OPTION_LOGGING_FILE_NAME            = '--logging-file-name'
OPTION_LOGGING_MAX_SIZE             = '--logging-max-size'
OPTION_LOGGING_MAX_FILES            = '--logging-max-files'
OPTION_LOGGING_LEVEL                = '--logging-level'
OPTION_LOGGING_STATUS_INTERVAL      = '--logging-status-interval'

ENV_ES_HOSTS                        = 'ES_HOSTS'
ENV_ES_USER                         = 'ES_USER'
ENV_ES_PASSWORD                     = 'ES_PASSWORD'
ENV_ES_USE_TLS                      = 'ES_USE_TLS'
ENV_ES_USE_HOSTS                    = 'ES_USE_HOSTS'
ENV_ES_USE_HOSTNAME                 = 'ES_USE_HOSTNAME'
ENV_ES_CONNECT_TIMEOUT              = 'ES_CONNECT_TIMEOUT'
ENV_ES_READ_TIMEOUT                 = 'ES_READ_TIMEOUT'
ENV_ES_SCROLL_TIMEOUT               = 'ES_SCROLL_TIMEOUT'
ENV_ES_SLICES_PER_SHARD             = 'ES_SLICES_PER_SHARD'
ENV_ES_SEARCH_BATCH_SIZE            = 'ES_SEARCH_BATCH_SIZE'
ENV_ES_DELETE_BATCH_SIZE            = 'ES_DELETE_BATCH_SIZE'
ENV_ES_DELETE_THREADS               = 'ES_DELETE_THREADS'
ENV_ES_DELETE_BY_INDEX              = 'ES_DELETE_BY_INDEX'
ENV_ES_NON_ALERTED_QUERY_FILE       = 'ES_NON_ALERTED_QUERY_FILE'
ENV_ES_ALERTED_QUERY_FILE           = 'ES_ALERTED_QUERY_FILE'
ENV_ES_COUNTRY_FIELD                = 'ES_COUNTRY_FIELD'
ENV_ES_PARTICIPANT_COUNTRIES        = 'ES_PARTICIPANT_COUNTRIES'
ENV_ES_KI_NAMES                     = 'ES_KI_NAMES'
ENV_ES_ALERT_STATUS                 = 'ES_ALERT_STATUS'
ENV_ES_START_DATE                   = 'ES_START_DATE'
ENV_GCS_PROJECT                     = 'GCS_PROJECT'
ENV_GCS_CREDENTIALS_FILE            = 'GCS_CREDENTIALS_FILE'
ENV_GCS_CONNECT_TIMEOUT             = 'GCS_CONNECT_TIMEOUT'
ENV_GCS_READ_TIMEOUT                = 'GCS_READ_TIMEOUT'
ENV_GCS_DELETE_BATCH_SIZE           = 'GCS_DELETE_BATCH_SIZE'
ENV_GCS_DELETE_THREADS              = 'GCS_DELETE_THREADS'
ENV_GOOGLE_CLOUD_PROJECT            = 'GOOGLE_CLOUD_PROJECT'
ENV_GOOGLE_APPLICATION_CREDENTIALS  = 'GOOGLE_APPLICATION_CREDENTIALS'
ENV_LOGGING_FILE_NAME               = 'LOGGING_FILE_NAME'
ENV_LOGGING_MAX_SIZE                = 'LOGGING_MAX_SIZE'
ENV_LOGGING_MAX_FILES               = 'LOGGING_MAX_FILES'
ENV_LOGGING_LEVEL                   = 'LOGGING_LEVEL'
ENV_LOGGING_STATUS_INTERVAL         = 'LOGGING_STATUS_INTERVAL'

DEFAULT_ES_HOSTS                    = 'localhost:9200'
DEFAULT_ES_PORT                     = 9200
DEFAULT_ES_USER                     = 'elastic'
DEFAULT_ES_PASSWORD                 = ''
DEFAULT_ES_USE_TLS                  = False
DEFAULT_ES_USE_HOSTS                = False
DEFAULT_ES_USE_HOSTNAME             = False
DEFAULT_ES_CONNECT_TIMEOUT          = 60
DEFAULT_ES_READ_TIMEOUT             = 300
DEFAULT_ES_SCROLL_TIMEOUT           = '5m'
DEFAULT_ES_SLICES_PER_SHARD         = 2
DEFAULT_ES_SEARCH_BATCH_SIZE        = 5000
DEFAULT_ES_DELETE_BATCH_SIZE        = 10000
DEFAULT_ES_DELETE_THREADS           = 10
DEFAULT_ES_DELETE_BY_INDEX          = False
DEFAULT_ES_NON_ALERTED_QUERY_FILE  = 'no_alerts_query.json'
DEFAULT_ES_ALERTED_QUERY_FILE      = 'match_all_query.json'
DEFAULT_ES_COUNTRY_FIELD            = 'Country'
DEFAULT_ES_PARTICIPANT_COUNTRIES    = None
DEFAULT_ES_KI_NAMES                 = None
DEFAULT_ES_ALERT_STATUS             = None
DEFAULT_ES_START_DATE               = None
DEFAULT_GCS_PROJECT                 = None
DEFAULT_GCS_CREDENTIALS_FILE        = None
DEFAULT_GCS_CONNECT_TIMEOUT         = 60
DEFAULT_GCS_READ_TIMEOUT            = 300
DEFAULT_GCS_DELETE_BATCH_SIZE       = 100
DEFAULT_GCS_DELETE_THREADS          = 10
DEFAULT_LOGGING_FILE_NAME           = 'csurv_purge_expired_messages.log'
DEFAULT_LOGGING_MAX_SIZE            = 10000000
DEFAULT_LOGGING_MAX_FILES           = 10
DEFAULT_LOGGING_LEVEL               = 'INFO'
DEFAULT_LOGGING_STATUS_INTERVAL     = 300

MIN_ES_CONNECT_TIMEOUT              = 1
MIN_ES_READ_TIMEOUT                 = 1
MIN_ES_SLICES_PER_SHARD             = 1
MIN_ES_SEARCH_BATCH_SIZE            = 1
MIN_ES_DELETE_BATCH_SIZE            = 1
MIN_ES_DELETE_THREADS               = 1
MIN_GCS_CONNECT_TIMEOUT             = 1
MIN_GCS_READ_TIMEOUT                = 1
MIN_GCS_DELETE_BATCH_SIZE           = 1
MIN_GCS_DELETE_THREADS              = 1
MIN_LOGGING_MAX_SIZE                = 10000
MIN_LOGGING_MAX_FILES               = 1
MIN_LOGGING_STATUS_INTERVAL         = 10

# Return the environment variable and default option value as a string.
def get_env_and_default(*env_var, default_value):
    return ' (Env: ' + ' or '.join(env_var) + ', Default: ' + str(default_value) + ')'
 
HELP_ES_HOSTS                       = 'Comma-separated list of ES hosts or IP addresses with optional ports. The default port is ' + str(DEFAULT_ES_PORT) + '.'
HELP_ES_USER                        = 'ES user name.'
HELP_ES_PASSWORD                    = 'ES password.'
HELP_ES_USE_TLS                     = 'If set, use HTTPS for ES connections. Otherwise, use HTTP.'
HELP_ES_USE_HOSTS                   = 'If set, use ES_HOSTS for connecting to ES. Otherwise, use the sniffer to discover ES data nodes and only use them for requests.'
HELP_ES_USE_HOSTNAME                = 'If set and sniffing, connect to ES data nodes using their hostname. Otherwise, use their IP address.'
HELP_ES_CONNECT_TIMEOUT             = 'ES connection timeout in seconds.'
HELP_ES_READ_TIMEOUT                = 'ES read timeout in seconds.'
HELP_ES_SCROLL_TIMEOUT              = 'ES scroll timeout.'
HELP_ES_SLICES_PER_SHARD            = 'Number of ES slices/threads per shard to use when searching.'
HELP_ES_SEARCH_BATCH_SIZE           = 'Batch size for an ES scrolled search request.'
HELP_ES_DELETE_BATCH_SIZE           = 'Batch size for an ES bulk delete request.'
HELP_ES_DELETE_THREADS              = 'Number of worker threads for ES deletions.'
HELP_ES_DELETE_BY_INDEX             = 'If set, delete an index if all messages have expired. Otherwise, delete individual expired messages.'
HELP_ES_NON_ALERTED_QUERY_FILE      = 'ES query file for non-alerted indices.'
HELP_ES_ALERTED_QUERY_FILE          = 'ES query file for alerted indices.'
HELP_ES_COUNTRY_FIELD               = 'Name of "country" metadata field in the ES participants.'
HELP_ES_PARTICIPANT_COUNTRIES       = 'Comma-separated list of participant countries (case-insensitive). Use "None" or "Null" for participants without a country.  Use a single \ to escape a comma in a country name.'
HELP_ES_KI_NAMES                    = 'Comma-separated list of key indicator names (case-sensitive). Use a single \ to escape a comma in a key indicator name.'
HELP_ES_ALERT_STATUS                = 'Comma-separated list of alert status values (case-sensitive). Use a single \ to escape a comma in an alert status.'
HELP_ES_START_DATE                  = 'Search only indices greater or equal to this date.'
HELP_GCS_PROJECT                    = 'GCS project name.'
HELP_GCS_CREDENTIALS_FILE           = 'GCS project credentials file in a JSON format.'
HELP_GCS_CONNECT_TIMEOUT            = 'GCS connection timeout in seconds.'
HELP_GCS_READ_TIMEOUT               = 'GCS read timeout in seconds.'
HELP_GCS_DELETE_BATCH_SIZE          = 'Batch size for a GCS bulk delete request.'
HELP_GCS_DELETE_THREADS             = 'Number of worker threads for GCS deletions.'
HELP_LOGGING_FILE_NAME              = 'Log file path. Parent directories in the path must already exist.'
HELP_LOGGING_MAX_SIZE               = 'Maximum size in bytes for a log file before rollover.'
HELP_LOGGING_MAX_FILES              = 'Maximum number of log files to save.'
HELP_LOGGING_LEVEL                  = 'Log level.'
HELP_LOGGING_STATUS_INTERVAL        = 'Number of seconds between logging status updates.'
 
HELP_ES_HOSTS                       += get_env_and_default(ENV_ES_HOSTS, default_value=DEFAULT_ES_HOSTS)
HELP_ES_USER                        += get_env_and_default(ENV_ES_USER, default_value=DEFAULT_ES_USER)
HELP_ES_PASSWORD                    += get_env_and_default(ENV_ES_PASSWORD, default_value=DEFAULT_ES_PASSWORD)
HELP_ES_USE_TLS                     += get_env_and_default(ENV_ES_USE_TLS, default_value=DEFAULT_ES_USE_TLS)
HELP_ES_USE_HOSTS                   += get_env_and_default(ENV_ES_USE_HOSTS, default_value=DEFAULT_ES_USE_HOSTS)
HELP_ES_USE_HOSTNAME                += get_env_and_default(ENV_ES_USE_HOSTNAME, default_value=DEFAULT_ES_USE_HOSTNAME)
HELP_ES_CONNECT_TIMEOUT             += get_env_and_default(ENV_ES_CONNECT_TIMEOUT, default_value=DEFAULT_ES_CONNECT_TIMEOUT)
HELP_ES_READ_TIMEOUT                += get_env_and_default(ENV_ES_READ_TIMEOUT, default_value=DEFAULT_ES_READ_TIMEOUT)
HELP_ES_SCROLL_TIMEOUT              += get_env_and_default(ENV_ES_SCROLL_TIMEOUT, default_value=DEFAULT_ES_SCROLL_TIMEOUT)
HELP_ES_SLICES_PER_SHARD            += get_env_and_default(ENV_ES_SLICES_PER_SHARD, default_value=DEFAULT_ES_SLICES_PER_SHARD)
HELP_ES_SEARCH_BATCH_SIZE           += get_env_and_default(ENV_ES_SEARCH_BATCH_SIZE, default_value=DEFAULT_ES_SEARCH_BATCH_SIZE)
HELP_ES_DELETE_BATCH_SIZE           += get_env_and_default(ENV_ES_DELETE_BATCH_SIZE, default_value=DEFAULT_ES_DELETE_BATCH_SIZE)
HELP_ES_DELETE_THREADS              += get_env_and_default(ENV_ES_DELETE_THREADS, default_value=DEFAULT_ES_DELETE_THREADS)
HELP_ES_DELETE_BY_INDEX             += get_env_and_default(ENV_ES_DELETE_BY_INDEX, default_value=DEFAULT_ES_DELETE_BY_INDEX)
HELP_ES_NON_ALERTED_QUERY_FILE      += get_env_and_default(ENV_ES_NON_ALERTED_QUERY_FILE, default_value=DEFAULT_ES_NON_ALERTED_QUERY_FILE)
HELP_ES_ALERTED_QUERY_FILE          += get_env_and_default(ENV_ES_ALERTED_QUERY_FILE, default_value=DEFAULT_ES_ALERTED_QUERY_FILE)
HELP_ES_COUNTRY_FIELD               += get_env_and_default(ENV_ES_COUNTRY_FIELD, default_value=DEFAULT_ES_COUNTRY_FIELD)
HELP_ES_PARTICIPANT_COUNTRIES       += get_env_and_default(ENV_ES_PARTICIPANT_COUNTRIES, default_value=DEFAULT_ES_PARTICIPANT_COUNTRIES)
HELP_ES_KI_NAMES                    += get_env_and_default(ENV_ES_KI_NAMES, default_value=DEFAULT_ES_KI_NAMES)
HELP_ES_ALERT_STATUS                += get_env_and_default(ENV_ES_ALERT_STATUS, default_value=DEFAULT_ES_ALERT_STATUS)
HELP_ES_START_DATE                  += get_env_and_default(ENV_ES_START_DATE, default_value=DEFAULT_ES_START_DATE)
HELP_GCS_PROJECT                    += get_env_and_default(ENV_GCS_PROJECT, ENV_GOOGLE_CLOUD_PROJECT, default_value=DEFAULT_GCS_PROJECT)
HELP_GCS_CREDENTIALS_FILE           += get_env_and_default(ENV_GCS_CREDENTIALS_FILE, ENV_GOOGLE_APPLICATION_CREDENTIALS, default_value=DEFAULT_GCS_CREDENTIALS_FILE)
HELP_GCS_CONNECT_TIMEOUT            += get_env_and_default(ENV_GCS_CONNECT_TIMEOUT, default_value=DEFAULT_GCS_CONNECT_TIMEOUT)
HELP_GCS_READ_TIMEOUT               += get_env_and_default(ENV_GCS_READ_TIMEOUT, default_value=DEFAULT_GCS_READ_TIMEOUT)
HELP_GCS_DELETE_BATCH_SIZE          += get_env_and_default(ENV_GCS_DELETE_BATCH_SIZE, default_value=DEFAULT_GCS_DELETE_BATCH_SIZE)
HELP_GCS_DELETE_THREADS             += get_env_and_default(ENV_GCS_DELETE_THREADS, default_value=DEFAULT_GCS_DELETE_THREADS)
HELP_LOGGING_FILE_NAME              += get_env_and_default(ENV_LOGGING_FILE_NAME, default_value=DEFAULT_LOGGING_FILE_NAME)
HELP_LOGGING_MAX_SIZE               += get_env_and_default(ENV_LOGGING_MAX_SIZE, default_value=DEFAULT_LOGGING_MAX_SIZE)
HELP_LOGGING_MAX_FILES              += get_env_and_default(ENV_LOGGING_MAX_FILES, default_value=DEFAULT_LOGGING_MAX_FILES)
HELP_LOGGING_LEVEL                  += get_env_and_default(ENV_LOGGING_LEVEL, default_value=DEFAULT_LOGGING_LEVEL)
HELP_LOGGING_STATUS_INTERVAL        += get_env_and_default(ENV_LOGGING_STATUS_INTERVAL, default_value=DEFAULT_LOGGING_STATUS_INTERVAL)
   
# Return an option value from the cmd line, env, or default. 
def get_option_as_str(args, option_name, *env_names, default_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value != None and option_value != '':
        return option_value
     
    for env_name in env_names:   
        env_value = os.getenv(env_name)
        if env_value != None and env_value != '':
            return env_value
     
    return default_value
       
def get_option_as_int(parser, args, option_name, env_name, default_value, min_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value != None:
        if option_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {option_value}, must be greater than or equal to {min_value}.') 
        return option_value
        
    env_value = int(os.getenv(env_name)) if os.getenv(env_name) != None else None
    if env_value != None:
        if env_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {env_value}, must be greater than or equal to {min_value}.')
        return env_value
        
    return default_value

def get_option_as_bool(args, option_name, env_name, default_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value == True:
        return option_value
    
    env_value = os.getenv(env_name).lower() == 'true' if os.getenv(env_name) != None else None    
    if env_value != None:
        return env_value
    
    return default_value

def get_option_as_datetime(parser, args, option_name, env_name, default_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value != None:
        try:
            date_value = datetime.strptime(option_value, '%Y-%m-%d').replace(hour=0,minute=0,second=0,microsecond=0,tzinfo=timezone.utc)
        except ValueError:  
            parser.error(option_name + '/' + env_name + f' = {option_value}, must be in the yyyy-mm-dd format.') 
        return date_value
        
    env_value = os.getenv(env_name)
    if env_value != None and env_value != '':
        try:
            date_value = datetime.strptime(env_value, '%Y-%m-%d').replace(hour=0,minute=0,second=0,microsecond=0,tzinfo=timezone.utc)
        except ValueError:  
            parser.error(option_name + '/' + env_name + f' = {option_value}, must be in the yyyy-mm-dd format.') 
        return date_value       
        
    return default_value
    
# Parse a comma-separated string and return a list. Commas in the string parts can be escaped with a \.
def cs_string_to_list(cs_string):
    # Split on commas that are not preceded by a backslash
    parts = re.split(r'(?<!\\),', cs_string)
    
    # Replace escaped commas with real commas in each part
    parts = [part.replace(r'\,', ',') for part in parts]
    
    return parts
    
# Get a comma-separated list of option values as a lower-case set.
def get_option_as_set(args, option_name, env_name, default_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value != None and option_value != '':
        return set(cs_string_to_list(option_value.lower()))
        
    env_value = os.getenv(env_name)
    if env_value != None and env_value != '':
        return set(cs_string_to_list(env_value.lower()))
        
    return default_value.lower() if default_value != None else None
    
# Get a comma-separated list of option values as a case-sensitive set.
def get_option_as_set_cs(args, option_name, env_name, default_value):
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value != None and option_value != '':
        return set(cs_string_to_list(option_value))
        
    env_value = os.getenv(env_name)
    if env_value != None and env_value != '':
        return set(cs_string_to_list(env_value))
        
    return default_value if default_value != None else None

#   
# Argument Validators
#

def validate_int(parser, arg_name, arg_value, min_value):
    if arg_value < min_value:
        parser.error(arg_name + f' = {arg_value}, must be greater than or equal to {min_value}.')
    return arg_value
       
#
# Logging
#
   
logging_status_interval = DEFAULT_LOGGING_STATUS_INTERVAL   

# Get the logging status interval.
def get_logging_status_interval():
    global logging_status_interval
    return logging_status_interval
    
# Init the logger.
def get_logger(name, file_name, max_size, max_files, level, status_interval = DEFAULT_LOGGING_STATUS_INTERVAL):
    name = os.path.basename(name)
    logger = logging.getLogger(name)
    
    if file_name == None or file_name == '' or file_name == 'none':
        logging.basicConfig(format='[%(asctime)s][%(name)s][%(levelname)s] %(message)s')
        
    else:
        handler = RotatingFileHandler(file_name, maxBytes=max_size, backupCount=max_files, encoding='utf-8')
        formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] %(message)s')    
    
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    logger.setLevel(level)
    
    global logging_status_interval
    logging_status_interval = status_interval
    
    return logger

#
# CSV Utilities
#

# Count the rows in a CSV file minus the header row.
def get_csv_row_count(csv_file):
    with open(csv_file, 'rb') as f:
        row_count = sum(1 for _ in f)
    return row_count - 1
    
#
# ES Utilities
#

QUERY_HEADERS               = {'Content-Type': 'application/json'}
BULK_HEADERS                = {'Content-Type': 'application/x-ndjson'}

DOC_TYPE_MESSAGE            = 'message'
DOC_TYPE_AUDIO              = 'audio'

INDEX_TYPE_NON_ALERTED      = 'non-alerted'
INDEX_TYPE_ALERTED          = 'alerted'
INDEX_TYPE_BOTH             = 'both'

MESSAGE_TYPES               = '__message_types_2'
MESSAGE_TYPES_ALERTS        = '__message_types_alerts_2'

# Supported ES versions.
VERSION_ES5 = '5'
VERSION_ES7 = '7'

# Check a no results response for errors.
def check_response(response, logger):
    logger.debug('check_response status_code: %s', response.status_code)
    if response.status_code == requests.codes.ok:
        return True
    elif response.status_code == requests.codes.not_found:
        return False
    else:
        logger.error('ES request error: %s', response.json())
        os._exit(1)      

# Check GET response for errors.
def check_get_response(response, logger):
    logger.debug('check_get_response status_code: %s', response.status_code)
    if response.status_code == requests.codes.ok:
        return response
    else:
        logger.error('ES GET error: %s', response.json())
        os._exit(1)     

# Check POST with results response for errors. 
def check_post_response(response, logger):
    if response.status_code != requests.codes.ok:
        logger.error('ES POST _bulk error: %s', response.json())
        os._exit(1)
        
    json_response = response.json()
    
    logger.debug('response: %s', json_response)
    
    deleted = 0
    not_found = 0
    
    for item in json_response['items']:
        if 'delete' in item:
            item_status = item['delete']
        else:
            logger.warn('Unexpected item in the bulk response: %s', item)
            continue
        
        logger.debug('item_status: %s', item_status)
        
        status = item_status['status']
        result = item_status['result']
        id = item_status['_id']
        index = item_status['_index']
            
        if status == requests.codes.ok and result == 'deleted':
            logger.debug('Message deleted. _id: %s, _index: %s', id, index)
            deleted += 1
                  
        elif status == requests.codes.not_found and result == 'not_found':
            logger.debug('Message not found. _id: %s, _index: %s', id, index)
            not_found += 1
                
        else:
            error = item_status.get('error', 'N/A')
            logger.error('Bulk command failed - _id: %s, _index: %s, status: %d, result: %s, error: %s', id, status, result, index, error)
            os._exit(1)
            
    return deleted, not_found

# Check POST _delete_by_query response for errors. 
def check_post_delete_response(response, logger):
    if response.status_code != requests.codes.ok:
        logger.error('ES POST delete error: %s', response.json())
        os._exit(1)
        
    json_response = response.json()
    
    logger.debug('response: %s', json_response)
    
    if json_response['timed_out']:
        logger.error('ES POST delete timed out.')
        os._exit(1)
    
    return json_response['deleted']
    
# ES HEAD request.
def es_head_request(request_url, logger):      
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):
        next_host = get_next_node()
        
        try: 
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES HEAD URL: %s', url)
            
            response = requests.head(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            
            return check_response(response, logger)
        except ConnectionError as ce:
            logger.error('Could not connect to ES: %s', ce)
            
    logger.error('ES HEAD request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)   
        
    
# ES GET request.
def es_get_request(request_url, es_body, logger):
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES GET URL: %s', url)
            logger.debug('ES GET body: %s', es_body)
            
            response = requests.get(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout),
                data=es_body,
                headers=QUERY_HEADERS if es_body != None else None                
            )
            
            return check_get_response(response, logger)
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES GET request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)
        
# ES POST request.
def es_post_request(request_url, es_body, logger):
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
   
            logger.debug('ES POST URL: %s', url)
            
            response = requests.post(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout),
                data=es_body,
                headers=BULK_HEADERS
            )
            return check_post_response(response, logger)
            
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)
    
# ES POST _delete_by_query request.
def es_post_delete_request(request_url, es_body, logger):
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
   
            logger.debug('ES POST URL: %s', url)
            
            response = requests.post(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout),
                data=es_body,
                headers=QUERY_HEADERS
            )
            return check_post_delete_response(response, logger)
            
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES POST _delete_by_query request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)

# POST with no body or return results.
def es_post_no_body_request(request_url, logger):
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):  
        next_host = get_next_node()
            
        try:
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
   
            logger.debug('ES POST URL: %s', url)
            
            response = requests.post(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            return check_response(response, logger)
            
        except ConnectionError as ce:
            logger.warn('Could not connect to ES: %s', ce)
            
    logger.error('ES POST request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)
    
# ES DELETE request.
def es_delete_request(request_url, logger):      
    global es_user
    global es_password
    global es_use_tls
    
    for retry in range(len(es_nodes)):
        next_host = get_next_node()
        
        try: 
            url = 'http{s}://{host}'.format(s=('s' if es_use_tls else ''),host=next_host) + request_url
             
            logger.debug('ES DELETE URL: %s', url)
            
            response = requests.delete(
                url,
                auth=(es_user, es_password),
                verify=False,
                timeout=(es_connect_timeout, es_read_timeout)
            )
            
            return check_response(response, logger)
        except ConnectionError as ce:
            logger.error('Could not connect to ES: %s', ce)
            
    logger.error('ES DELETE request failed. Could not connect to any ES host. Request: %s', url)
    os._exit(1)   

es_version = None
            
# Get the ES version and check if it is supported.
def check_es_version(logger):
    global es_version
    
    request_url = "/"
    
    response = es_get_request(request_url, None, logger)
    
    result = response.json()
    version_number = result['version']['number']
    es_version = version_number.split('.')[0]  
   
    if es_version is None and not (es_version == VERSION_ES5 or es_version == VERSION_ES7):
        logger.error('Unsupported ES version: %s', version_number)
        os._exit(1)
        
    return es_version 

es_nodes_lock = threading.Lock()  
es_nodes = list()
es_next_node = 0
es_user = ''
es_password = ''
es_use_tls = False
es_use_hostname = True
es_connect_timeout = 0
es_read_timeout = 0

# Initialize the ES environment.
def init_es(initial_hosts, user, password, use_tls, use_hosts, use_hostname, connect_timeout, read_timeout, logger):
    global es_nodes_lock
    global es_nodes
    global es_next_node
    global es_user
    global es_password
    global es_use_tls
    global es_use_hostname
    global es_connect_timeout
    global es_read_timeout
    
    # Silence https warnings
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
    
    initial_hosts = initial_hosts.split(',')
     
    data_nodes = list()   
    coord_nodes = list()   
    requested_nodes = list()
    
    es_nodes_lock.acquire() 
    
    # Try all of the initial hosts.
    for initial_host in initial_hosts:
        
        try:
            logger.debug('Trying initial host: %s', initial_host)
            
            # Add the default port if the port is not present.
            host_and_port = initial_host if ':' in initial_host else initial_host + ':' + str(DEFAULT_ES_PORT)
                
            base_url = 'http{s}://{host_and_port}'.format(s=('s' if use_tls else ''),host_and_port=host_and_port)
            
            url = base_url + '/_nodes/http'
        
            logger.debug('ES get hosts: %s', url)
        
            response = requests.get(
                url,
                auth=(user, password),
                verify=False,
                timeout=(connect_timeout, read_timeout)
            )
            response = check_get_response(response, logger)
            
            results = response.json()
            
            # If using sniffer, save the data hosts.
            if use_hosts == False:
                for node in results['nodes'].values():    
                    host = node['host']
                    ip = node['ip']
                    roles = node['roles']
                    
                    # Get the port from the published_address.
                    if 'published_address' in node['http'] and ':' in node['http']['published_address']:
                        host_part, port_part = node['http']['published_address'].split(':')
                        port = int(port_part)
                        logger.debug('Using published port: %d', port)
                    else:
                        port = DEFAULT_ES_PORT
                        logger.debug('Using default port: %d', port)
                            
                    # Check for a dedicated coordinator.
                    if 'master' not in roles and 'data' not in roles:  
                        # Save the host/IP plus port.
                        coord_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                        logger.debug('Saving coordinating node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                             
                    elif 'data' in node['roles']:                                                  
                        # Save the host/IP plus port.
                        data_nodes.append((host + ':' + str(port), ip  + ':' + str(port)))
                        logger.debug('Saving data node: %s, IP: %s, port: %d, roles: %s', host, ip, port, roles)
                    
                    else:
                        logger.debug('Non-data or coordinating node: %s', node)
                    
                if len(data_nodes) > 0 or len(coord_nodes) > 0:
                    break
            else:
                # No sniffer, use as-is.
                requested_nodes.append((host_and_port, host_and_port))
                    
        except ConnectionError as ce:
            logger.warn('Could not connect to configured ES host: %s', ce) 
     
    # Check if there is at least one coordinating node available.
    if len(requested_nodes) > 0:
        nodes = requested_nodes
        node_type = 'requested'
    if len(coord_nodes) > 0:
        nodes = coord_nodes
        node_type = 'coordinating'
    else:
        nodes = data_nodes
        node_type = 'data'
        
    if len(nodes) == 0:
        if use_hosts == False:
            logger.error('No ES data or coordinating nodes are available.')
        else:
            logger.error('Configured ES hosts are not available.')
        os._exit(1)
      
    es_nodes = nodes
    es_next_node = 0
    es_user = user
    es_password = password
    es_use_tls = use_tls
    es_use_hostname = use_hostname
    es_connect_timeout = connect_timeout
    es_read_timeout = read_timeout
    es_nodes_lock.release()    
    
    es_version = check_es_version(logger)  
    
    logger.info('ES version: %s', es_version)
    logger.info('ES hosts available: %d, type: %s', len(nodes), node_type)
      
    return es_version     
 
# Return the next node in the list.
def get_next_node():
    global es_nodes_lock
    global es_nodes
    global es_next_node
    global es_use_hostname
    
    es_nodes_lock.acquire()    
    node = es_nodes[es_next_node] 
    es_next_node += 1
    if es_next_node >= len(es_nodes):
        es_next_node = 0        
    es_nodes_lock.release()
    
    return node[0] if es_use_hostname else node[1] 

# Get the index type.
def get_index_type(index_name, logger):
    if MESSAGE_TYPES_ALERTS in index_name:  
        return INDEX_TYPE_ALERTED  
    elif MESSAGE_TYPES in index_name:
        return INDEX_TYPE_NON_ALERTED  
    else:
        logger.error('Index type not supported: %s'. index_name)
        os._exit(1)
        
# Check if a non-alerted index type.
def is_non_alerted_index(index_name, logger):
    return get_index_type(index_name, logger) == INDEX_TYPE_NON_ALERTED
    
# Check if an alerted index type.
def is_alerted_index(index_name, logger):
    return get_index_type(index_name, logger) == INDEX_TYPE_ALERTED
 
JSON_DOC_TYPE_QUERY = '{"query":{"bool":{"filter":{"term":{"doc_type":"' + DOC_TYPE_MESSAGE + '"}}}}}'
 
# Count all messages.
def count_all_messages(index_name, logger):
    if es_version == VERSION_ES5:
        request_url = '/' + index_name + '/' + DOC_TYPE_MESSAGE + '/' + '_count'
        es_body = None
    else:
        request_url = '/' + index_name + '/' + '_count'
        es_body = JSON_DOC_TYPE_QUERY
   
    response = es_get_request(request_url, es_body, logger)   
    
    results = response.json()
    
    failed_shards = results['_shards']['failed']
    
    if failed_shards != 0:
        logger.error('Could not count messages. %d shards failed.', failed_shards)
        os._exit(1)
    
    return results['count']

# Count messages with a query.
def count_messages(index_name, es_body, logger):
    if es_version == VERSION_ES5:
        request_url = '/' + index_name + '/' + DOC_TYPE_MESSAGE + '/' + '_count'
    else:
        request_url = '/' + index_name + '/' + '_count'
   
    response = es_get_request(request_url, es_body, logger)   
    
    results = response.json()
    
    failed_shards = results['_shards']['failed']
    
    if failed_shards != 0:
        logger.error('Could not count messages. %d shards failed.', failed_shards)
        os._exit(1)
    
    return results['count']
            
#       
# GCS Utilities
#
                   
# Init the required Google env variables.
def init_gcs_env(gcs_project, gcs_credentials_file):
    if gcs_project != None and gcs_project != '':
        env_value = os.getenv(ENV_GOOGLE_CLOUD_PROJECT)
        if env_value == None or env_value != gcs_project:
            os.environ[ENV_GOOGLE_CLOUD_PROJECT] = gcs_project
    
    if gcs_credentials_file != None and gcs_credentials_file != '':
        env_value = os.getenv(ENV_GOOGLE_APPLICATION_CREDENTIALS)
        if env_value == None or env_value != gcs_credentials_file:
            os.environ[ENV_GOOGLE_APPLICATION_CREDENTIALS] = gcs_credentials_file