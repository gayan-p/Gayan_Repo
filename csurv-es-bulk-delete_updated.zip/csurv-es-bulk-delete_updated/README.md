es_bulk_delete_messages_by_csv.py
This script deletes messages in ES listed in a CSV file that contains _index and _id columns from ES. It uses the ES Bulk API to delete in batches (default: 10,000). The batch size can optionally be configured. If a message is not found in the index, no error is produced, so the script can be rerun on a partially processed CSV file.

Usage
usage: es_bulk_delete_messages_by_csv.py [-h] [--es-host ES_HOST] [--es-user ES_USER]
                                  [--es-password ES_PASSWORD] [--es-use-tls]
                                  [--es-use-hosts] [--es-use-hostname]
                                  [--es-connect-timeout ES_CONNECT_TIMEOUT]
                                  [--es-read-timeout ES_READ_TIMEOUT]
                                  [--es-delete-batch-size ES_DELETE_BATCH_SIZE]
                                  [--es-delete-threads ES_DELETE_THREADS]
                                  [--logging-file-name LOGGING_FILE_NAME]
                                  [--logging-max-size LOGGING_MAX_SIZE]
                                  [--logging-max-files LOGGING_MAX_FILES]
                                  [--logging-level {DEBUG,INFO,WARNING,ERROR}]
                                  [--logging-status-interval LOGGING_STATUS_INTERVAL]
                                  csv_file

Bulk delete messages listed in a CSV file from ES.

positional arguments:
  csv_file              CSV file containing _index and _id for message
                        documents.

optional arguments:
  -h, --help            show this help message and exit
  --es-host ES_HOST     Comma-separated list of ES hosts or IP addresses with
                        optional ports. The default port is 9200. (Env:
                        ES_HOSTS, Default: localhost:9200)
  --es-user ES_USER     ES user name. (Env: ES_USER, Default: elastic)
  --es-password ES_PASSWORD
                        ES password. (Env: ES_PASSWORD, Default: )
  --es-use-tls          If set, use HTTPS for ES connections. Otherwise, use
                        HTTP. (Env: ES_USE_TLS, Default: False)
  --es-use-hosts        If set, use ES_HOSTS for connecting to ES. Otherwise,
                        use the sniffer to discover ES data nodes and only use
                        them for requests. (Env: ES_USE_HOSTS, Default: False)
  --es-use-hostname     If set and sniffing, connect to ES data nodes using
                        their hostname. Otherwise, use their IP address. (Env:
                        ES_USE_HOSTNAME, Default: False)
  --es-connect-timeout ES_CONNECT_TIMEOUT
                        ES connection timeout in seconds. (Env:
                        ES_CONNECT_TIMEOUT, Default: 60)
  --es-read-timeout ES_READ_TIMEOUT
                        ES read timeout in seconds. (Env: ES_READ_TIMEOUT,
                        Default: 300)
  --es-delete-batch-size ES_DELETE_BATCH_SIZE
                        Batch size for an ES bulk delete request. (Env:
                        ES_DELETE_BATCH_SIZE, Default: 10000)
  --es-delete-threads ES_DELETE_THREADS
                        Number of worker threads for ES deletions. (Env:
                        ES_DELETE_THREADS, Default: 10)
  --logging-file-name LOGGING_FILE_NAME
                        Log file path. Parent directories in the path must
                        already exist. (Env: LOGGING_FILE_NAME, Default:
                        csurv_purge_expired_messages.log)
  --logging-max-size LOGGING_MAX_SIZE
                        Maximum size in bytes for a log file before rollover.
                        (Env: LOGGING_MAX_SIZE, Default: 10000000)
  --logging-max-files LOGGING_MAX_FILES
                        Maximum number of log files to save. (Env:
                        LOGGING_MAX_FILES, Default: 10)
  --logging-level {DEBUG,INFO,WARNING,ERROR}
                        Log level. (Env: LOGGING_LEVEL, Default: INFO)
  --logging-status-interval LOGGING_STATUS_INTERVAL
                        Number of seconds between logging status updates.
                        (Env: LOGGING_STATUS_INTERVAL, Default: 300)

Example:-
es_bulk_delete_messages_by_csv.py --es-host localhost:9200 --es-use-tls true --es-user elastic --es-password changeme csv_file.csv 