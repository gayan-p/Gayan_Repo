import sys
import requests
import argparse
import json
import time
import logging
import os
import csv
import threading
import queue
import copy
from urllib3.exceptions import InsecureRequestWarning
import purge_common as pc

#
# Script to bulk delete CSurv 4.x messages from ES. This is written for ES 5.x and ES 7.x.
#

ROUTING_QUERY = '''
{
    "query": {
        "terms": {
            "_routing": []
        }
    }
}
'''

routing_query = json.loads(ROUTING_QUERY)

# Processed counts for a CSV.
csv_row_count       = 0
total_msgs          = 0
total_deleted       = 0
total_not_found     = 0
last_total_msgs     = 0

stats_lock = threading.Lock()

def init_stats(row_count):
    global csv_row_count
    global total_msgs
    global total_deleted
    global total_not_found
    global last_total_msgs 
    global last_status
    
    csv_row_count = row_count
    total_msgs = 0
    total_deleted = 0
    total_not_found = 0
    last_total_msgs = 0    
    last_status = time.time()

def update_counts(deleted, not_found):
    global total_deleted
    global total_msgs
    global total_not_found
    global stats_lock
    
    stats_lock.acquire()
    total_msgs += deleted + not_found
    total_deleted += deleted
    total_not_found += not_found
    stats_lock.release()
    
def print_stats():
    global csv_row_count
    global total_msgs
    global total_deleted
    global total_not_found
    global last_total_msgs 
    global last_status 
    global stats_lock
    
    stats_lock.acquire()   
    cur_time = time.time()
    if cur_time - last_status >= pc.get_logging_status_interval():
        exec_time = cur_time - last_status
        stats_count = total_msgs - last_total_msgs
        docs_per_sec = stats_count / exec_time if exec_time > 0 else stats_count
        logger.info('Processed %d - %s, deleted: %d, not found: %d, docs/sec: %.0f', total_msgs, '{:.0%} complete'.format(total_msgs / csv_row_count), total_deleted, total_not_found, docs_per_sec)
        last_total_msgs = total_msgs
        last_status = cur_time     
    stats_lock.release()
 
def get_last_status():
    global last_status 
    global stats_lock
    
    stats_lock.acquire()   
    ret_last_status = last_status 
    stats_lock.release()
    return ret_last_status

# Truncate audio IDs for ES 7.
def get_utf8_length(str):
    return len(str.encode('utf-8'))
   
def exceeds_max_length(id, max_length):
    return get_utf8_length(id) > max_length

MAX_ID_LEN          = 512
SEPARATOR_CHAR      = "#"
SUFFIX_LEN          = get_utf8_length(SEPARATOR_CHAR + pc.DOC_TYPE_AUDIO)
MAX_AUDIO_ID_LEN    = MAX_ID_LEN - SUFFIX_LEN
    
# Create an unique _id less than or equal to the 512 byte limit.
def create_unique_audio_ID(id):
    return truncate_ID(id, MAX_AUDIO_ID_LEN) + SEPARATOR_CHAR + pc.DOC_TYPE_AUDIO
    
def truncate_ID(id, max_length):
    if exceeds_max_length(id, max_length):
        return truncate_utf8_bytes(id, max_length)
    else:
        return id
    
def truncate_utf8_bytes(id, max_length):
    # Encode the string to bytes using the specified encoding
    encoded_bytes = id.encode('utf-8')
    
    # Truncate the bytes to the specified limit
    truncated_bytes = encoded_bytes[:max_length]
    
    # Try to decode the truncated bytes back to a string, ignoring incomplete characters
    while True:
        try:
            return truncated_bytes.decode('utf-8')
        except UnicodeDecodeError:
            # If decoding fails due to incomplete characters, remove the last byte and retry
            truncated_bytes = truncated_bytes[:-1]
    
# Refresh an index.
def refresh_index(index):
    request_url = '/' + index + '/_refresh'
    
    return pc.es_post_no_body_request(request_url, logger)
        
# Delete a batch of messages.
def delete_messages(es_body):
    request_url = '/' + '_bulk'
   
    return pc.es_post_request(request_url, es_body, logger)   
    
# Delete message children in an index.
def delete_message_children(index, message_ids, routing_query):
    request_url = '/' + index + '/_delete_by_query'
    
    routing_query['query']['terms']['_routing'] = message_ids
    
    es_body = json.dumps(routing_query)
    
    logger.debug('delete_message_children: %s', es_body)
    
    return pc.es_post_delete_request(request_url, es_body, logger)  

# Worker function to process items from the queue
def worker(worker_num, q, routing_query):
    logger.debug('[%d] Worker starting.', worker_num)
    exec_time = 0
    processed_count = 0
    while True:
        bulk_count_and_cmd = q.get()
        if bulk_count_and_cmd is None:
            docs_per_sec = processed_count / exec_time if processed_count > 0 and exec_time > 0 else 0
            logger.debug('[%d] Worker done. Processed: %d, docs/sec: %.0f', worker_num, processed_count, docs_per_sec)
            break
            
        # Track worker stats.
        bulk_count = bulk_count_and_cmd[0]
        message_bulk_cmd = bulk_count_and_cmd[1]
        audio_bulk_cmd = bulk_count_and_cmd[2]
        index_map = bulk_count_and_cmd[3]
        
        logger.debug('[%d] Deleting %d messages.', worker_num, bulk_count)
        
        start_time = time.time() 
        
        # Check if there are alert children to delete.
        if len(index_map) > 0:
            logger.debug('[%d] Deleting children: %s', worker_num, index_map)
        
            for index, message_ids in index_map.items():
                deleted_children = delete_message_children(index, message_ids, routing_query)
                logger.debug('[%d] Deleted children: %d', worker_num, deleted_children)
                
        logger.debug('[%d] Deleting messages: %s', worker_num, message_bulk_cmd)
        deleted, not_found = delete_messages(message_bulk_cmd)
        logger.debug('[%d] messages deleted: %d, not_found: %d', worker_num, deleted, not_found)
        
        # Try to delete any audio.
        logger.debug('[%d] Deleting audio: %s', worker_num, audio_bulk_cmd)
        audio_deleted, audio_not_found = delete_messages(audio_bulk_cmd)  
        logger.debug('[%d] audio deleted: %d, not_found: %d', worker_num, audio_deleted, audio_not_found)
        
        end_time = time.time() 
        exec_time += end_time - start_time
        processed_count += deleted + not_found        
        
        update_counts(deleted, not_found)
        
        if end_time - get_last_status() >= pc.get_logging_status_interval():
            print_stats()
            
        q.task_done()

# Process a CSV file.        
def process_csv(csv_file, es_version, batch_size, num_threads):
    global total_msgs
    global total_deleted
    global total_not_found
    
    logger.info('Counting messages...')
    row_count = pc.get_csv_row_count(csv_file)
    logger.info('CSV message count: %d', row_count)
    
    start_exec = time.time()    
     
    init_stats(row_count)
     
    q = queue.Queue(maxsize=num_threads * 2)
    
    # Create and start worker threads
    logger.debug('Starting workers...')
    threads = []
    for worker_num in range(num_threads):
        t = threading.Thread(target=worker, args=(worker_num, q, copy.deepcopy(routing_query)))
        t.start()
        threads.append(t)    
    logger.debug('Workers started.')
    
    logger.info('Starting bulk deletion...')
       
    index_set = set() 
    with open(csv_file, newline='', encoding='utf-8') as f:
        csv_reader = csv.DictReader(f)
        batch_count = 0
        message_bulk_cmd = ''
        audio_bulk_cmd = ''
        index_map = dict()
        for row in csv_reader:
            id = row.get('_id', None)
            
            if id == None or id == '':
                logger.info('_id missing in row: %s', row)
                update_counts(0,1)
                continue
            
            index = row.get('_index', None)
            
            if index == None or index == '':
                logger.info('_index missing in row: %s', row)
                update_counts(0,1)
                continue
                    
            # Save the index for a refresh at the end.
            if index not in index_set:
                index_set.add(index)
             
            # Check if an alerts index.   
            if pc.is_alerted_index(index, logger):
                if index in index_map:
                    message_ids = index_map[index]
                else:
                    message_ids = list()
                    index_map[index] = message_ids
                
                message_ids.append(id)
                        
            # Add a message to the batch.
            delete_obj = {}
            delete_obj['_id'] = id
            delete_obj['_index'] = index
            if es_version == pc.VERSION_ES5:
                delete_obj['_type'] = pc.DOC_TYPE_MESSAGE
                
            delete_cmd = {}
            delete_cmd['delete'] = delete_obj
                 
            delete_str =  json.dumps(delete_cmd)    
            logger.debug('Delete message: %s', delete_str)
             
            message_bulk_cmd += delete_str + '\n'
            
            # Add an audio to the batch.
            delete_obj = {}
            delete_obj['_id'] = id if es_version == pc.VERSION_ES5 else create_unique_audio_ID(id)
            delete_obj['_index'] = index
            if es_version == pc.VERSION_ES5:
                delete_obj['_type'] = pc.DOC_TYPE_AUDIO
                
            delete_cmd = {}
            delete_cmd['delete'] = delete_obj
                 
            delete_str =  json.dumps(delete_cmd)    
            logger.debug('Delete audio: %s', delete_str)
             
            audio_bulk_cmd += delete_str + '\n'
            
            batch_count += 1
            
            # Delete if at the batch size.
            if batch_count == batch_size:
                logger.debug('Bulk request: %s', message_bulk_cmd)
                q.put((batch_count,message_bulk_cmd,audio_bulk_cmd,index_map))               
                batch_count = 0
                message_bulk_cmd = ''
                audio_bulk_cmd = ''
                index_map = dict()
                
        # Delete the last batch.
        if batch_count > 0:
            logger.debug('Bulk request: %s', message_bulk_cmd)
            q.put((batch_count,message_bulk_cmd,audio_bulk_cmd,index_map)) 
    
    logger.info('All messages queued.')
    
    # Wait for all tasks in the queue to be processed
    q.join()
    
    logger.info('Queue was emptied.')
    
    # Stop worker threads
    logger.info('Signaling workers...')
    for _ in range(num_threads):
        q.put(None)        
    logger.info('Signaled workers.')
    
    logger.info('Waiting for workers to stop...')
    for t in threads:
        t.join()    
    logger.info('Workers stopped.')
    
    # Refresh the index. (There should only be one.)
    for index in index_set:
        logger.info('Refreshing index: %s', index)
        refresh_index(index)
                            
    end_exec = time.time()    
    exec_time = end_exec - start_exec
    exec_mins = exec_time / 60
    docs_per_sec = total_msgs / exec_time if exec_time > 0 else total_msgs
     
    logger.info('Processed %d messages in %.2f minutes, deleted: %d, not found: %d, docs/sec: %.0f', total_msgs, exec_mins, total_deleted, total_not_found, docs_per_sec)
    
    if total_msgs != row_count:
        logger.error('Total messages %d not equal to the CSV message count %d.', total_msgs, row_count)
        os._exit(1)
        
    return total_msgs
             
# Main program.
def main(parser):
    args = parser.parse_args()
    
    # Required args
    csv_file = args.csv_file
    
    # Options
    es_hosts = pc.get_option_as_str(args, pc.OPTION_ES_HOSTS, pc.ENV_ES_HOSTS, default_value=pc.DEFAULT_ES_HOSTS)
    es_user = pc.get_option_as_str(args, pc.OPTION_ES_USER, pc.ENV_ES_USER, default_value=pc.DEFAULT_ES_USER)
    es_password = pc.get_option_as_str(args, pc.OPTION_ES_PASSWORD, pc.ENV_ES_PASSWORD, default_value=pc.DEFAULT_ES_PASSWORD)
    es_use_tls = pc.get_option_as_bool(args, pc.OPTION_ES_USE_TLS, pc.ENV_ES_USE_TLS, pc.DEFAULT_ES_USE_TLS)
    es_use_hosts = pc.get_option_as_bool(args, pc.OPTION_ES_USE_HOSTS, pc.ENV_ES_USE_HOSTS, pc.DEFAULT_ES_USE_HOSTS)
    es_use_hostname = pc.get_option_as_bool(args, pc.OPTION_ES_USE_HOSTNAME, pc.ENV_ES_USE_HOSTNAME, pc.DEFAULT_ES_USE_HOSTNAME)
    es_connect_timeout = pc.get_option_as_int(parser, args, pc.OPTION_ES_CONNECT_TIMEOUT, pc.ENV_ES_CONNECT_TIMEOUT, pc.DEFAULT_ES_CONNECT_TIMEOUT, pc.MIN_ES_CONNECT_TIMEOUT)
    es_read_timeout = pc.get_option_as_int(parser, args, pc.OPTION_ES_READ_TIMEOUT, pc.ENV_ES_READ_TIMEOUT, pc.DEFAULT_ES_READ_TIMEOUT, pc.MIN_ES_READ_TIMEOUT)
    es_delete_batch_size = pc.get_option_as_int(parser, args, pc.OPTION_ES_DELETE_BATCH_SIZE, pc.ENV_ES_DELETE_BATCH_SIZE, pc.DEFAULT_ES_DELETE_BATCH_SIZE, pc.MIN_ES_DELETE_BATCH_SIZE)
    es_delete_threads = pc.get_option_as_int(parser, args, pc.OPTION_ES_DELETE_THREADS, pc.ENV_ES_DELETE_THREADS, pc.DEFAULT_ES_DELETE_THREADS, pc.MIN_ES_DELETE_THREADS)
    
    logging_file_name = pc.get_option_as_str(args, pc.OPTION_LOGGING_FILE_NAME, pc.ENV_LOGGING_FILE_NAME, default_value=pc.DEFAULT_LOGGING_FILE_NAME)
    logging_max_size = pc.get_option_as_int(parser, args, pc.OPTION_LOGGING_MAX_SIZE, pc.ENV_LOGGING_MAX_SIZE, pc.DEFAULT_LOGGING_MAX_SIZE, pc.MIN_LOGGING_MAX_SIZE)
    logging_max_files = pc.get_option_as_int(parser, args, pc.OPTION_LOGGING_MAX_FILES, pc.ENV_LOGGING_MAX_FILES, pc.DEFAULT_LOGGING_MAX_FILES, pc.MIN_LOGGING_MAX_FILES)
    logging_level = pc.get_option_as_str(args, pc.OPTION_LOGGING_LEVEL, pc.ENV_LOGGING_LEVEL, default_value=pc.DEFAULT_LOGGING_LEVEL)
    logging_status_interval = pc.get_option_as_int(parser, args, pc.OPTION_LOGGING_STATUS_INTERVAL, pc.ENV_LOGGING_STATUS_INTERVAL, pc.DEFAULT_LOGGING_STATUS_INTERVAL, pc.MIN_LOGGING_STATUS_INTERVAL)
        
    global logger
    logger = pc.get_logger(__file__, logging_file_name, logging_max_size, logging_max_files, logging_level, logging_status_interval)
       
    logger.info('Starting...')   
    logger.info('CSV file: %s', csv_file)
    
    logger.info('ES hosts: %s', es_hosts)
    logger.info('ES user: %s', es_user)
    logger.info('ES password: %s', ''.rjust(len(es_password),'*'))
    logger.info('ES use TLS: %s', es_use_tls)
    logger.info('ES use hosts: %s', es_use_hosts)
    logger.info('ES use hostname: %s', es_use_hostname)
    logger.info('ES connect timeout: %d', es_connect_timeout)
    logger.info('ES read timeout: %d', es_read_timeout)
    logger.info('ES delete batch size: %d', es_delete_batch_size)    
    logger.info('ES delete threads count: %d', es_delete_threads)
    
    es_version = pc.init_es(es_hosts, es_user, es_password, es_use_tls, es_use_hosts, es_use_hostname, es_connect_timeout, es_read_timeout, logger)
    
    total_processed = process_csv(csv_file, es_version, es_delete_batch_size, es_delete_threads)
       
    print(total_processed, file=sys.stdout)
    
    logger.info('Done.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Bulk delete messages listed in a CSV file from ES.')
    parser.add_argument('csv_file', help='CSV file containing _index and _id for message documents.')
    
    parser.add_argument(pc.OPTION_ES_HOSTS, type=str, help=pc.HELP_ES_HOSTS)
    parser.add_argument(pc.OPTION_ES_USER, type=str, help=pc.HELP_ES_USER)
    parser.add_argument(pc.OPTION_ES_PASSWORD, type=str, help=pc.HELP_ES_PASSWORD)
    parser.add_argument(pc.OPTION_ES_USE_TLS, action='store_true', help=pc.HELP_ES_USE_TLS)    
    parser.add_argument(pc.OPTION_ES_USE_HOSTS, action='store_true', help=pc.HELP_ES_USE_HOSTS)  
    parser.add_argument(pc.OPTION_ES_USE_HOSTNAME, action='store_true', help=pc.HELP_ES_USE_HOSTNAME)  
    parser.add_argument(pc.OPTION_ES_CONNECT_TIMEOUT, type=int, help=pc.HELP_ES_CONNECT_TIMEOUT)  
    parser.add_argument(pc.OPTION_ES_READ_TIMEOUT, type=int, help=pc.HELP_ES_READ_TIMEOUT)  
    parser.add_argument(pc.OPTION_ES_DELETE_BATCH_SIZE, type=int, help=pc.HELP_ES_DELETE_BATCH_SIZE)  
    parser.add_argument(pc.OPTION_ES_DELETE_THREADS, type=int, help=pc.HELP_ES_DELETE_THREADS)  
        
    parser.add_argument(pc.OPTION_LOGGING_FILE_NAME, type=str, help=pc.HELP_LOGGING_FILE_NAME)
    parser.add_argument(pc.OPTION_LOGGING_MAX_SIZE, type=int, help=pc.HELP_LOGGING_MAX_SIZE)
    parser.add_argument(pc.OPTION_LOGGING_MAX_FILES, type=int, help=pc.HELP_LOGGING_MAX_FILES)
    parser.add_argument(pc.OPTION_LOGGING_LEVEL, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], help=pc.HELP_LOGGING_LEVEL)
    parser.add_argument(pc.OPTION_LOGGING_STATUS_INTERVAL, type=int, help=pc.HELP_LOGGING_STATUS_INTERVAL)
        
    main(parser)