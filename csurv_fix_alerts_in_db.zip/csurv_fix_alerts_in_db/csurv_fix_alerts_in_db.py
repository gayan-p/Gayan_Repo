'''Script to fix CSurv 4.x alert status records in the DB.'''

import argparse
import time
import os
import csv
import json
from datetime import datetime, timezone
import yaml
import app_common as app
from app_common import AppLogger
from es_client import ESClient
from es_client import ESNotFoundError
from postgresql_client import PostgresqlClient
import es_csurv as csurv

#
# Required libraries.
#
# pip3 install psycopg2
# pip3 install pyyaml
# pip3 install requests

OPTION_UPDATE   = '--update'
ENV_UPDATE      = 'UPDATE'
DEFAULT_UPDATE  = False
HELP_UPDATE     = 'If set, execute the update. Otherwise, list the records to be updated.'
HELP_UPDATE     += app.get_env_and_default(ENV_UPDATE, default_value=DEFAULT_UPDATE)

ALERTS_INDEX_PATTERN                = '__message_types*2*'
AUDIT_INDEX_PATTERN                 = '__alert_audit_types'

JSON_MESSAGE_DOC_TYPE_FILTER        = '{"term":{"doc_type":"' + csurv.DOC_TYPE_MESSAGE + '"}}'
JSON_ALERT_STATUS_DOC_TYPE_FILTER   = '{"term":{"doc_type":"' + csurv.DOC_TYPE_ALERT_STATUS + '"}}'
JSON_ALERT_AUDIT_DOC_TYPE_FILTER    = '{"term":{"doc_type":"' + csurv.DOC_TYPE_ALERT_AUDIT + '"}}'
JSON_TRACK_TOTAL_HITS               = '{"track_total_hits":true}'

JSON_GET_MESSAGE_BODY = '''
    {
        "query": { 
            "bool": {
                "filter": [
                    {
                        "term": {
                            "message_id": ""
                        }
                    }
                ]
            }
        },
        "_source": {
            "includes": ["key_indicators.name","key_indicators.key_indicator_id","ghost_key_indicators.name","ghost_key_indicators.key_indicator_id"]
        },
        "size": 1,
        "sort": ["_doc"]
    }
    '''
    
JSON_GET_ALERT_STATUS_BODY = '''
    {
        "query": { 
            "bool": {
                "filter": [
                    {
                        "term": {
                            "_id": ""
                        }
                    }
                ]
            }
        },
        "size": 1,
        "sort": ["_doc"]
    }
    '''                            

JSON_GET_ALERT_AUDIT_BODY = '''
    {
        "query": { 
            "bool": {
                "filter": [
                    {
                        "term": {
                            "message_id": ""
                        }
                    },
                    {
                        "term": {
                            "key_indicator_id": ""
                        }
                    },
                    {
                        "term": {
                            "is_manual_alert": true
                        }
                    }
                ]
            }
        },
        "size": 1,
        "sort": ["_doc"]
    }
    '''          
    
def get_message(es_client, indices, query_body, message_id):
    '''Get a message from the indices.'''
    
    if es_client.is_es5():
        request_url = '/' + indices + '/' + csurv.DOC_TYPE_MESSAGE + '/_search'
    else:
        request_url = '/' + indices + '/_search'
        
    query_body['query']['bool']['filter'][0]['term']['message_id'] = message_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
        
    return response.json()    
    
def get_alert_status(es_client, index, query_body, message_id, ki_id, logger):
    '''Get an alert status from the message's index.'''
    
    if es_client.is_es5():
        request_url = '/' + index + '/' + csurv.DOC_TYPE_ALERT_STATUS + '/_search'
    else:
        request_url = '/' + index + '/_search'
        
    query_body['query']['bool']['filter'][0]['term']['_id'] = message_id + '$' + ki_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
        
    results = response.json()  
    
    if es_client.is_es5():
        total_hits = results['hits']['total']
    else:
        total_hits = results['hits']['total']['value']
    
    logger.debug('Alert status total hits: %d', total_hits)
    
    hits = results['hits']['hits']
    
    source = None
    if total_hits > 0 and len(hits) > 0:
        source = hits[0]['_source']         
        logger.debug('Alert status: %s', source)  
    
    return source                   

def is_manual_alert(es_client, index, query_body, message_id, ki_id, logger):
    '''Check if a manual alert in the alert audit records. '''
    
    if es_client.is_es5():
        request_url = '/' + index + '/' + csurv.DOC_TYPE_ALERT_AUDIT + '/_search'
    else:
        request_url = '/' + index + '/_search'
        
    query_body['query']['bool']['filter'][0]['term']['message_id'] = message_id
    query_body['query']['bool']['filter'][1]['term']['key_indicator_id'] = ki_id
    
    data = json.dumps(query_body)
    
    response = es_client.es_get_request(request_url, data)
        
    results = response.json()  
    
    if es_client.is_es5():
        total_hits = results['hits']['total']
    else:
        total_hits = results['hits']['total']['value']
    
    logger.debug('Alert audit total hits: %d', total_hits)
    
    return total_hits > 0
    
def init_status_types(reporting_yaml, logger):
    '''Initialize the status types.'''
    
    with open(reporting_yaml, 'r', encoding='utf-8') as f:
        yaml_data = yaml.safe_load(f)
        
    status_types = yaml_data['defaults']['statusTypeMap']
        
    logger.info('Loaded status types: %s', status_types)
    
    return status_types        
    
def upsert_alert_status(db_client, message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of, logger):
    '''Upsert an alert record.'''
    
    if db_client is not None:
        query = """
            INSERT INTO R_ALERT_STATUS (message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (message_id, ki_id) 
            DO UPDATE SET 
                status = EXCLUDED.status,
                status_type = EXCLUDED.status_type,
                status_date = EXCLUDED.status_date,
                resolved = EXCLUDED.resolved,
                resolved_date = EXCLUDED.resolved_date,
                assignee = EXCLUDED.assignee,
                assignment_date = EXCLUDED.assignment_date,
                owner = EXCLUDED.owner,
                ghost = EXCLUDED.ghost,
                manual = EXCLUDED.manual,
                as_of = EXCLUDED.as_of;
        """
        
        values = (message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of)
        
        db_client.execute_insert(query, values)
        
        update_msg = 'Updated alert'
    else:
        update_msg = 'Test alert update'
        
    logger.info('%s for message_id: %s, ki_id: %s, status: %s, status_type: %s, status_date: %s, resolved: %s, resolved_date: %s, assignee: %s, assignment_date: %s, owner: %s, ghost: %s, manual: %s, as_of: %s', 
        update_msg, message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of)                     
             
def process_csv(csv_file, indices, audit_index, es_client, logger, status_types, as_of, db_client):
    '''Process a CSV file.'''
    
    logger.info('Counting messages...')
    row_count = app.get_csv_row_count(csv_file)
    logger.info('CSV message count: %d', row_count)
    
    start_exec = time.time()  
    total_msgs = 0  
    dup_messages = 0
    missing_messages = 0
    message_ids = set()
    
    message_query_body = json.loads(JSON_GET_MESSAGE_BODY)
    alert_status_query_body = json.loads(JSON_GET_ALERT_STATUS_BODY)
    alert_audit_query_body = json.loads(JSON_GET_ALERT_AUDIT_BODY)
    
    if es_client.is_es7(): 
        message_query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))
        alert_status_query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))
        alert_audit_query_body.update(json.loads(JSON_TRACK_TOTAL_HITS))
        
        # Add doc_type filter.
        message_query_body['query']['bool']['filter'].append(json.loads(JSON_MESSAGE_DOC_TYPE_FILTER))
        alert_status_query_body['query']['bool']['filter'].append(json.loads(JSON_ALERT_STATUS_DOC_TYPE_FILTER))
        alert_audit_query_body['query']['bool']['filter'].append(json.loads(JSON_ALERT_AUDIT_DOC_TYPE_FILTER))
    
    with open(csv_file, newline='', encoding='utf-8') as f:
        csv_reader = csv.DictReader(f)
        
        for row in csv_reader:
            try:
                message_id = row['message_id']
            except KeyError as ke:
                logger.error('message_id field not found in CSV file.')
                os._exit(1)
                
            if message_id in message_ids:
                dup_messages += 1
                continue
                
            message_ids.add(message_id)
            total_msgs += 1        
            
            try:
                logger.info('Getting KIs for message ID: %s', message_id)
                results = get_message(es_client, indices, message_query_body, message_id)
                
                if es_client.is_es5():
                    total_hits = results['hits']['total']
                else:
                    total_hits = results['hits']['total']['value']
                
                logger.debug('Total hits: %d', total_hits)
                
                hits = results['hits']['hits']
                
                if total_hits > 0 and len(hits) > 0:                    
                    _index = hits[0]['_index']
                    source = hits[0]['_source'] 
            
                    if 'key_indicators' in source:
                        for ki in source['key_indicators']:
                            ki_id = ki.get('key_indicator_id', None)
                            
                            if ki_id is None:
                                logger.warning('key_indicator_id missing in key_indicator for message_id: %s, key_indicator: %s', message_id, ki)
                                continue
                            
                            alert_status = get_alert_status(es_client, _index, alert_status_query_body, message_id, ki_id, logger)
                            
                            if alert_status is None:
                                logger.warning('Alert status record missing for message_id: %s, key_indicator_id: %s', message_id, ki_id)
                                continue
                                
                            status = alert_status.get('status', None) 
                            status_date = alert_status.get('status_date', None) 
                            resolved = alert_status.get('resolved', None) 
                            resolved_date = alert_status.get('resolved_date', None)
                            assignee = alert_status.get('assignee', None) 
                            assignment_date = alert_status.get('assignment_date', None) 
                            owner = alert_status.get('owner', None) 
                            ghost = False
                            status_type = status_types[status] if status is not None and status in status_types else None                            
                            manual = is_manual_alert(es_client, audit_index, alert_audit_query_body, message_id, ki_id, logger)
                            
                            upsert_alert_status(db_client, message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of, logger)                             
                            
                    if 'ghost_key_indicators' in source:
                        for ki in source['ghost_key_indicators']:
                            ki_id = ki.get('key_indicator_id', None)
                            
                            if ki_id is None:
                                logger.warning('key_indicator_id missing in key_indicator for message_id: %s, key_indicator: %s', message_id, ki)
                                continue
                            
                            status = None 
                            status_date = None 
                            resolved = False 
                            resolved_date = None
                            assignee = None 
                            assignment_date = None 
                            owner = None 
                            ghost = True
                            status_type = None                            
                            manual = False
                            
                            upsert_alert_status(db_client, message_id, ki_id, status, status_type, status_date, resolved, resolved_date, assignee, assignment_date, owner, ghost, manual, as_of, logger)
                else:
                    logger.info('Message not found: %s', message_id)
                    missing_messages += 1  
            except ESNotFoundError as _:
                logger.info('Message not found: %s', message_id)
                missing_messages += 1                     
                                  
    logger.info('All messages read.')    
    
    end_exec = time.time()    
    exec_time = end_exec - start_exec
    exec_mins = exec_time / 60
    docs_per_sec = total_msgs / exec_time if exec_time > 0 else total_msgs
     
    logger.info('Processed %d messages in %.2f minutes, docs/sec: %.0f, missing: %d, duplicates: %d', total_msgs, exec_mins, docs_per_sec, missing_messages, dup_messages)
    
    if total_msgs + dup_messages != row_count:
        logger.warning('Processed count %d plus duplicates %d not equal to the CSV message count %d.', total_msgs, dup_messages, row_count)
            
def main():
    '''Start of main.'''    
    parser = argparse.ArgumentParser(description='Fix alerts in DB from ES data.')
    parser.add_argument('kg_name', help='KG name.')
    parser.add_argument('csv_file', help='CSV file containing the message IDs to fix.')
    parser.add_argument('reporting_yaml', help='CSurv reporting.yaml file.')
    
    parser.add_argument(OPTION_UPDATE, action='store_true', help=HELP_UPDATE)    
        
    parser = ESClient.init_client_args(parser)    
    parser = ESClient.init_scroll_timeout_arg(parser)
    
    parser = PostgresqlClient.init_client_args(parser)
    
    parser = AppLogger.init_file_args(parser)
    
    args = parser.parse_args()
          
    app_logger = AppLogger.create_file_from_args(__file__, args, parser)
    logger = app_logger.get_logger()
    
    kg_name = args.kg_name
    csv_file = args.csv_file
    reporting_yaml = args.reporting_yaml
        
    es_scroll_timeout = ESClient.get_scroll_timeout(args)
       
    logger.info('Starting...')       
    
    indices = kg_name + ALERTS_INDEX_PATTERN
    audit_index = kg_name + AUDIT_INDEX_PATTERN
    
    as_of = datetime.now(timezone.utc)
    
    logger.info('KG name: %s', kg_name) 
    logger.info('CSV file: %s', csv_file)
    logger.info('Reporting config file: %s', reporting_yaml)
    logger.info('Indices: %s', indices)    
    logger.info('As of: %s', as_of)
          
    update = app.get_option_as_bool(args, OPTION_UPDATE, ENV_UPDATE, DEFAULT_UPDATE)    
    logger.info('Update: %s', update)
       
    es_client = ESClient.create_from_args(args, parser, logger)  
     
    logger.info('ES scroll timeout: %s', es_scroll_timeout)
    
    if update:
        db_client = PostgresqlClient.create_from_args(args, parser, logger)  
    else:
        db_client = None
        
    status_types = init_status_types(reporting_yaml, logger)
        
    process_csv(csv_file, indices, audit_index, es_client, logger, status_types, as_of, db_client)
                            
    logger.info('Done.')
            
if __name__ == '__main__':
    main()