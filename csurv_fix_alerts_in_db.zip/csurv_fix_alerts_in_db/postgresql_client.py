'''Elasticsearch client for ES 5 and 7.'''

import psycopg2
import app_common as app 

DB_DEFAULT_HOST            = 'localhost'
DB_DEFAULT_PORT            = 5432
DB_DEFAULT_DATABASE        = 'reporting'
DB_DEFAULT_SCHEMA          = 'csurv'
DB_DEFAULT_USER            = 'postgres'
DB_DEFAULT_PASSWORD        = '' 

class PostgresqlClient:  
    '''An PostgreSQL client.'''
    
    #
    # Constants
    #
    
    # Client options
    OPTION_DB_HOST          = '--db-host'
    OPTION_DB_PORT          = '--db-port'
    OPTION_DB_DATABASE      = '--db-database'
    OPTION_DB_SCHEMA        = '--db-schema'
    OPTION_DB_USER          = '--db-user'
    OPTION_DB_PASSWORD      = '--db-password'
    
    ENV_DB_HOST             = 'DB_HOSTS'
    ENV_DB_PORT             = 'DB_PORT'
    ENV_DB_DATABASE         = 'DB_DATABASE'
    ENV_DB_SCHEMA           = 'DB_SCHEMA'
    ENV_DB_USER             = 'DB_USER'
    ENV_DB_PASSWORD         = 'DB_PASSWORD'
 
    DEFAULT_DB_HOST         = 'localhost'
    DEFAULT_DB_PORT         = 5432
    DEFAULT_DB_DATABASE     = 'reporting'
    DEFAULT_DB_SCHEMA       = 'csurv'
    DEFAULT_DB_USER         = 'postgres'
    DEFAULT_DB_PASSWORD     = ''

    MIN_DB_PORT             = 1
    
    HELP_DB_HOST            = 'Database host or IP address.'
    HELP_DB_PORT            = 'Database port.'
    HELP_DB_DATABASE        = 'Database name.'
    HELP_DB_SCHEMA          = 'Database schema name.'
    HELP_DB_USER            = 'Database user.'
    HELP_DB_PASSWORD        = 'Database password.'

    HELP_DB_HOST            += app.get_env_and_default(ENV_DB_HOST, default_value=DEFAULT_DB_HOST)
    HELP_DB_PORT            += app.get_env_and_default(ENV_DB_PORT, default_value=DEFAULT_DB_PORT)
    HELP_DB_DATABASE        += app.get_env_and_default(ENV_DB_DATABASE, default_value=DEFAULT_DB_DATABASE)
    HELP_DB_SCHEMA          += app.get_env_and_default(ENV_DB_SCHEMA, default_value=DEFAULT_DB_SCHEMA)
    HELP_DB_USER            += app.get_env_and_default(ENV_DB_USER, default_value=DEFAULT_DB_USER)
    HELP_DB_PASSWORD        += app.get_env_and_default(ENV_DB_PASSWORD, default_value=DEFAULT_DB_PASSWORD)
    
    def __init__(self, db_conn, logger):
        '''Internal constructor for the database client.'''       
        self._db_conn = db_conn
        self._logger = logger     
      
    @staticmethod
    def init_client_args(parser):
        '''Initialize database client options.'''
        parser.add_argument(PostgresqlClient.OPTION_DB_HOST, type=str, help=PostgresqlClient.HELP_DB_HOST)
        parser.add_argument(PostgresqlClient.OPTION_DB_PORT, type=int, help=PostgresqlClient.HELP_DB_PORT)  
        parser.add_argument(PostgresqlClient.OPTION_DB_DATABASE, type=str, help=PostgresqlClient.HELP_DB_DATABASE)
        parser.add_argument(PostgresqlClient.OPTION_DB_SCHEMA, type=str, help=PostgresqlClient.HELP_DB_SCHEMA)
        parser.add_argument(PostgresqlClient.OPTION_DB_USER, type=str, help=PostgresqlClient.HELP_DB_USER)
        parser.add_argument(PostgresqlClient.OPTION_DB_PASSWORD, type=str, help=PostgresqlClient.HELP_DB_PASSWORD)       
        
        return parser
     
    @staticmethod
    def create_from_args(args, parser, logger):
        '''Create a database client from the options.'''
        # Options
        db_host = app.get_option_as_str(args, PostgresqlClient.OPTION_DB_HOST, PostgresqlClient.ENV_DB_HOST, default_value=PostgresqlClient.DEFAULT_DB_HOST)
        db_port = app.get_option_as_int(parser, args, PostgresqlClient.OPTION_DB_PORT, PostgresqlClient.ENV_DB_PORT, PostgresqlClient.DEFAULT_DB_PORT, PostgresqlClient.MIN_DB_PORT)
        db_database = app.get_option_as_str(args, PostgresqlClient.OPTION_DB_DATABASE, PostgresqlClient.ENV_DB_DATABASE, default_value=PostgresqlClient.DEFAULT_DB_DATABASE)
        db_schema = app.get_option_as_str(args, PostgresqlClient.OPTION_DB_SCHEMA, PostgresqlClient.ENV_DB_SCHEMA, default_value=PostgresqlClient.DEFAULT_DB_SCHEMA)
        db_user = app.get_option_as_str(args, PostgresqlClient.OPTION_DB_USER, PostgresqlClient.ENV_DB_USER, default_value=PostgresqlClient.DEFAULT_DB_USER)
        db_password = app.get_option_as_str(args, PostgresqlClient.OPTION_DB_PASSWORD, PostgresqlClient.ENV_DB_PASSWORD, default_value=PostgresqlClient.DEFAULT_DB_PASSWORD)
        
        return PostgresqlClient.create(db_host, db_port, db_database, db_schema, db_user, db_password, logger)
        
    @staticmethod
    def create(db_host, db_port, db_database, db_schema, db_user, db_password, logger):
        '''Create a database client.'''
        
        logger.info('DB host: %s', db_host)
        logger.info('DB port: %d', db_port)
        logger.info('DB database: %s', db_database)
        logger.info('DB schema: %s', db_schema)
        logger.info('DB user: %s', db_user)
        logger.info('DB password: %s', ''.rjust(len(db_password),'*'))
        
        logger.info('Connecting to DB...')
        db_conn = psycopg2.connect(
                host=db_host,
                port=db_port,
                database=db_database,
                user=db_user,
                password=db_password,
                options=f'-c search_path={db_schema}'
            )        
        
        return PostgresqlClient(db_conn, logger)
        
    def execute_insert(self, query, values):
        '''Execute an insert.'''
        
        try:
            with self._db_conn.cursor() as cursor:
                cursor.execute(query, values)
            self._db_conn.commit()
            self._logger.debug('Inserted: %s', values)
        except Exception as e: # pylint: disable=W0718
            self._db_conn.rollback()
            self._logger.error('Could not insert record. Query: %s, values: (%s), reason: %s', query, values, e)
     
