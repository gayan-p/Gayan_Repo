'''Elasticsearch client for ES 5 and 7.'''

import json
#import threading
#import urllib3
#import requests
import app_common as app
from es_client import ESRequestError

#
# ES Constants
#

DOC_TYPE_MESSAGE            = 'message'
DOC_TYPE_ALERT_STATUS       = 'alert_status'
DOC_TYPE_ALERT_AUDIT        = 'alert_audit'
DOC_TYPE_KI                 = 'key_indicator'

class CSurvKINamesCache:  
    '''KI name and ID mapping.'''
    
    #
    # Constants
    #
    KIS_INDEX_PATTERN           = '__monitoring_misc_types'
    JSON_KIS_DOC_TYPE_FILTER    = '{"term":{"doc_type":"' + DOC_TYPE_KI + '"}}'
    JSON_TRACK_TOTAL_HITS       = '{"track_total_hits":true}'
    JSON_SCROLL_BODY            = '{"scroll":"","scroll_id":""}'
    
    JSON_QUERY_BODY = '''
    {
        "query": { 
            "bool": {
                "filter": [
                    {
                        "match_all": {}
                    }
                ]
            }
        },
        "_source": "ki_name",
        "size": 100,
        "sort": ["_doc"]
    }
    '''
    
    @staticmethod
    def get_kis_search(es_client, query_body, kis_index, es_scroll_timeout):
        '''Get the initial batch of KIs.'''
        
        if es_client.is_es5():
            request_url = '/' + kis_index + '/' + DOC_TYPE_KI + '/' + '_search' + '?scroll=' + es_scroll_timeout
        else:
            request_url = '/' + kis_index + '/' + '_search' + '?scroll=' + es_scroll_timeout
            
        data = json.dumps(query_body)
        
        response = es_client.es_get_request(request_url, data)
        
        return response.json()
    
    @staticmethod
    def get_kis_scroll(es_client, scroll_id, query_body, es_scroll_timeout):
        '''Get a subsequent batch of KIs with the scroll_id.'''
      
        request_url = "/" + "_search/scroll"
        
        # Update the scroll.
        query_body['scroll'] = es_scroll_timeout
        query_body['scroll_id'] = scroll_id
        
        data = json.dumps(query_body)
        
        response = es_client.es_get_request(request_url, data)
        
        return response.json()

    @staticmethod
    def create(es_client, kg_name, es_scroll_timeout, logger):
        '''Create a cache of KI names.'''
        query_body = json.loads(CSurvKINamesCache.JSON_QUERY_BODY)
        scroll_body = json.loads(CSurvKINamesCache.JSON_SCROLL_BODY)
          
        if es_client.is_es7(): 
            query_body.update(json.loads(CSurvKINamesCache.JSON_TRACK_TOTAL_HITS))

            # Add doc_type filter.
            query_body['query']['bool']['filter'].append(json.loads(CSurvKINamesCache.JSON_KIS_DOC_TYPE_FILTER))
            
        kis_index = kg_name + CSurvKINamesCache.KIS_INDEX_PATTERN
                
        logger.info('Starting search...')
        
        results = CSurvKINamesCache.get_kis_search(es_client, query_body, kis_index, es_scroll_timeout)
        
        failed_shards = results['_shards']['failed']
        
        if failed_shards != 0:
            logger.error('Could not search KIs. Shards failed: %d', failed_shards)
            raise ESRequestError(f'Could not search KIs. Shards failed: {failed_shards}')
            
        if es_client.is_es5():
            total_hits = results['hits']['total']
        else:
            total_hits = results['hits']['total']['value']
        
        logger.info('Total hits: %d', total_hits)
        
        hits = results['hits']['hits']
          
        ki_by_id = {}
        ki_by_name = {}
        count = 0
        
        while total_hits > 0 and len(hits) > 0:
            # Save a batch of KIs.
            for hit in hits:
                _id = hit['_id']
                ki_name = hit['_source']['ki_name']
            
                ki_by_id[_id] = ki_name
                ki_by_name[ki_name] = _id
                count += 1
        
            scroll_id = results['_scroll_id']
                
            results = CSurvKINamesCache.get_kis_scroll(es_client, scroll_id, scroll_body, es_scroll_timeout)
            
            failed_shards = results['_shards']['failed']
        
            if failed_shards != 0:
                logger.error('Could not search alerts. Shards failed: %d', failed_shards)
                raise ESRequestError(f'Could not search KIs. Shards failed: {failed_shards}')
                    
            hits = results['hits']['hits']
        
        logger.info('Inited cache, total KIs: %d', count)
        
        return CSurvKINamesCache(ki_by_id, ki_by_name)
    
    def __init__(self, ki_by_id, ki_by_name):
        '''Internal constructor for the KI names.'''        
        self._ki_by_id = ki_by_id
        self._ki_by_name = ki_by_name
      
    def get_id(self, ki_name):
        '''Get a KI id by name.'''
        return self._ki_by_name[ki_name]
    
    def get_name(self, ki_id):
        '''Get a KI name by id.'''
        return self._ki_by_id[ki_id]

