'''Misc. utilities for scripts.'''

import logging
from logging.handlers import RotatingFileHandler
import os

def get_env_and_default(*env_var, default_value):
    '''Return the environment variable and default option value as a string.'''
    
    return ' (Env: ' + ' or '.join(env_var) + ', Default: ' + str(default_value) + ')'
   
def get_option_as_str(args, option_name, *env_names, default_value):
    '''Return a string option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None and option_value != '':
        return option_value
     
    for env_name in env_names:   
        env_value = os.getenv(env_name)
        if env_value is not None and env_value != '':
            return env_value
     
    return default_value
       
def get_option_as_int(parser, args, option_name, env_name, default_value, min_value):
    '''Return an integer option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None:
        if option_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {option_value}, must be greater than or equal to {min_value}.') 
        return option_value
        
    env_value = int(os.getenv(env_name)) if os.getenv(env_name) is not None else None
    if env_value is not None:
        if env_value < min_value:
            parser.error(option_name + '/' + env_name + f' = {env_value}, must be greater than or equal to {min_value}.')
        return env_value
        
    return default_value

def get_option_as_bool(args, option_name, env_name, default_value):
    '''Return an boolean option value from the cmd line, env, or default.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is True:
        return option_value
    
    env_value = os.getenv(env_name).lower() == 'true' if os.getenv(env_name) is not None else None    
    if env_value is not None:
        return env_value
    
    return default_value

def get_option_as_set(args, option_name, env_name, default_value):
    '''Get a comma-separated list of option values as a lower-case set.'''
    
    option_value = getattr(args, option_name.lstrip('--').replace('-', '_'))
    if option_value is not None and option_value != '':
        return set(option_value.lower().split(','))
        
    env_value = os.getenv(env_name)
    if env_value is not None and env_value != '':
        return set(env_value.lower().split(','))
        
    return default_value.lower() if default_value is not None else None

#   
# Argument Validators
#

def validate_int(parser, arg_name, arg_value, min_value):
    '''Validate an integer argument.'''
    
    if arg_value < min_value:
        parser.error(arg_name + f' = {arg_value}, must be greater than or equal to {min_value}.')
    return arg_value
       
#
# Logging
#   
class AppLogger:  
    '''Application logging.'''
    
    OPTION_LOGGING_LEVEL                = '--logging-level'
    OPTION_LOGGING_STATUS_INTERVAL      = '--logging-status-interval'
    OPTION_LOGGING_FILE_NAME            = '--logging-file-name'
    OPTION_LOGGING_MAX_SIZE             = '--logging-max-size'
    OPTION_LOGGING_MAX_FILES            = '--logging-max-files'
    
    ENV_LOGGING_LEVEL                   = 'LOGGING_LEVEL'
    ENV_LOGGING_STATUS_INTERVAL         = 'LOGGING_STATUS_INTERVAL'
    ENV_LOGGING_FILE_NAME               = 'LOGGING_FILE_NAME'
    ENV_LOGGING_MAX_SIZE                = 'LOGGING_MAX_SIZE'
    ENV_LOGGING_MAX_FILES               = 'LOGGING_MAX_FILES'
    
    DEFAULT_LOGGING_LEVEL               = 'INFO'
    DEFAULT_LOGGING_STATUS_INTERVAL     = 20
    DEFAULT_LOGGING_FILE_NAME           = 'application.log'
    DEFAULT_LOGGING_MAX_SIZE            = 10000000
    DEFAULT_LOGGING_MAX_FILES           = 10
    
    MIN_LOGGING_STATUS_INTERVAL         = 1
    MIN_LOGGING_MAX_SIZE                = 10000
    MIN_LOGGING_MAX_FILES               = 1
    
    HELP_LOGGING_LEVEL                  = 'Log level.'
    HELP_LOGGING_STATUS_INTERVAL        = 'Number of seconds between logging status updates.'
     
    HELP_LOGGING_LEVEL                  += get_env_and_default(ENV_LOGGING_LEVEL, default_value=DEFAULT_LOGGING_LEVEL)
    HELP_LOGGING_STATUS_INTERVAL        += get_env_and_default(ENV_LOGGING_STATUS_INTERVAL, default_value=DEFAULT_LOGGING_STATUS_INTERVAL)
    
    HELP_LOGGING_FILE_NAME              = 'Log file path. Parent directories in the path must already exist.'
    HELP_LOGGING_MAX_SIZE               = 'Maximum size in bytes for a log file before rollover.'
    HELP_LOGGING_MAX_FILES              = 'Maximum number of log files to save.'
    
    HELP_LOGGING_FILE_NAME              += get_env_and_default(ENV_LOGGING_FILE_NAME, default_value=DEFAULT_LOGGING_FILE_NAME)
    HELP_LOGGING_MAX_SIZE               += get_env_and_default(ENV_LOGGING_MAX_SIZE, default_value=DEFAULT_LOGGING_MAX_SIZE)
    HELP_LOGGING_MAX_FILES              += get_env_and_default(ENV_LOGGING_MAX_FILES, default_value=DEFAULT_LOGGING_MAX_FILES)
    
    def __init__(self, logger, status_interval):
        '''Internal constructor for the logger.'''      
        self._logger = logger
        self._status_interval = status_interval     
        
    @staticmethod
    def init_stdout_args(parser):
        '''Initialize stdout logging options.'''
        parser.add_argument(AppLogger.OPTION_LOGGING_LEVEL, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], help=AppLogger.HELP_LOGGING_LEVEL)
        parser.add_argument(AppLogger.OPTION_LOGGING_STATUS_INTERVAL, type=int, help=AppLogger.HELP_LOGGING_STATUS_INTERVAL)
            
        return parser
        
    @staticmethod
    def init_file_args(parser):
        '''Initialize log file logging options.'''
        parser = AppLogger.init_stdout_args(parser)
        parser.add_argument(AppLogger.OPTION_LOGGING_FILE_NAME, type=str, help=AppLogger.HELP_LOGGING_FILE_NAME)
        parser.add_argument(AppLogger.OPTION_LOGGING_MAX_SIZE, type=int, help=AppLogger.HELP_LOGGING_MAX_SIZE)
        parser.add_argument(AppLogger.OPTION_LOGGING_MAX_FILES, type=int, help=AppLogger.HELP_LOGGING_MAX_FILES)
    
        return parser
     
    @staticmethod   
    def create_stdout_from_args(name, args, parser):
        '''Create a stdout logger from the options.'''
        level = get_option_as_str(args, AppLogger.OPTION_LOGGING_LEVEL, AppLogger.ENV_LOGGING_LEVEL, default_value=AppLogger.DEFAULT_LOGGING_LEVEL)
        status_interval = get_option_as_int(parser, args, AppLogger.OPTION_LOGGING_STATUS_INTERVAL, AppLogger.ENV_LOGGING_STATUS_INTERVAL, AppLogger.DEFAULT_LOGGING_STATUS_INTERVAL, AppLogger.MIN_LOGGING_STATUS_INTERVAL)
      
        return AppLogger.create(name, level, status_interval, None, -1, -1)
    
    @staticmethod   
    def create_file_from_args(name, args, parser):
        '''Create a file logger from the options.'''
        level = get_option_as_str(args, AppLogger.OPTION_LOGGING_LEVEL, AppLogger.ENV_LOGGING_LEVEL, default_value=AppLogger.DEFAULT_LOGGING_LEVEL)
        status_interval = get_option_as_int(parser, args, AppLogger.OPTION_LOGGING_STATUS_INTERVAL, AppLogger.ENV_LOGGING_STATUS_INTERVAL, AppLogger.DEFAULT_LOGGING_STATUS_INTERVAL, AppLogger.MIN_LOGGING_STATUS_INTERVAL)
        file_name = get_option_as_str(args, AppLogger.OPTION_LOGGING_FILE_NAME, AppLogger.ENV_LOGGING_FILE_NAME, default_value=AppLogger.DEFAULT_LOGGING_FILE_NAME)
        max_size = get_option_as_int(parser, args, AppLogger.OPTION_LOGGING_MAX_SIZE, AppLogger.ENV_LOGGING_MAX_SIZE, AppLogger.DEFAULT_LOGGING_MAX_SIZE, AppLogger.MIN_LOGGING_MAX_SIZE)
        max_files = get_option_as_int(parser, args, AppLogger.OPTION_LOGGING_MAX_FILES, AppLogger.ENV_LOGGING_MAX_FILES, AppLogger.DEFAULT_LOGGING_MAX_FILES, AppLogger.MIN_LOGGING_MAX_FILES)
    
        return AppLogger.create(name, level, status_interval, file_name, max_size, max_files)
      
    @staticmethod  
    def create(name, level, status_interval, file_name, max_size, max_files):
        '''Create a stdout or file logger.'''        
        name = os.path.basename(name)
        logger = logging.getLogger(name)
        
        if file_name in (None, '', 'none'):
            logging.basicConfig(format='[%(asctime)s][%(name)s][%(levelname)s] %(message)s')
            
        else:
            handler = RotatingFileHandler(file_name, maxBytes=max_size, backupCount=max_files, encoding='utf-8')
            formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] %(message)s')    
        
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        logger.setLevel(level)
        
        return AppLogger(logger, status_interval)
        
    def get_logger(self):
        '''Get the logger.'''
        return self._logger
        
    def get_status_interval(self):
        '''Get the status interval.'''
        return self._status_interval
    
#
# CSV Utilities
#

def get_csv_row_count(csv_file):
    '''Count the rows in a CSV file minus the header row.'''
    
    with open(csv_file, 'rb') as f:
        row_count = sum(1 for _ in f)
    return row_count - 1