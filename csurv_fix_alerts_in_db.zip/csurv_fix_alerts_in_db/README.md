# csurv_fix_alerts_in_db.py
This Python script will update database records in the R_ALERT_STATUS table from the records in Elasticsearch.
**The script requires a CSV file with a message_id column.** The message IDs in this column will be searched
in the alerted and non-alerted message indices. For each message found and each KI in the key_indicators list, 
it will search for the alert_status record and an alert_audit record with the *is_manual_alert* field set to *true*. 
Using the data in the alert_status and the alert_audit records,
a record will be inserted into the R_ALERT_STATUS table. 
It will also insert a record into the R_ALERT_STATUS table for each message found and each KI in the ghost_key_indicators list.

By default, the script is run in a "test" mode, which conducts the ES search and logs the results, but no records are inserted into the database.
The *--update* option is required to update the records in the database with an SQL upsert.

# Supported Environment
- CSurv 4.x
- Elasticsearch 5.x or 7.x
- PostgreSQL
- Python3

# Required Python Packages
The following Python packages are required and can be installed as follows if they are not already present:
- PostgreSQL - pip3 install psycopg2
- YAML - pip3 install pyyaml
- ES HTTP - pip3 install requests
    

# Script Options and Environment Variables
All script options can be passed in as command-line options or environment variables.
Elasticsearch and PostgreSQL connection options should be set as needed. 

# Usage
```
usage: csurv_fix_alerts_in_db.py [-h] [--update] [--es-hosts ES_HOSTS]
                                 [--es-user ES_USER]
                                 [--es-password ES_PASSWORD] [--es-use-tls]
                                 [--es-use-hosts] [--es-use-hostname]
                                 [--es-connect-timeout ES_CONNECT_TIMEOUT]
                                 [--es-read-timeout ES_READ_TIMEOUT]
                                 [--es-scroll-timeout ES_SCROLL_TIMEOUT]
                                 [--db-host DB_HOST] [--db-port DB_PORT]
                                 [--db-database DB_DATABASE]
                                 [--db-schema DB_SCHEMA] [--db-user DB_USER]
                                 [--db-password DB_PASSWORD]
                                 [--logging-level {DEBUG,INFO,WARNING,ERROR}]
                                 [--logging-status-interval LOGGING_STATUS_INTERVAL]
                                 [--logging-file-name LOGGING_FILE_NAME]
                                 [--logging-max-size LOGGING_MAX_SIZE]
                                 [--logging-max-files LOGGING_MAX_FILES]
                                 kg_name csv_file reporting_yaml

Fix alerts in DB from ES data.

positional arguments:
  kg_name               KG name.
  csv_file              CSV file containing the message IDs to fix.
  reporting_yaml        CSurv reporting.yaml file.

optional arguments:
  -h, --help            show this help message and exit
  --update              If set, execute the update. Otherwise, list the
                        records to be updated. (Env: UPDATE, Default: False)
  --es-hosts ES_HOSTS   Comma-separated list of ES hosts or IP addresses with
                        optional ports. The default port is 9200. (Env:
                        ES_HOSTS, Default: localhost:9200)
  --es-user ES_USER     ES user name. (Env: ES_USER, Default: elastic)
  --es-password ES_PASSWORD
                        ES password. (Env: ES_PASSWORD, Default: )
  --es-use-tls          If set, use HTTPS for ES connections. Otherwise, use
                        HTTP. (Env: ES_USE_TLS, Default: False)
  --es-use-hosts        If set, use ES_HOSTS for connecting to ES. Otherwise,
                        use the sniffer to discover ES data nodes and only use
                        them for requests. (Env: ES_USE_HOSTS, Default: False)
  --es-use-hostname     If set and sniffing, connect to ES data nodes using
                        their hostname. Otherwise, use their IP address. (Env:
                        ES_USE_HOSTNAME, Default: False)
  --es-connect-timeout ES_CONNECT_TIMEOUT
                        ES connection timeout in seconds. (Env:
                        ES_CONNECT_TIMEOUT, Default: 60)
  --es-read-timeout ES_READ_TIMEOUT
                        ES read timeout in seconds. (Env: ES_READ_TIMEOUT,
                        Default: 300)
  --es-scroll-timeout ES_SCROLL_TIMEOUT
                        ES scroll timeout. (Env: ES_SCROLL_TIMEOUT, Default:
                        5m)
  --db-host DB_HOST     Database host or IP address. (Env: DB_HOSTS, Default:
                        localhost)
  --db-port DB_PORT     Database port. (Env: DB_PORT, Default: 5432)
  --db-database DB_DATABASE
                        Database name. (Env: DB_DATABASE, Default: reporting)
  --db-schema DB_SCHEMA
                        Database schema name. (Env: DB_SCHEMA, Default: csurv)
  --db-user DB_USER     Database user. (Env: DB_USER, Default: postgres)
  --db-password DB_PASSWORD
                        Database password. (Env: DB_PASSWORD, Default: )
  --logging-level {DEBUG,INFO,WARNING,ERROR}
                        Log level. (Env: LOGGING_LEVEL, Default: INFO)
  --logging-status-interval LOGGING_STATUS_INTERVAL
                        Number of seconds between logging status updates.
                        (Env: LOGGING_STATUS_INTERVAL, Default: 20)
  --logging-file-name LOGGING_FILE_NAME
                        Log file path. Parent directories in the path must
                        already exist. (Env: LOGGING_FILE_NAME, Default:
                        application.log)
  --logging-max-size LOGGING_MAX_SIZE
                        Maximum size in bytes for a log file before rollover.
                        (Env: LOGGING_MAX_SIZE, Default: 10000000)
  --logging-max-files LOGGING_MAX_FILES
                        Maximum number of log files to save. (Env:
                        LOGGING_MAX_FILES, Default: 10)
```
# Examples
Run the script in test mode to see the updated alerts in a named log file.
```
python3 csurv_fix_alerts_in_db.py --es-hosts "csurv-es-master:9200" --es-password "xxx" --db-host "csurv-db" --db-password "yyy" --logging-file-name "test_mode.log" "prod_kg" "messages.csv" "/synthesys/current/config/reporting.yaml"
```
Run the script in update mode to upsert the records into the database and see the updated alerts in a named log file.
```
python3 csurv_fix_alerts_in_db.py --update --es-hosts "csurv-es-master:9200" --es-password "xxx" --db-host "csurv-db" --db-password "yyy" --logging-file-name "update_mode.log" "prod_kg" "messages.csv" "/synthesys/current/config/reporting.yaml"
```